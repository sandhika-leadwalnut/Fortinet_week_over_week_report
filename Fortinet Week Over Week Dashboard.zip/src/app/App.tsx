import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Chart,
  LineController, BarController, DoughnutController,
  CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement,
  Legend, Tooltip, Title, Filler
} from 'chart.js';
import '../styles/fortinet.css';
import { KeyInsights, TabHead, HomePage, type InsightItem } from './dashParts';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import fortinetLogo from '../imports/WhatsApp_Image_2026-10-06_at_5.36.40_PM.jpeg';

Chart.register(
  LineController, BarController, DoughnutController,
  CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement,
  Legend, Tooltip, Title, Filler
);

// ═══════════════════ DATA ═══════════════════
const WEEKS = ["Dec 31","Jan 07","Jan 14","Jan 21","Jan 28","Feb 04","Feb 11","Feb 18","Feb 25","Mar 04","Mar 11","Mar 18","Mar 25","Apr 01","Apr 08","Apr 15","Apr 22","Apr 29","May 06","May 13","May 20","May 27","Jun 03","Jun 10","Jun 17","Jun 24","Jul 01","Jul 08","Jul 15","Jul 22","Jul 29","Aug 05","Aug 12","Aug 19","Aug 26","Sep 02","Sep 09","Sep 16","Sep 23","Sep 30","Oct 07","Oct 14","Oct 21","Oct 28"];

const CAT_STATS: Record<string, {total:number;valid:number;rank1:number;avg_rank:number;improving:number;declining:number;pct:number|string;tofu_mofu:number;bofu:number;not_ranking:number;tofu_r1:number;bofu_r1:number;isNew?:boolean}> = {
  // Source: Semrush · Oct 28, 2026 · Page 1 & Position 1 · WoW = Oct 21→Oct 28
  // valid = Page 1 (rank 1-10) | rank1 = Position 1 | improving/declining/not_ranking = Oct 21→Oct 28
  "Top Opportunities":{total:49, valid:31, rank1:27, avg_rank:7.1, improving:8, declining:11, pct:63.3, tofu_mofu:48, bofu:1, not_ranking:6, tofu_r1:26, bofu_r1:1},
  "NAC":             {total:80, valid:67, rank1:53, avg_rank:3.8, improving:16, declining:14, pct:83.8, tofu_mofu:72, bofu:8, not_ranking:5, tofu_r1:49, bofu_r1:4},
  "NGFW":            {total:141, valid:114, rank1:86, avg_rank:5.3, improving:16, declining:39, pct:80.9, tofu_mofu:111, bofu:30, not_ranking:4, tofu_r1:68, bofu_r1:18},
  "Zero Trust":      {total:20, valid:19, rank1:14, avg_rank:3, improving:2, declining:4, pct:95.0, tofu_mofu:19, bofu:1, not_ranking:0, tofu_r1:13, bofu_r1:1},
  "SD-WAN":          {total:130, valid:84, rank1:45, avg_rank:9.6, improving:34, declining:49, pct:64.6, tofu_mofu:120, bofu:10, not_ranking:10, tofu_r1:45, bofu_r1:0},
  "AI Cybersecurity":{total:136, valid:54, rank1:42, avg_rank:11.1, improving:29, declining:31, pct:39.7, tofu_mofu:112, bofu:24, not_ranking:48, tofu_r1:33, bofu_r1:9,isNew:true},
  "OT Security":     {total:46, valid:33, rank1:25, avg_rank:8.3, improving:12, declining:6, pct:71.7, tofu_mofu:38, bofu:8, not_ranking:1, tofu_r1:22, bofu_r1:3,isNew:true},
  "Quantum Security":{total:28, valid:16, rank1:13, avg_rank:9.5, improving:4, declining:6, pct:57.1, tofu_mofu:28, bofu:0, not_ranking:7, tofu_r1:13, bofu_r1:0,isNew:true},
  "SASE":            {total:30, valid:26, rank1:24, avg_rank:2.8, improving:2, declining:4, pct:86.7, tofu_mofu:28, bofu:2, not_ranking:1, tofu_r1:24, bofu_r1:0,isNew:true}
};

const WEEKLY_R1: Record<string, number[]> = {
  // Source CSV · count of keywords at Rank #1 each week · Dec31→Oct21
  "Top Opportunities":[21,18,20,22,20,16,22,23,27,26,26,18,19,30,28,35,32,28,31,32,29,24,27,22,27,23,23,22,24,19,20,16,19,21,22,13,18,20,18,16,22,24,28,27],
  "NAC":              [48,36,46,49,38,43,44,48,48,50,50,40,47,51,48,54,52,53,51,58,52,41,53,47,59,57,46,46,44,41,33,33,39,35,43,43,37,40,43,49,48,60,53,53],
  "NGFW":             [93,87,89,96,82,75,73,105,92,110,103,95,94,103,105,118,119,109,112,112,105,82,109,114,108,111,103,104,98,99,87,85,98,99,94,93,90,79,108,91,82,94,100,86],
  "Zero Trust":       [13,13,14,14,14,10,9,16,17,13,16,15,13,14,17,16,13,15,16,17,14,12,13,16,12,14,19,16,15,16,17,17,16,12,16,15,14,16,18,11,15,14,17,14],
  "SD-WAN":           [80,54,86,79,64,59,59,75,88,73,73,68,80,96,96,90,96,93,85,80,70,54,67,73,76,75,82,66,69,45,45,53,63,67,65,73,62,42,78,54,53,61,49,45],
  "AI Cybersecurity": [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,7,5,5,4,37,39,44,38,31,32,38,37,37,46,44,42],
  "OT Security":      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,15,15,12,14,17,20,20,19,22,29,22,26,26,26,25],
  "Quantum Security": [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,14,16,13,14,15,17,14,14,12,16,15,15,12,17,15,13],
  "SASE":             [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,23,22,20,17,22,25,22,24,23,20,21,26,23,20,22,25,24]
};

// Weekly average base rank per category · all 44 weeks · Source CSV Oct 28 2026
const WEEKLY_AVG_RANK: Record<string, (number|null)[]> = {
  "Top Opportunities":[7.49,8.19,7.02,8.11,7.81,7.76,6.11,6.36,5.23,4.76,4.98,6.6,4.72,5.0,4.79,4.96,5.54,7.06,5.68,5.69,5.13,5.98,5.76,6.31,4.65,7.5,9.22,8.64,9.25,9.47,8.4,8.18,7.39,7.82,8.73,8.09,9.95,9.17,9.35,9.6,6.88,7.33,6.91,7.14],
  "NAC":              [3.37,5.46,3.97,4.62,5.76,5.97,3.36,3.57,4.57,3.71,4.72,6.53,3.27,3.41,2.84,4.03,4.26,2.87,3.08,3.03,2.53,2.72,2.41,3.05,2.87,2.43,4.07,3.43,3.66,3.68,3.68,3.82,3.72,3.56,3.36,3.49,4.49,3.48,4.79,2.52,5.08,2.35,3.47,3.83],
  "NGFW":             [3.42,3.2,3.06,3.09,3.3,3.34,3.57,2.5,2.52,2.35,2.52,2.64,2.59,2.73,2.7,2.33,2.06,2.41,2.08,2.26,2.26,3.04,2.63,2.15,2.52,2.65,2.25,2.35,2.34,2.45,3.72,2.96,2.64,2.44,2.89,3.06,3.71,3.15,2.71,3.33,3.48,3.88,3.33,5.26],
  "Zero Trust":       [6.8,3.75,3.5,3.0,3.6,3.37,5.95,2.85,2.75,4.8,3.2,3.4,3.3,3.75,2.65,1.95,3.32,2.45,4.15,2.1,2.95,4.05,3.85,2.75,5.4,3.0,1.35,2.35,2.8,2.05,1.8,1.95,2.0,4.1,1.85,3.0,2.75,1.7,1.8,5.45,6.3,3.25,2.05,3.0],
  "SD-WAN":           [6.21,8.11,6.32,6.16,7.45,7.96,6.45,5.95,5.59,6.0,7.36,7.22,3.96,2.91,5.03,4.8,4.98,5.02,5.02,5.74,4.04,5.11,4.5,4.04,4.32,3.66,3.0,3.55,3.68,5.52,5.72,4.19,4.66,4.47,4.59,3.11,3.72,4.75,4.04,5.55,7.21,6.66,7.47,9.57],
  "AI Cybersecurity": [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,6.8,2.9,7.78,8.56,7.22,10.43,11.21,9.85,8.93,8.74,8.65,9.7,8.35,7.48,8.4,9.25,11.11],
  "OT Security":      [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,1.0,7.86,8.63,7.36,5.82,6.18,7.24,6.6,8.07,6.7,7.98,7.43,8.02,7.09,7.91,8.27],
  "Quantum Security": [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,10.48,7.33,4.95,7.32,7.67,5.76,4.25,5.95,6.33,7.14,5.68,4.91,5.64,7.59,7.0,6.15,9.52],
  "SASE":             [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,2.72,1.86,3.29,3.68,2.97,1.9,2.18,2.23,2.03,2.46,2.66,1.97,1.82,3.0,2.61,1.9,2.83]
};

// Page 1 (rank 1-10) count per week per category · Source CSV Oct 28 2026
const WEEKLY_PAGE1: Record<string, number[]> = {
  "Top Opportunities":[37,36,39,36,35,35,39,37,40,38,41,40,41,41,42,38,37,34,35,39,37,34,35,32,35,35,30,31,31,35,35,31,35,32,31,30,27,30,32,26,29,31,32,31],
  "NAC":              [72,74,72,71,70,70,72,73,71,73,72,70,75,74,73,68,67,75,71,73,73,72,71,70,71,72,70,71,69,70,72,70,70,71,71,71,69,71,67,73,62,72,70,67],
  "NGFW":             [133,132,134,133,131,134,134,135,136,136,135,137,135,135,135,134,137,135,137,135,134,133,132,133,131,131,133,134,135,134,131,133,134,134,130,128,126,129,131,130,126,127,132,114],
  "Zero Trust":       [16,17,18,20,18,19,16,19,19,17,17,18,19,18,19,19,17,20,18,20,20,19,18,19,16,18,20,19,19,20,19,19,20,18,19,18,19,19,20,17,18,19,20,19],
  "SD-WAN":           [110,105,109,107,104,101,108,109,109,109,105,104,109,112,105,107,109,110,107,107,100,100,102,101,99,105,104,104,99,98,101,102,103,103,102,99,99,99,106,97,94,98,97,84],
  "AI Cybersecurity": [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,9,7,6,6,58,54,60,52,59,60,57,62,59,61,62,54],
  "OT Security":      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,32,30,35,36,37,39,38,38,40,39,37,34,36,34,33],
  "Quantum Security": [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,16,17,14,16,17,17,16,16,16,18,16,18,13,17,16,16],
  "SASE":             [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,26,27,27,27,27,28,28,29,28,27,27,29,27,29,27,28,26]
};

import { KW, TOP_VOL, CAT_KEYWORDS, BACKLINK_KWS, NO_BACKLINK_KWS, RANK1_KEYWORDS, FunnelKW, TOP_TOFU_R1_KWS, TOP_BOFU_R1_KWS, solidR1, volatileKws } from './keywords';

// Week-over-week stats — CSV "FORT_Week_Over_Week_Rankings…__5_.csv" · Aug 26→Sep 02, 2026
// All 660 keywords · 9 categories · gaining = NR→ranking OR rank improved, declining=rank fell or ranking→NR
// bothNr = keywords where both weeks were NR
type WowStat = {improving:number;declining:number;stable:number;net:number;bothNr:number;tracked:number;total:number};
const WOW_STATS: Record<string, WowStat> = {
  // Week-over-week stats · Oct 21→Oct 28, 2026 · source: 9_Category_With_AIO.csv
  'Top Opportunities': {improving:8, declining:11, stable:26, bothNr:4,  net:-3,  tracked:49,  total:49},
  'NAC': {improving:16, declining:14, stable:46, bothNr:4,  net:2,  tracked:80,  total:80},
  'NGFW': {improving:16, declining:39, stable:86, bothNr:0,  net:-23,  tracked:141,  total:141},
  'Zero Trust': {improving:2, declining:4, stable:14, bothNr:0,  net:-2,  tracked:20,  total:20},
  'SD-WAN': {improving:34, declining:49, stable:41, bothNr:6,  net:-15,  tracked:130,  total:130},
  'SASE': {improving:2, declining:4, stable:23, bothNr:1,  net:-2,  tracked:30,  total:30},
  'Quantum Security': {improving:4, declining:6, stable:12, bothNr:6,  net:-2,  tracked:28,  total:28},
  'AI Cybersecurity': {improving:29, declining:31, stable:36, bothNr:40,  net:-2,  tracked:136,  total:136},
  'OT Security': {improving:12, declining:6, stable:27, bothNr:1,  net:6,  tracked:46,  total:46},
};

// Top movers per category — Oct 21 → Oct 28 2026
const WOW_MOVERS: Record<string, {gainers:{kw:string;vol:number;from:string;to:string;d:number}[];decliners:{kw:string;vol:number;from:string;to:string;d:number}[]}> = {
  // Top movers per category — Oct 21 → Oct 28 2026 · source: 9_Category_With_AIO_Data.csv · top 3 by highest SV
  'Top Opportunities': {
    gainers:   [{kw:'iot',vol:27100,from:'34',to:'31',d:3},{kw:'internet of things',vol:22200,from:'48',to:'25',d:23},{kw:'access control',vol:12100,from:'18',to:'1',d:17}],
    decliners: [{kw:'vpn',vol:673000,from:'1',to:'15',d:-14},{kw:'proxy',vol:201000,from:'3',to:'5',d:-2},{kw:'what is phishing',vol:74000,from:'1',to:'8',d:-7}],
  },
  'NAC': {
    gainers:   [{kw:'access control',vol:12100,from:'18',to:'1',d:17},{kw:'access control management',vol:720,from:'49',to:'19',d:30},{kw:'access control services',vol:720,from:'23',to:'5',d:18}],
    decliners: [{kw:'nac network',vol:1300,from:'1',to:'19',d:-18},{kw:'what is access control',vol:1000,from:'1',to:'21',d:-20},{kw:'bring your own device policy',vol:720,from:'1',to:'8',d:-7}],
  },
  'NGFW': {
    gainers:   [{kw:'network firewall',vol:3600,from:'7',to:'1',d:6},{kw:'waf meaning',vol:1000,from:'4',to:'1',d:3},{kw:'waf firewall',vol:480,from:'5',to:'1',d:4}],
    decliners: [{kw:'hardware firewall',vol:4400,from:'1',to:'4',d:-3},{kw:'small business firewall',vol:720,from:'1',to:'6',d:-5},{kw:'types of firewall',vol:720,from:'1',to:'7',d:-6}],
  },
  'Zero Trust': {
    gainers:   [{kw:'zero trust',vol:9900,from:'10',to:'9',d:1},{kw:'ztna security',vol:260,from:'6',to:'1',d:5}],
    decliners: [{kw:'zero trust architecture',vol:6600,from:'1',to:'22',d:-21},{kw:'zero trust edge',vol:260,from:'1',to:'3',d:-2},{kw:'VPN to ZTNA',vol:30,from:'1',to:'2',d:-1}],
  },
  'SD-WAN': {
    gainers:   [{kw:'what is sd wan',vol:1900,from:'30',to:'1',d:29},{kw:'software defined wan',vol:1600,from:'3',to:'1',d:2},{kw:'sd wan meaning',vol:1300,from:'3',to:'1',d:2}],
    decliners: [{kw:'what is wan',vol:2900,from:'1',to:'4',d:-3},{kw:'managed sd wan',vol:1000,from:'4',to:'20',d:-16},{kw:'sd wan explained',vol:720,from:'1',to:'21',d:-20}],
  },
  'SASE': {
    gainers:   [{kw:'Sase Services',vol:390,from:'2',to:'1',d:1},{kw:'Ai Powered Sase',vol:30,from:'14',to:'12',d:2}],
    decliners: [{kw:'Sse',vol:14800,from:'10',to:'12',d:-2},{kw:'Sase Providers',vol:480,from:'1',to:'21',d:-20},{kw:'Single Vendor Sase',vol:170,from:'4',to:'6',d:-2}],
  },
  'Quantum Security': {
    gainers:   [{kw:'quantum cryptography',vol:18100,from:'39',to:'33',d:6},{kw:'what is QKD',vol:40,from:'7',to:'6',d:1}],
    decliners: [{kw:'PQC',vol:1900,from:'24',to:'26',d:-2},{kw:'quantum computing security',vol:170,from:'1',to:'5',d:-4},{kw:'quantum readiness',vol:110,from:'21',to:'43',d:-22}],
  },
  'AI Cybersecurity': {
    gainers:   [{kw:'AI security',vol:6600,from:'22',to:'9',d:13},{kw:'deepfake ai',vol:5400,from:'4',to:'1',d:3},{kw:'list of ai cybersecurity tools',vol:2400,from:'47',to:'21',d:26}],
    decliners: [{kw:'aiops',vol:5400,from:'14',to:'25',d:-11},{kw:'what are ai data centers',vol:1000,from:'1',to:'22',d:-21},{kw:'deepfakes meaning',vol:1000,from:'1',to:'23',d:-22}],
  },
  'OT Security': {
    gainers:   [{kw:'ot security tools',vol:170,from:'5',to:'1',d:4},{kw:'ics/ot',vol:140,from:'35',to:'14',d:21},{kw:'ot security company',vol:140,from:'5',to:'4',d:1}],
    decliners: [{kw:'ot network security',vol:390,from:'1',to:'5',d:-4},{kw:'ot security companies',vol:210,from:'17',to:'19',d:-2},{kw:'ot vulnerabilities',vol:140,from:'15',to:'90',d:-75}],
  },
};

// WoW distribution buckets · Oct 21→Oct 28 · ↑20+,↑10-20,↑5-10,↑1-5,Stable,↓1-5,↓5-10,↓10-20,↓20+
// Computed from 9_Category_With_AIO.csv (keywords with both weeks ranked)
const WOW_DIST = [15,20,13,54,311,47,27,46,24];

// All keywords flattened with WoW delta for the full keyword risk table · Oct 21→Oct 28
const ALL_KW_WOW = (()=>{
  const rows: {keyword:string;category:string;vol:number;aug12:number|null;aug19:number|null;delta:number|null}[] = [];
  for(const [cat,kws] of Object.entries(CAT_KEYWORDS)){
    for(const kw of kws){
      const aug12=kw.ranks[42]??null;  // Oct 21 rank
      const aug19=kw.ranks[43]??null;  // Oct 28 rank
      const delta=(aug12!=null&&aug19!=null)?aug19-aug12:null;
      rows.push({keyword:kw.keyword,category:cat,vol:kw.vol_jan26,aug12,aug19,delta});
    }
  }
  rows.sort((a,b)=>{
    if(a.delta==null&&b.delta==null) return 0;
    if(a.delta==null) return 1;
    if(b.delta==null) return -1;
    return a.delta-b.delta; // most improved (negative delta) first
  });
  return rows;
})();

const WOW_MOVERS_FUNNEL: Record<string,{TOFU:{kw:string,vol:number,from:number,to:number,d:number}[],MOFU:{kw:string,vol:number,from:number,to:number,d:number}[],BOFU:{kw:string,vol:number,from:number,to:number,d:number}[]}> = {
  // Oct 21 → Oct 28 2026 · Source: 9_Category_With_AIO_Data.csv · top 3 by highest SV
  'Top Opportunities': {
    TOFU: [{kw:"phishing",vol:49500,from:0,to:26,d:99},{kw:"internet of things",vol:22200,from:48,to:25,d:23},{kw:"access control",vol:12100,from:18,to:1,d:17},{kw:"how does vpn work",vol:4400,from:9,to:1,d:8},{kw:"network firewall",vol:3600,from:7,to:1,d:6},{kw:"iot",vol:27100,from:34,to:31,d:3},{kw:"malware definition",vol:8100,from:18,to:15,d:3},{kw:"zero day",vol:368000,from:0,to:0,d:0},{kw:"cybersecurity",vol:201000,from:1,to:1,d:0},{kw:"what is a firewall",vol:135000,from:1,to:1,d:0},{kw:"malware",vol:40500,from:15,to:15,d:0},{kw:"ddos",vol:33100,from:1,to:1,d:0},{kw:"iam",vol:33100,from:1,to:1,d:0},{kw:"wan",vol:33100,from:1,to:1,d:0},{kw:"ransomware",vol:33100,from:1,to:1,d:0},{kw:"proxy server",vol:33100,from:1,to:1,d:0},{kw:"firewall",vol:27100,from:1,to:1,d:0},{kw:"encryption",vol:22200,from:16,to:16,d:0},{kw:"ddos attack",vol:18100,from:1,to:1,d:0},{kw:"what is a proxy server",vol:18100,from:1,to:1,d:0},{kw:"sase",vol:14800,from:1,to:1,d:0},{kw:"multi factor authentication",vol:14800,from:0,to:0,d:0},{kw:"oauth",vol:12100,from:1,to:1,d:0},{kw:"what is a proxy",vol:12100,from:3,to:3,d:0},{kw:"phishing email",vol:9900,from:0,to:0,d:0},{kw:"qos",vol:9900,from:1,to:1,d:0},{kw:"byod",vol:9900,from:1,to:1,d:0},{kw:"ddos meaning",vol:8100,from:1,to:1,d:0},{kw:"sd wan",vol:6600,from:1,to:1,d:0},{kw:"sd-wan",vol:6600,from:1,to:1,d:0},{kw:"sdwan",vol:6600,from:1,to:1,d:0},{kw:"encryption definition",vol:6600,from:1,to:1,d:0},{kw:"firewalls",vol:5400,from:1,to:1,d:0},{kw:"what is ddos",vol:3600,from:1,to:1,d:0},{kw:"802.1 x",vol:1000,from:1,to:1,d:0},{kw:"network firewalls",vol:720,from:1,to:1,d:0},{kw:"what is malware",vol:135000,from:24,to:0,d:-99},{kw:"saml",vol:18100,from:18,to:0,d:-99},{kw:"single sign on",vol:12100,from:1,to:20,d:-19},{kw:"ethernet switching",vol:260,from:1,to:20,d:-19},{kw:"vpn",vol:673000,from:1,to:15,d:-14},{kw:"phishing definition",vol:27100,from:26,to:39,d:-13},{kw:"what is phishing",vol:74000,from:1,to:8,d:-7},{kw:"what is ips",vol:3600,from:1,to:7,d:-6},{kw:"ips",vol:49500,from:17,to:21,d:-4},{kw:"proxy",vol:201000,from:3,to:5,d:-2},{kw:"two factor authentication",vol:12100,from:13,to:14,d:-1}],
    MOFU: [{kw:"vpn service",vol:9900,from:0,to:0,d:0}],
    BOFU: [{kw:"ethernet switch",vol:14800,from:0,to:1,d:99}],
  },
  'NAC': {
    TOFU: [{kw:"identity access management",vol:2900,from:0,to:35,d:99},{kw:"access control management",vol:720,from:49,to:19,d:30},{kw:"access control list example",vol:140,from:25,to:1,d:24},{kw:"access control services",vol:720,from:23,to:5,d:18},{kw:"access control",vol:12100,from:18,to:1,d:17},{kw:"networking acl",vol:90,from:19,to:2,d:17},{kw:"what is identity and access management",vol:590,from:7,to:1,d:6},{kw:"network access control software",vol:320,from:6,to:1,d:5},{kw:"access control definition",vol:320,from:4,to:1,d:3},{kw:"access control examples",vol:110,from:4,to:1,d:3},{kw:"nac security",vol:210,from:3,to:1,d:2},{kw:"nac tools",vol:50,from:3,to:1,d:2},{kw:"nac server",vol:20,from:3,to:1,d:2},{kw:"iam definition",vol:260,from:2,to:1,d:1},{kw:"nac security solution",vol:30,from:3,to:2,d:1},{kw:"byod",vol:9900,from:1,to:1,d:0},{kw:"iot security",vol:3600,from:1,to:1,d:0},{kw:"network access control",vol:2900,from:1,to:1,d:0},{kw:"bring your own device",vol:2400,from:0,to:0,d:0},{kw:"what is iam",vol:1900,from:1,to:1,d:0},{kw:"access control security",vol:1300,from:2,to:2,d:0},{kw:"iot device security",vol:1000,from:1,to:1,d:0},{kw:"network access control solutions",vol:1000,from:1,to:1,d:0},{kw:"internet of things security",vol:880,from:1,to:1,d:0},{kw:"what is iot security",vol:880,from:1,to:1,d:0},{kw:"access control lists",vol:720,from:1,to:1,d:0},{kw:"acl network",vol:720,from:1,to:1,d:0},{kw:"identity and access management system",vol:720,from:1,to:1,d:0},{kw:"network access control list",vol:480,from:1,to:1,d:0},{kw:"what is network access control",vol:390,from:1,to:1,d:0},{kw:"nac cyber security",vol:390,from:1,to:1,d:0},{kw:"what is nac in networking",vol:390,from:1,to:1,d:0},{kw:"iot network security",vol:320,from:1,to:1,d:0},{kw:"iot network security",vol:320,from:1,to:1,d:0},{kw:"access control methods",vol:260,from:1,to:1,d:0},{kw:"access control meaning",vol:260,from:1,to:1,d:0},{kw:"what is an acl networking",vol:210,from:2,to:2,d:0},{kw:"nac network access",vol:210,from:1,to:1,d:0},{kw:"access control list in networking",vol:140,from:1,to:1,d:0},{kw:"nac network security",vol:140,from:1,to:1,d:0},{kw:"acl firewall",vol:110,from:1,to:1,d:0},{kw:"nac network access control",vol:110,from:1,to:1,d:0},{kw:"nac it",vol:110,from:1,to:1,d:0},{kw:"nac technology",vol:110,from:1,to:1,d:0},{kw:"acls security",vol:110,from:1,to:1,d:0},{kw:"security for iot devices",vol:70,from:1,to:1,d:0},{kw:"what is iam security",vol:50,from:1,to:1,d:0},{kw:"network access control benefits",vol:50,from:1,to:1,d:0},{kw:"cyber security in iot devices",vol:50,from:1,to:1,d:0},{kw:"what is nac security",vol:30,from:1,to:1,d:0},{kw:"security on iot devices",vol:30,from:1,to:1,d:0},{kw:"cyber security iot devices",vol:30,from:1,to:1,d:0},{kw:"nac computer",vol:20,from:1,to:1,d:0},{kw:"network access control methods",vol:20,from:1,to:1,d:0},{kw:"access control methods in computer networks",vol:20,from:5,to:5,d:0},{kw:"nac computer security",vol:20,from:1,to:1,d:0},{kw:"acl access control lists",vol:10,from:1,to:1,d:0},{kw:"iam identity access management",vol:1900,from:1,to:0,d:-99},{kw:"benefits of access control list",vol:40,from:4,to:34,d:-30},{kw:"access control in network security",vol:90,from:1,to:23,d:-22},{kw:"what is access control",vol:1000,from:1,to:21,d:-20},{kw:"nac network",vol:1300,from:1,to:19,d:-18},{kw:"how to secure iot devices",vol:170,from:5,to:19,d:-14},{kw:"bring your own device policy",vol:720,from:1,to:8,d:-7},{kw:"acls networking",vol:210,from:1,to:5,d:-4},{kw:"types of access control list",vol:50,from:9,to:13,d:-4},{kw:"network access control device",vol:50,from:1,to:4,d:-3},{kw:"network access control system",vol:210,from:1,to:3,d:-2},{kw:"network access control technologies",vol:20,from:1,to:3,d:-2},{kw:"how to secure iot network",vol:20,from:1,to:3,d:-2},{kw:"network access control policy",vol:40,from:1,to:2,d:-1}],
    MOFU: [{kw:"access control technologies",vol:880,from:1,to:1,d:0}],
    BOFU: [{kw:"nac solutions",vol:390,from:6,to:1,d:5},{kw:"access control solutions",vol:1900,from:0,to:0,d:0},{kw:"iot security solutions",vol:1000,from:1,to:1,d:0},{kw:"access control devices",vol:590,from:0,to:0,d:0},{kw:"iot firewall",vol:70,from:5,to:5,d:0},{kw:"network access control products",vol:40,from:1,to:1,d:0},{kw:"nac service",vol:40,from:0,to:0,d:0},{kw:"nac network access control products",vol:20,from:1,to:1,d:0}],
  },
  'NGFW': {
    TOFU: [{kw:"layer 7 firewall",vol:390,from:41,to:17,d:24},{kw:"network firewall",vol:3600,from:7,to:1,d:6},{kw:"waf firewall",vol:480,from:5,to:1,d:4},{kw:"waf meaning",vol:1000,from:4,to:1,d:3},{kw:"what is a stateful firewall",vol:260,from:2,to:1,d:1},{kw:"firewall as a service providers",vol:210,from:2,to:1,d:1},{kw:"cloud firewall service",vol:210,from:2,to:1,d:1},{kw:"enterprise security firewall",vol:50,from:3,to:2,d:1},{kw:"what is a firewall",vol:135000,from:1,to:1,d:0},{kw:"firewall",vol:27100,from:1,to:1,d:0},{kw:"web application firewall",vol:9900,from:8,to:8,d:0},{kw:"firewalls",vol:5400,from:1,to:1,d:0},{kw:"firewall configuration",vol:5400,from:1,to:1,d:0},{kw:"network firewall security",vol:4400,from:1,to:1,d:0},{kw:"network security firewall",vol:2400,from:1,to:1,d:0},{kw:"network security firewall",vol:2400,from:1,to:1,d:0},{kw:"firewall settings",vol:1900,from:3,to:3,d:0},{kw:"what does a firewall do",vol:1600,from:1,to:1,d:0},{kw:"stateful firewall",vol:1300,from:1,to:1,d:0},{kw:"what is waf",vol:1300,from:1,to:1,d:0},{kw:"waf security",vol:1300,from:1,to:1,d:0},{kw:"stateful vs stateless firewall",vol:1000,from:1,to:1,d:0},{kw:"stateful inspection firewall",vol:1000,from:1,to:1,d:0},{kw:"firewall as a service",vol:1000,from:1,to:1,d:0},{kw:"network firewalls",vol:720,from:1,to:1,d:0},{kw:"how does a firewall work",vol:590,from:1,to:1,d:0},{kw:"utm firewall",vol:590,from:1,to:1,d:0},{kw:"proxy firewall",vol:590,from:1,to:1,d:0},{kw:"firewalls explained",vol:480,from:1,to:1,d:0},{kw:"security firewall",vol:390,from:1,to:1,d:0},{kw:"security firewall",vol:390,from:1,to:1,d:0},{kw:"network based firewall",vol:390,from:1,to:1,d:0},{kw:"next generation firewall ngfw",vol:390,from:1,to:1,d:0},{kw:"what is a network firewall",vol:320,from:1,to:1,d:0},{kw:"waf vs firewall",vol:320,from:1,to:1,d:0},{kw:"what is firewall in networking",vol:260,from:1,to:1,d:0},{kw:"physical firewall",vol:260,from:1,to:1,d:0},{kw:"how firewall works",vol:210,from:1,to:1,d:0},{kw:"perimeter firewall",vol:210,from:1,to:1,d:0},{kw:"hardware vs software firewall",vol:170,from:1,to:1,d:0},{kw:"firewall setup",vol:170,from:2,to:2,d:0},{kw:"hardware firewall vs software firewall",vol:140,from:1,to:1,d:0},{kw:"proxy server firewall",vol:140,from:1,to:1,d:0},{kw:"benefits of firewall",vol:140,from:1,to:1,d:0},{kw:"utm vs firewall",vol:110,from:1,to:1,d:0},{kw:"how firewalls work",vol:90,from:1,to:1,d:0},{kw:"firewall vs waf",vol:90,from:1,to:1,d:0},{kw:"next generation firewall vs utm",vol:90,from:1,to:1,d:0},{kw:"software firewall vs hardware firewall",vol:70,from:1,to:1,d:0},{kw:"distributed firewall",vol:70,from:1,to:1,d:0},{kw:"what is proxy firewall",vol:70,from:1,to:1,d:0},{kw:"what are software firewalls",vol:70,from:1,to:1,d:0},{kw:"next generation firewall vs waf",vol:70,from:1,to:1,d:0},{kw:"what is utm firewall",vol:50,from:1,to:1,d:0},{kw:"firewall vs utm",vol:50,from:1,to:1,d:0},{kw:"border firewall",vol:50,from:1,to:1,d:0},{kw:"benefits of firewall security",vol:50,from:1,to:1,d:0},{kw:"firewall defined",vol:40,from:1,to:1,d:0},{kw:"configuration of firewall",vol:40,from:1,to:1,d:0},{kw:"how network firewall works",vol:40,from:1,to:1,d:0},{kw:"application proxy firewall",vol:30,from:1,to:1,d:0},{kw:"working of firewall",vol:30,from:1,to:1,d:0},{kw:"how hardware firewall works",vol:30,from:1,to:1,d:0},{kw:"ngfw vs ips",vol:30,from:2,to:2,d:0},{kw:"difference between next generation firewall and standard firewall",vol:30,from:1,to:1,d:0},{kw:"transparent firewalls",vol:20,from:1,to:1,d:0},{kw:"layer 2 firewall",vol:20,from:1,to:1,d:0},{kw:"network firewall definition",vol:20,from:1,to:1,d:0},{kw:"how firewall works in network",vol:20,from:1,to:1,d:0},{kw:"transparent mode firewall",vol:20,from:2,to:2,d:0},{kw:"firewall transparent mode",vol:20,from:2,to:2,d:0},{kw:"difference between application level firewall and network level firewall",vol:20,from:1,to:1,d:0},{kw:"next generation firewalls ngfw",vol:20,from:1,to:1,d:0},{kw:"how to setup a firewall",vol:140,from:1,to:0,d:-99},{kw:"5th generation firewall",vol:30,from:6,to:0,d:-99},{kw:"what is next generation firewalls",vol:40,from:1,to:21,d:-20},{kw:"ngfw definition",vol:40,from:1,to:21,d:-20},{kw:"what is the next generation firewall",vol:30,from:1,to:21,d:-20},{kw:"next generation firewall meaning",vol:30,from:1,to:21,d:-20},{kw:"application firewall and network firewall",vol:40,from:1,to:20,d:-19},{kw:"ngfw layer 7 firewall",vol:30,from:4,to:23,d:-19},{kw:"stateless firewall",vol:320,from:2,to:20,d:-18},{kw:"how network firewall is different from application firewall",vol:40,from:2,to:20,d:-18},{kw:"ngfw network",vol:30,from:12,to:23,d:-11},{kw:"what is next generation firewall",vol:170,from:1,to:9,d:-8},{kw:"advantages of hardware firewall",vol:30,from:2,to:10,d:-8},{kw:"ngfw networking",vol:30,from:1,to:8,d:-7},{kw:"types of firewall",vol:720,from:1,to:7,d:-6},{kw:"what is next generation firewall ngfw",vol:30,from:1,to:7,d:-6},{kw:"hardware firewall",vol:4400,from:1,to:4,d:-3},{kw:"secure web gateway vs next generation firewall",vol:30,from:21,to:24,d:-3},{kw:"stateless vs stateful firewall",vol:720,from:1,to:2,d:-1},{kw:"stateful firewall vs stateless firewall",vol:590,from:1,to:2,d:-1},{kw:"firewall utm ngfw",vol:30,from:1,to:2,d:-1}],
    MOFU: [{kw:"what is enterprise firewall",vol:30,from:26,to:8,d:18},{kw:"advantages to next generation firewalls",vol:30,from:8,to:4,d:4},{kw:"advantages to next generation firewall",vol:30,from:8,to:4,d:4},{kw:"ngfw tools",vol:20,from:4,to:1,d:3},{kw:"next generation firewall software",vol:30,from:4,to:3,d:1},{kw:"next generation firewall security",vol:40,from:1,to:1,d:0},{kw:"next generation enterprise firewall",vol:30,from:1,to:1,d:0},{kw:"next gen firewall services",vol:70,from:4,to:47,d:-43},{kw:"ngfw firewall features",vol:20,from:1,to:24,d:-23},{kw:"ngfw magic quadrant",vol:20,from:2,to:19,d:-17},{kw:"next generation firewall benefits",vol:50,from:5,to:21,d:-16},{kw:"features of next generation firewall",vol:70,from:1,to:15,d:-14},{kw:"next generation firewall features list",vol:30,from:1,to:15,d:-14},{kw:"enterprise firewall magic quadrant",vol:30,from:1,to:9,d:-8},{kw:"next gen firewall magic quadrant",vol:40,from:1,to:5,d:-4},{kw:"branch office firewall",vol:20,from:4,to:8,d:-4},{kw:"ngfw throughput",vol:30,from:2,to:5,d:-3}],
    BOFU: [{kw:"enterprise firewall",vol:320,from:11,to:1,d:10},{kw:"enterprise grade firewall",vol:30,from:15,to:11,d:4},{kw:"enterprise firewall router",vol:40,from:33,to:30,d:3},{kw:"ngfw",vol:4400,from:1,to:1,d:0},{kw:"next generation firewall",vol:2400,from:1,to:1,d:0},{kw:"next gen firewall",vol:2400,from:1,to:1,d:0},{kw:"firewall next generation",vol:720,from:1,to:1,d:0},{kw:"business firewall",vol:320,from:1,to:1,d:0},{kw:"firewall price",vol:170,from:1,to:1,d:0},{kw:"firewall cost",vol:90,from:1,to:1,d:0},{kw:"network firewall price",vol:90,from:1,to:1,d:0},{kw:"next generation firewall appliance",vol:90,from:1,to:1,d:0},{kw:"network firewall security price",vol:70,from:1,to:1,d:0},{kw:"network firewall cost",vol:70,from:2,to:2,d:0},{kw:"firewall security price",vol:30,from:1,to:1,d:0},{kw:"nexgen firewall",vol:30,from:1,to:1,d:0},{kw:"ngfw products",vol:30,from:1,to:1,d:0},{kw:"firewall security price in usa",vol:20,from:1,to:1,d:0},{kw:"low cost firewall",vol:20,from:3,to:3,d:0},{kw:"add a next generation firewall",vol:20,from:1,to:1,d:0},{kw:"price of hardware firewall",vol:20,from:1,to:1,d:0},{kw:"physical firewall prices",vol:10,from:1,to:1,d:0},{kw:"layer 3 firewall",vol:70,from:62,to:0,d:-99},{kw:"cheap firewall",vol:20,from:29,to:0,d:-99},{kw:"firewall price comparison",vol:30,from:1,to:21,d:-20},{kw:"how much is a network firewall",vol:20,from:1,to:21,d:-20},{kw:"business firewall solutions",vol:50,from:4,to:22,d:-18},{kw:"affordable firewall",vol:20,from:6,to:24,d:-18},{kw:"small business firewall",vol:720,from:1,to:6,d:-5},{kw:"next generation application firewall",vol:30,from:4,to:5,d:-1}],
  },
  'Zero Trust': {
    TOFU: [{kw:"ztna security",vol:260,from:6,to:1,d:5},{kw:"zero trust",vol:9900,from:10,to:9,d:1},{kw:"zero trust security",vol:5400,from:1,to:1,d:0},{kw:"zero trust network access",vol:2900,from:1,to:1,d:0},{kw:"what is zero trust",vol:2400,from:8,to:8,d:0},{kw:"zero trust network",vol:1900,from:1,to:1,d:0},{kw:"what is zero trust security",vol:1600,from:1,to:1,d:0},{kw:"zero trust model",vol:1300,from:1,to:1,d:0},{kw:"zero trust security model",vol:1300,from:1,to:1,d:0},{kw:"what is zero trust architecture",vol:1300,from:1,to:1,d:0},{kw:"zero trust access",vol:720,from:1,to:1,d:0},{kw:"what is zero trust network access",vol:720,from:1,to:1,d:0},{kw:"zero trust networking",vol:590,from:1,to:1,d:0},{kw:"VPN vs ZTNA",vol:140,from:1,to:1,d:0},{kw:"what is zero trust networking",vol:70,from:1,to:1,d:0},{kw:"zero trust architecture",vol:6600,from:1,to:22,d:-21},{kw:"zero trust edge",vol:260,from:1,to:3,d:-2},{kw:"VPN to ZTNA",vol:30,from:1,to:2,d:-1}],
    MOFU: [{kw:"How to migrate from VPN to ZTNA",vol:30,from:1,to:2,d:-1}],
    BOFU: [{kw:"ztna",vol:5400,from:1,to:1,d:0}],
  },
  'SD-WAN': {
    TOFU: [{kw:"managed service sd wan",vol:210,from:0,to:2,d:99},{kw:"sd wan software",vol:140,from:0,to:21,d:99},{kw:"sd wan appliances",vol:50,from:0,to:36,d:99},{kw:"what is sd wan",vol:1900,from:30,to:1,d:29},{kw:"sd wan managed services",vol:880,from:34,to:7,d:27},{kw:"sd wan lte",vol:70,from:32,to:5,d:27},{kw:"sd wan providers",vol:590,from:37,to:16,d:21},{kw:"sd wan brands",vol:30,from:15,to:2,d:13},{kw:"wan cost",vol:50,from:24,to:13,d:11},{kw:"sd wan lan",vol:30,from:28,to:23,d:5},{kw:"sd wan explanation",vol:110,from:5,to:1,d:4},{kw:"sd wan device",vol:210,from:4,to:1,d:3},{kw:"sdwan explained",vol:40,from:4,to:1,d:3},{kw:"sd wan replace mpls",vol:40,from:4,to:1,d:3},{kw:"sd wan software defined wan",vol:20,from:4,to:1,d:3},{kw:"software defined wan",vol:1600,from:3,to:1,d:2},{kw:"sd wan meaning",vol:1300,from:3,to:1,d:2},{kw:"definition sd wan",vol:50,from:3,to:1,d:2},{kw:"sd wan for enterprise",vol:50,from:5,to:3,d:2},{kw:"sd wan pricing model",vol:40,from:3,to:1,d:2},{kw:"sd wan what is it",vol:30,from:3,to:1,d:2},{kw:"sd wan software defined wide area network",vol:30,from:3,to:1,d:2},{kw:"sd wan as a service pricing",vol:30,from:6,to:4,d:2},{kw:"sd wan appliance",vol:210,from:10,to:9,d:1},{kw:"wan",vol:33100,from:1,to:1,d:0},{kw:"sd wan",vol:6600,from:1,to:1,d:0},{kw:"sd-wan",vol:6600,from:1,to:1,d:0},{kw:"sdwan",vol:6600,from:1,to:1,d:0},{kw:"wan definition",vol:6600,from:1,to:1,d:0},{kw:"wide area network",vol:2900,from:1,to:1,d:0},{kw:"what is sd-wan",vol:2400,from:1,to:1,d:0},{kw:"sd wan solutions",vol:1600,from:1,to:1,d:0},{kw:"sd wan vs mpls",vol:880,from:1,to:1,d:0},{kw:"sd wan benefits",vol:480,from:1,to:1,d:0},{kw:"managed sd wan solutions",vol:480,from:0,to:0,d:0},{kw:"sd wan definition",vol:390,from:1,to:1,d:0},{kw:"sd wan technology",vol:390,from:1,to:1,d:0},{kw:"benefits of sd wan",vol:260,from:1,to:1,d:0},{kw:"wan aggregation",vol:260,from:1,to:1,d:0},{kw:"sd wan router",vol:260,from:0,to:0,d:0},{kw:"software defined wide area network",vol:260,from:1,to:1,d:0},{kw:"sdn wan",vol:260,from:1,to:1,d:0},{kw:"what is wan aggregation",vol:110,from:1,to:1,d:0},{kw:"sd wan comparison",vol:110,from:9,to:9,d:0},{kw:"mpls to sd wan",vol:90,from:1,to:1,d:0},{kw:"wan security issues",vol:90,from:5,to:5,d:0},{kw:"sd wan with mpls",vol:90,from:1,to:1,d:0},{kw:"sd wan overview",vol:70,from:1,to:1,d:0},{kw:"sd wan security concerns",vol:50,from:1,to:1,d:0},{kw:"what does sd wan mean",vol:50,from:1,to:1,d:0},{kw:"diy sd wan",vol:50,from:1,to:1,d:0},{kw:"difference between sdn and sd wan",vol:50,from:1,to:1,d:0},{kw:"sd wan capabilities",vol:40,from:3,to:3,d:0},{kw:"wan sd wan",vol:40,from:18,to:18,d:0},{kw:"mpls vs hybrid wan",vol:40,from:2,to:2,d:0},{kw:"sd wan vs. mpls",vol:30,from:1,to:1,d:0},{kw:"sdn wan vs mpls",vol:30,from:1,to:1,d:0},{kw:"sd wan vs vpls",vol:30,from:3,to:3,d:0},{kw:"difference between sd wan and wan",vol:30,from:6,to:6,d:0},{kw:"sdn wan solutions",vol:20,from:1,to:1,d:0},{kw:"sd wan enterprise edition",vol:20,from:2,to:2,d:0},{kw:"sd wan explained",vol:720,from:1,to:21,d:-20},{kw:"sdn in the wan",vol:140,from:3,to:22,d:-19},{kw:"sd wan requirements",vol:90,from:5,to:24,d:-19},{kw:"define sd wan",vol:70,from:1,to:20,d:-19},{kw:"sd wan security features",vol:110,from:5,to:22,d:-17},{kw:"is sd wan better than mpls",vol:90,from:4,to:21,d:-17},{kw:"sd wan vs mpls cost comparison",vol:90,from:3,to:20,d:-17},{kw:"managed sd wan",vol:1000,from:4,to:20,d:-16},{kw:"sd wan access",vol:30,from:10,to:26,d:-16},{kw:"sd wan aggregation",vol:30,from:1,to:17,d:-16},{kw:"sd wan price list",vol:20,from:10,to:26,d:-16},{kw:"diy vs managed sd wan",vol:70,from:2,to:17,d:-15},{kw:"why use sd wan",vol:30,from:1,to:16,d:-15},{kw:"difference between wan and sd wan",vol:30,from:7,to:21,d:-14},{kw:"sd wan connectivity",vol:30,from:2,to:15,d:-13},{kw:"sd wan price comparison",vol:30,from:9,to:22,d:-13},{kw:"sd wan ready",vol:20,from:17,to:30,d:-13},{kw:"sd-wan aggregation",vol:20,from:1,to:14,d:-13},{kw:"sd wan data center",vol:30,from:12,to:23,d:-11},{kw:"sd wan cost calculator",vol:20,from:3,to:14,d:-11},{kw:"wan providers",vol:110,from:32,to:40,d:-8},{kw:"sd wan vs firewall",vol:30,from:1,to:8,d:-7},{kw:"sd wan pricing",vol:170,from:1,to:6,d:-5},{kw:"sd wan over mpls",vol:170,from:4,to:9,d:-5},{kw:"sd wan features comparison",vol:20,from:5,to:10,d:-5},{kw:"sd wan cost savings",vol:70,from:2,to:6,d:-4},{kw:"why is sd wan important",vol:50,from:1,to:5,d:-4},{kw:"what is wan",vol:2900,from:1,to:4,d:-3},{kw:"what is sd wan and how does it work",vol:30,from:1,to:4,d:-3},{kw:"sd wan cost",vol:210,from:1,to:3,d:-2},{kw:"whats sd wan",vol:30,from:1,to:3,d:-2},{kw:"sdn sd wan",vol:20,from:1,to:3,d:-2},{kw:"what is managed sd wan",vol:140,from:1,to:2,d:-1},{kw:"sd wan security issues",vol:40,from:4,to:5,d:-1},{kw:"sd wan concept",vol:30,from:1,to:2,d:-1},{kw:"what is the difference between wan and mpls",vol:30,from:2,to:3,d:-1},{kw:"wan sdn",vol:20,from:2,to:3,d:-1}],
    MOFU: [{kw:"sd wan vendors",vol:390,from:0,to:14,d:99},{kw:"sd wan visibility",vol:70,from:0,to:64,d:99},{kw:"business sd wan",vol:140,from:47,to:24,d:23},{kw:"cloud sd wan",vol:140,from:22,to:4,d:18},{kw:"sd wan automation",vol:70,from:52,to:35,d:17},{kw:"sd wan security measures",vol:10,from:6,to:1,d:5},{kw:"sd wan solutions with dynamic routing",vol:30,from:5,to:1,d:4},{kw:"sd wan security measure",vol:20,from:5,to:4,d:1},{kw:"sd wan security",vol:720,from:1,to:1,d:0},{kw:"sd wan advantages",vol:210,from:1,to:1,d:0},{kw:"advantages of sd wan",vol:70,from:1,to:1,d:0},{kw:"sd wan application performance",vol:70,from:4,to:4,d:0},{kw:"leading sd wan vendors",vol:50,from:0,to:0,d:0},{kw:"sd wan bandwidth",vol:40,from:1,to:1,d:0},{kw:"fully managed sd wan",vol:320,from:26,to:0,d:-99},{kw:"best sd wan providers",vol:90,from:53,to:0,d:-99},{kw:"best sd wan vendors",vol:90,from:17,to:0,d:-99},{kw:"cloud managed sd wan",vol:110,from:26,to:92,d:-66},{kw:"sd wan fec",vol:20,from:1,to:9,d:-8},{kw:"sd wan leaders",vol:90,from:1,to:6,d:-5},{kw:"wan security risks",vol:70,from:4,to:7,d:-3},{kw:"wan security measures",vol:70,from:6,to:7,d:-1}],
    BOFU: [{kw:"sd wan vendors comparison",vol:90,from:0,to:44,d:99},{kw:"sd wan and cloud",vol:20,from:20,to:7,d:13},{kw:"sd wan for small business",vol:170,from:2,to:2,d:0},{kw:"top sd wan providers",vol:110,from:0,to:0,d:0},{kw:"top sd wan vendors",vol:70,from:0,to:0,d:0},{kw:"sd wan hardware vendors",vol:30,from:0,to:0,d:0},{kw:"best sd wan",vol:90,from:62,to:0,d:-99},{kw:"small business wan",vol:30,from:1,to:21,d:-20},{kw:"sd wan multi cloud",vol:30,from:4,to:21,d:-17},{kw:"sd wan companies",vol:210,from:17,to:23,d:-6}],
  },
  'AI Cybersecurity': {
    TOFU: [{kw:"ai data center",vol:5400,from:0,to:18,d:99},{kw:"ai cybersecurity risks",vol:1600,from:0,to:27,d:99},{kw:"artificial intelligence risk management",vol:140,from:0,to:56,d:99},{kw:"risks of ai in cybersecurity",vol:110,from:0,to:25,d:99},{kw:"what does aiops stand for",vol:50,from:0,to:38,d:99},{kw:"what is aiops",vol:1900,from:22,to:1,d:21},{kw:"ai security threats",vol:320,from:19,to:1,d:18},{kw:"AI security",vol:6600,from:22,to:9,d:13},{kw:"aiops meaning",vol:140,from:28,to:15,d:13},{kw:"ai security risk",vol:320,from:5,to:1,d:4},{kw:"deepfake ai",vol:5400,from:4,to:1,d:3},{kw:"what is ai security",vol:720,from:4,to:1,d:3},{kw:"deepfake ai examples",vol:0,from:7,to:5,d:2},{kw:"AI in cybersecurity",vol:22200,from:1,to:1,d:0},{kw:"ai governance",vol:8100,from:0,to:0,d:0},{kw:"ai cybersecurity",vol:4400,from:1,to:1,d:0},{kw:"frontier ai",vol:3600,from:0,to:0,d:0},{kw:"ai governance framework",vol:2900,from:0,to:0,d:0},{kw:"ai adoption",vol:2400,from:1,to:1,d:0},{kw:"what is an ai data center",vol:2400,from:1,to:1,d:0},{kw:"ai deepfakes",vol:2400,from:1,to:1,d:0},{kw:"agentic ai security",vol:1000,from:0,to:0,d:0},{kw:"cybersecurity and ai",vol:1000,from:1,to:1,d:0},{kw:"ai red teaming",vol:880,from:1,to:1,d:0},{kw:"ai security definition",vol:720,from:1,to:1,d:0},{kw:"ai cybersecurity threats",vol:480,from:12,to:12,d:0},{kw:"Artificial intelligence in cybersecurity",vol:390,from:1,to:1,d:0},{kw:"role of ai in cybersecurity",vol:260,from:1,to:1,d:0},{kw:"ai adoption by industry",vol:260,from:0,to:0,d:0},{kw:"ai adoption statistics",vol:260,from:0,to:0,d:0},{kw:"aiops definition",vol:140,from:0,to:0,d:0},{kw:"ai adoption rate",vol:140,from:0,to:0,d:0},{kw:"what is ai adoption",vol:90,from:1,to:1,d:0},{kw:"what is deepfake ai",vol:70,from:1,to:1,d:0},{kw:"what is ai risk management",vol:50,from:0,to:0,d:0},{kw:"ai security examples",vol:40,from:1,to:1,d:0},{kw:"what is ai in cybersecurity",vol:20,from:1,to:1,d:0},{kw:"what industries benefit most from ai adoption",vol:0,from:0,to:0,d:0},{kw:"what frameworks guide successful ai adoption",vol:0,from:0,to:0,d:0},{kw:"ai prompt injection",vol:590,from:1,to:0,d:-99},{kw:"Generative ai security",vol:720,from:1,to:37,d:-36},{kw:"artificial intelligence data center",vol:480,from:1,to:32,d:-31},{kw:"deepfakes meaning",vol:1000,from:1,to:23,d:-22},{kw:"what are ai data centers",vol:1000,from:1,to:22,d:-21},{kw:"how do deepfakes work",vol:720,from:15,to:32,d:-17},{kw:"what does deepfake mean",vol:720,from:1,to:18,d:-17},{kw:"ai cybersecurity incidents",vol:140,from:2,to:18,d:-16},{kw:"what are aiops",vol:50,from:15,to:31,d:-16},{kw:"aiops",vol:5400,from:14,to:25,d:-11},{kw:"how ai security works",vol:0,from:1,to:10,d:-9},{kw:"how can generative ai be used in cybersecurity",vol:880,from:1,to:7,d:-6}],
    MOFU: [{kw:"generative ai for cybersecurity",vol:170,from:0,to:37,d:99},{kw:"ai based security system",vol:90,from:0,to:1,d:99},{kw:"aiops capabilities",vol:90,from:0,to:40,d:99},{kw:"ai data center architecture",vol:110,from:45,to:16,d:29},{kw:"aiops monitoring",vol:140,from:65,to:40,d:25},{kw:"generative ai adoption",vol:210,from:12,to:2,d:10},{kw:"ai adoption framework",vol:1000,from:24,to:18,d:6},{kw:"ai secops",vol:110,from:7,to:1,d:6},{kw:"ai based security",vol:70,from:6,to:1,d:5},{kw:"deepfake attacks",vol:90,from:5,to:1,d:4},{kw:"deepfake ai technology",vol:20,from:4,to:1,d:3},{kw:"aiops network",vol:70,from:11,to:10,d:1},{kw:"aiops networking",vol:50,from:7,to:6,d:1},{kw:"ai in risk management",vol:3600,from:0,to:0,d:0},{kw:"ai risk management",vol:3600,from:0,to:0,d:0},{kw:"ai risk management framework",vol:1300,from:0,to:0,d:0},{kw:"ai risk assessment",vol:1300,from:0,to:0,d:0},{kw:"ai for cybersecurity",vol:880,from:1,to:1,d:0},{kw:"ai operations",vol:880,from:0,to:0,d:0},{kw:"enterprise ai adoption",vol:720,from:0,to:0,d:0},{kw:"ai adoption challenges",vol:720,from:0,to:0,d:0},{kw:"generative ai in cybersecurity",vol:480,from:14,to:14,d:0},{kw:"ai adoption strategy",vol:480,from:1,to:1,d:0},{kw:"ai siem",vol:390,from:0,to:0,d:0},{kw:"ai security best practices",vol:390,from:0,to:0,d:0},{kw:"artificial intelligence for it operations",vol:390,from:1,to:1,d:0},{kw:"artificial intelligence risk management framework",vol:320,from:0,to:0,d:0},{kw:"ai and risk management",vol:260,from:0,to:0,d:0},{kw:"ai for risk management",vol:260,from:0,to:0,d:0},{kw:"ai powered cybersecurity",vol:210,from:1,to:1,d:0},{kw:"strategic ai adoption",vol:170,from:1,to:1,d:0},{kw:"ai adoption in healthcare",vol:170,from:0,to:0,d:0},{kw:"ai powered security",vol:110,from:3,to:3,d:0},{kw:"ai model risk management",vol:90,from:0,to:0,d:0},{kw:"enterprise ai adoption trends",vol:90,from:0,to:0,d:0},{kw:"ai impact on data centers",vol:70,from:0,to:0,d:0},{kw:"aiops trends",vol:70,from:0,to:0,d:0},{kw:"adoption of ai for cybersecurity",vol:70,from:1,to:1,d:0},{kw:"ai adoption in financial services",vol:70,from:0,to:0,d:0},{kw:"ai automation in cybersecurity",vol:50,from:1,to:1,d:0},{kw:"enterprise ai adoption challenges",vol:50,from:0,to:0,d:0},{kw:"ai and machine learning for risk management",vol:40,from:0,to:0,d:0},{kw:"ai data center trends",vol:30,from:0,to:0,d:0},{kw:"ai security benefits",vol:20,from:1,to:1,d:0},{kw:"ai security for enterprise",vol:20,from:0,to:0,d:0},{kw:"ai security use case",vol:0,from:18,to:18,d:0},{kw:"ai cybersecurity applications",vol:0,from:1,to:1,d:0},{kw:"data center challenges in ai",vol:0,from:0,to:0,d:0},{kw:"deepfake ai best practices",vol:0,from:0,to:0,d:0},{kw:"deepfake ai challenges",vol:0,from:0,to:0,d:0},{kw:"deepfake ai risks",vol:0,from:4,to:4,d:0},{kw:"ai security frameworks",vol:140,from:34,to:0,d:-99},{kw:"enterprise aiops",vol:110,from:1,to:0,d:-99},{kw:"ai security challenges",vol:40,from:1,to:0,d:-99},{kw:"preparing for ai adoption",vol:210,from:3,to:22,d:-19},{kw:"benefits of ai data center",vol:40,from:1,to:16,d:-15},{kw:"ai security monitoring",vol:260,from:9,to:22,d:-13},{kw:"ai driven security",vol:210,from:17,to:23,d:-6},{kw:"aiops framework",vol:90,from:21,to:25,d:-4},{kw:"artificial intelligence security",vol:720,from:6,to:7,d:-1},{kw:"ai security systems",vol:390,from:5,to:6,d:-1}],
    BOFU: [{kw:"list of ai cybersecurity tools",vol:2400,from:47,to:21,d:26},{kw:"ai security platfrom",vol:0,from:54,to:36,d:18},{kw:"ai cyber security companies",vol:170,from:17,to:1,d:16},{kw:"ai cybersecurity tools",vol:2400,from:1,to:1,d:0},{kw:"ai security solutions",vol:1600,from:1,to:1,d:0},{kw:"aiops platforms",vol:1300,from:0,to:0,d:0},{kw:"ai cybersecurity solutions",vol:880,from:1,to:1,d:0},{kw:"ai cybersecurity certification",vol:590,from:0,to:0,d:0},{kw:"ai cybersecurity software",vol:210,from:1,to:1,d:0},{kw:"ai security providers",vol:20,from:1,to:1,d:0},{kw:"gen ai security solutions",vol:0,from:0,to:0,d:0},{kw:"ai security vendor",vol:0,from:1,to:1,d:0},{kw:"which are the top ai security companies",vol:0,from:1,to:1,d:0},{kw:"what companies provide ai security platforms",vol:0,from:1,to:1,d:0},{kw:"gen ai security platform",vol:0,from:0,to:0,d:0},{kw:"aiops tools",vol:1900,from:15,to:0,d:-99},{kw:"ai security companies",vol:720,from:1,to:0,d:-99},{kw:"aiops software",vol:590,from:25,to:0,d:-99},{kw:"aiops vendors",vol:210,from:68,to:0,d:-99},{kw:"ai security software",vol:590,from:13,to:25,d:-12},{kw:"ai cybersecurity providers",vol:10,from:25,to:33,d:-8},{kw:"top ai cybersecurity vendors",vol:10,from:7,to:14,d:-7},{kw:"best ai security companies",vol:20,from:1,to:7,d:-6},{kw:"ai security services",vol:90,from:10,to:11,d:-1}],
  },
  'OT Security': {
    TOFU: [{kw:"ics/ot",vol:140,from:35,to:14,d:21},{kw:"iot and ot security",vol:40,from:31,to:15,d:16},{kw:"iot/ot security",vol:70,from:12,to:1,d:11},{kw:"ot security monitoring",vol:110,from:24,to:14,d:10},{kw:"ot security tools",vol:170,from:5,to:1,d:4},{kw:"ot security standards",vol:90,from:4,to:2,d:2},{kw:"iot security",vol:5400,from:1,to:1,d:0},{kw:"ot cybersecurity",vol:1600,from:1,to:1,d:0},{kw:"operational technology cyber security",vol:390,from:1,to:1,d:0},{kw:"securing ot networks",vol:70,from:1,to:1,d:0},{kw:"manufacturing ot security",vol:50,from:3,to:3,d:0},{kw:"cyber security for operational technology",vol:40,from:1,to:1,d:0},{kw:"ot vulnerabilities",vol:140,from:15,to:90,d:-75},{kw:"ot security framework",vol:70,from:1,to:10,d:-9}],
    MOFU: [{kw:"industrial ot cybersecurity",vol:70,from:0,to:49,d:99},{kw:"ot/ics cybersecurity",vol:70,from:108,to:15,d:93},{kw:"ot network architecture",vol:90,from:24,to:23,d:1},{kw:"operational technology networks",vol:50,from:4,to:3,d:1},{kw:"ot security",vol:3600,from:1,to:1,d:0},{kw:"what is ot security",vol:1000,from:1,to:1,d:0},{kw:"operational technology security",vol:1000,from:1,to:1,d:0},{kw:"what is operational technology",vol:720,from:1,to:1,d:0},{kw:"ot technology",vol:480,from:1,to:1,d:0},{kw:"ot security meaning",vol:390,from:1,to:1,d:0},{kw:"ot environment",vol:390,from:1,to:1,d:0},{kw:"ot devices",vol:390,from:1,to:1,d:0},{kw:"what is ot cybersecurity",vol:140,from:1,to:1,d:0},{kw:"operational technology definition",vol:140,from:1,to:1,d:0},{kw:"ot infrastructure",vol:140,from:1,to:1,d:0},{kw:"what is ot in cybersecurity",vol:90,from:1,to:1,d:0},{kw:"ot networking",vol:90,from:1,to:1,d:0},{kw:"operational technology examples",vol:70,from:1,to:1,d:0},{kw:"ot security architecture",vol:50,from:2,to:2,d:0},{kw:"what does ot stand for in cyber security",vol:40,from:1,to:1,d:0},{kw:"operational technology network",vol:40,from:4,to:4,d:0},{kw:"ot cyber security framework",vol:70,from:3,to:24,d:-21},{kw:"ot it security",vol:30,from:1,to:21,d:-20},{kw:"ot network security",vol:390,from:1,to:5,d:-4}],
    BOFU: [{kw:"ot cyber security companies",vol:140,from:0,to:12,d:99},{kw:"ot security company",vol:140,from:5,to:4,d:1},{kw:"ot security solutions",vol:480,from:1,to:1,d:0},{kw:"best ot security for critical infrastructure",vol:140,from:1,to:1,d:0},{kw:"ot security assessment",vol:90,from:1,to:1,d:0},{kw:"ot cybersecurity vendors",vol:90,from:18,to:18,d:0},{kw:"best ot security companies",vol:70,from:0,to:0,d:0},{kw:"ot security companies",vol:210,from:17,to:19,d:-2}],
  },
  'Quantum Security': {
    TOFU: [{kw:"what is PQC",vol:170,from:0,to:1,d:99},{kw:"post quantum readiness",vol:20,from:0,to:45,d:99},{kw:"quantum cryptography",vol:18100,from:39,to:33,d:6},{kw:"what is QKD",vol:40,from:7,to:6,d:1},{kw:"quantum computing",vol:74000,from:0,to:0,d:0},{kw:"post-quantum cryptography",vol:8100,from:1,to:1,d:0},{kw:"quantum encryption",vol:2900,from:1,to:1,d:0},{kw:"quantum key distribution",vol:1000,from:1,to:1,d:0},{kw:"HNDL",vol:1000,from:0,to:0,d:0},{kw:"quantum security",vol:880,from:1,to:1,d:0},{kw:"QKD",vol:880,from:1,to:1,d:0},{kw:"q-day",vol:720,from:1,to:1,d:0},{kw:"quantum day",vol:480,from:0,to:0,d:0},{kw:"quantum safe encryption",vol:390,from:1,to:1,d:0},{kw:"harvest now decrypt later",vol:210,from:0,to:0,d:0},{kw:"NIST PQC standards",vol:70,from:0,to:0,d:0},{kw:"what is q-day",vol:30,from:1,to:1,d:0},{kw:"Shor's and Grover's Algorithms",vol:20,from:1,to:1,d:0},{kw:"what is HNDL",vol:20,from:0,to:0,d:0},{kw:"Quantum-Safe Security",vol:10,from:1,to:1,d:0},{kw:"what is quatum security",vol:0,from:1,to:1,d:0},{kw:"Cryptographic Agility",vol:140,from:1,to:0,d:-99},{kw:"quantum readiness",vol:110,from:21,to:43,d:-22},{kw:"Crypto-Agility",vol:70,from:17,to:25,d:-8},{kw:"quantum computing security",vol:170,from:1,to:5,d:-4},{kw:"quantum security solutions",vol:40,from:1,to:4,d:-3},{kw:"PQC",vol:1900,from:24,to:26,d:-2}],
    MOFU: [{kw:"Quantum-Risk Assessment",vol:20,from:1,to:1,d:0}],
    BOFU: [],
  },
  'SASE': {
    TOFU: [{kw:"Sase Services",vol:390,from:2,to:1,d:1},{kw:"Sase",vol:14800,from:1,to:1,d:0},{kw:"Sase Meaning",vol:4400,from:1,to:1,d:0},{kw:"What Is Sase",vol:3600,from:1,to:1,d:0},{kw:"Secure Access Service Edge",vol:2900,from:1,to:1,d:0},{kw:"What Is Sse",vol:1900,from:0,to:0,d:0},{kw:"Sase Solutions",vol:1900,from:1,to:1,d:0},{kw:"Security Service Edge",vol:1600,from:1,to:1,d:0},{kw:"Sase Architecture",vol:1300,from:1,to:1,d:0},{kw:"Sase Definition",vol:1000,from:1,to:1,d:0},{kw:"Sase Vs Sse",vol:1000,from:1,to:1,d:0},{kw:"Sase Benefits",vol:720,from:1,to:1,d:0},{kw:"Secure Access Service Edge SASE",vol:480,from:1,to:1,d:0},{kw:"Sase Platform",vol:480,from:1,to:1,d:0},{kw:"Sase Vs Casb",vol:390,from:1,to:1,d:0},{kw:"Sase Network",vol:320,from:1,to:1,d:0},{kw:"Sase Provider",vol:320,from:1,to:1,d:0},{kw:"Sase Vendor",vol:320,from:1,to:1,d:0},{kw:"Sase Network Security",vol:260,from:1,to:1,d:0},{kw:"Sase Vs Ztna",vol:170,from:1,to:1,d:0},{kw:"Sase Vs Vpn",vol:170,from:1,to:1,d:0},{kw:"Sd-Wan Vs Sase",vol:90,from:1,to:1,d:0},{kw:"How Does Sase Work",vol:50,from:1,to:1,d:0},{kw:"Sase Providers",vol:480,from:1,to:21,d:-20},{kw:"Sase Service Provider",vol:30,from:1,to:7,d:-6},{kw:"Sse",vol:14800,from:10,to:12,d:-2}],
    MOFU: [{kw:"Ai Sase",vol:40,from:1,to:1,d:0},{kw:"Sovereign Sase",vol:40,from:1,to:1,d:0}],
    BOFU: [{kw:"Ai Powered Sase",vol:30,from:14,to:12,d:2},{kw:"Single Vendor Sase",vol:170,from:4,to:6,d:-2}],
  },
};



const GL_PERIOD_PREV = 'Oct 11–Oct 17', GL_PERIOD_CUR = 'Oct 18–Oct 24';
const GL_SECTIONS: {title:string;icon:string;col:string;wowPct:string;wowAbs:string;items:{label:string;href:string|null;prev:string;curr:string;chg:string;pct:string}[];total:{prev:string;curr:string;chg:string;pct:string};intlFor?:string}[] = 
[
 {
  "title": "Branded Traffic (GSC) — Top Gaining URLs",
  "icon": "🔍",
  "col": "URL",
  "wowPct": "+23.42%",
  "wowAbs": "+27,659",
  "items": [
   {
    "label": "fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "href": "https://www.fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "prev": "0",
    "curr": "8,647",
    "chg": "+8,647",
    "pct": "+864700%"
   },
   {
    "label": "fortinet.com",
    "href": "https://www.fortinet.com/",
    "prev": "7,131",
    "curr": "9,207",
    "chg": "+2,076",
    "pct": "+29.1%"
   },
   {
    "label": "fortinet.com/support/product-downloads",
    "href": "https://www.fortinet.com/support/product-downloads",
    "prev": "36,550",
    "curr": "38,055",
    "chg": "+1,505",
    "pct": "+4.1%"
   }
  ],
  "total": {
   "prev": "43,681",
   "curr": "55,909",
   "chg": "+12,228",
   "pct": "+28.0%"
  }
 },
 {
  "title": "International Markets — Top Gaining URLs",
  "icon": "🌍",
  "col": "URL",
  "wowPct": "+51.7%",
  "wowAbs": "+5,066",
  "items": [
   {
    "label": "fortinet.com/jp/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "href": "https://www.fortinet.com/jp/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "prev": "0",
    "curr": "2,987",
    "chg": "+2,987",
    "pct": "+298700%"
   },
   {
    "label": "fortinet.com/lat/support/product-downloads",
    "href": "https://www.fortinet.com/lat/support/product-downloads",
    "prev": "9,808",
    "curr": "11,887",
    "chg": "+2,079",
    "pct": "+21.2%"
   }
  ],
  "total": {
   "prev": "9,808",
   "curr": "14,874",
   "chg": "+5,066",
   "pct": "+51.7%"
  },
  "intlFor": "Branded Traffic (GSC) — Top Gaining URLs"
 },
 {
  "title": "Branded Traffic (GSC) — Top Gaining Keywords",
  "icon": "🔑",
  "col": "Keyword",
  "wowPct": "+23.42%",
  "wowAbs": "+27,659",
  "items": [
   {
    "label": "fortinet",
    "href": null,
    "prev": "9,389",
    "curr": "13,715",
    "chg": "+4,326",
    "pct": "+46.1%"
   },
   {
    "label": "fortinet vulnerability",
    "href": null,
    "prev": "19",
    "curr": "1,479",
    "chg": "+1,460",
    "pct": "+7684.2%"
   },
   {
    "label": "fortigate",
    "href": null,
    "prev": "1,651",
    "curr": "2,581",
    "chg": "+930",
    "pct": "+56.3%"
   }
  ],
  "total": {
   "prev": "11,059",
   "curr": "17,775",
   "chg": "+6,716",
   "pct": "+60.7%"
  }
 },
 {
  "title": "International Markets — Top Gaining Keywords",
  "icon": "🌐",
  "col": "Keyword",
  "wowPct": "+9.1%",
  "wowAbs": "+2,420",
  "items": [
   {
    "label": "forticlient vpn",
    "href": null,
    "prev": "14,306",
    "curr": "15,802",
    "chg": "+1,496",
    "pct": "+10.5%"
   },
   {
    "label": "forticlient",
    "href": null,
    "prev": "12,205",
    "curr": "13,129",
    "chg": "+924",
    "pct": "+7.6%"
   }
  ],
  "total": {
   "prev": "26,511",
   "curr": "28,931",
   "chg": "+2,420",
   "pct": "+9.1%"
  },
  "intlFor": "Branded Traffic (GSC) — Top Gaining Keywords"
 },
 {
  "title": "/cyberglossary (GA) — Top Gaining URLs",
  "icon": "📚",
  "col": "URL",
  "wowPct": "+3.59%",
  "wowAbs": "+1,223",
  "items": [
   {
    "label": "fortinet.com/resources/cyberglossary/recent-cyber-attacks",
    "href": "https://www.fortinet.com/resources/cyberglossary/recent-cyber-attacks",
    "prev": "553",
    "curr": "968",
    "chg": "+415",
    "pct": "+75.0%"
   },
   {
    "label": "fortinet.com/resources/cyberglossary/what-is-hacking",
    "href": "https://www.fortinet.com/resources/cyberglossary/what-is-hacking",
    "prev": "1,327",
    "curr": "1,406",
    "chg": "+79",
    "pct": "+6.0%"
   },
   {
    "label": "fortinet.com/resources/cyberglossary/proxy-server",
    "href": "https://www.fortinet.com/resources/cyberglossary/proxy-server",
    "prev": "1,824",
    "curr": "1,899",
    "chg": "+75",
    "pct": "+4.1%"
   }
  ],
  "total": {
   "prev": "3,704",
   "curr": "4,273",
   "chg": "+569",
   "pct": "+15.4%"
  }
 },
 {
  "title": "International Markets · /cyberglossary — Top Gaining URLs",
  "icon": "🌍",
  "col": "URL",
  "wowPct": "+292.2%",
  "wowAbs": "+526",
  "items": [
   {
    "label": "fortinet.com/jp/resources/cyberglossary/vulnerability-disclosure",
    "href": "https://www.fortinet.com/jp/resources/cyberglossary/vulnerability-disclosure",
    "prev": "39",
    "curr": "274",
    "chg": "+235",
    "pct": "+602.6%"
   },
   {
    "label": "fortinet.com/jp/resources/cyberglossary/what-is-globalip",
    "href": "https://www.fortinet.com/jp/resources/cyberglossary/what-is-globalip",
    "prev": "117",
    "curr": "266",
    "chg": "+149",
    "pct": "+127.4%"
   },
   {
    "label": "fortinet.com/jp/resources/cyberglossary/remote-code-execution",
    "href": "https://www.fortinet.com/jp/resources/cyberglossary/remote-code-execution",
    "prev": "24",
    "curr": "166",
    "chg": "+142",
    "pct": "+591.7%"
   }
  ],
  "total": {
   "prev": "180",
   "curr": "706",
   "chg": "+526",
   "pct": "+292.2%"
  },
  "intlFor": "/cyberglossary (GA) — Top Gaining URLs"
 },
 {
  "title": "/blog (GA) — Top Gaining URLs",
  "icon": "📝",
  "col": "URL",
  "wowPct": "+720.37%",
  "wowAbs": "+16,194",
  "items": [
   {
    "label": "fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "href": "https://www.fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "prev": "0",
    "curr": "11,958",
    "chg": "+11,958",
    "pct": "+1195800%"
   },
   {
    "label": "fortinet.com/blog/ciso-collective/update-on-fortinet-use-of-frontier-ai",
    "href": "https://www.fortinet.com/blog/ciso-collective/update-on-fortinet-use-of-frontier-ai",
    "prev": "29",
    "curr": "903",
    "chg": "+874",
    "pct": "+13500%"
   },
   {
    "label": "fortinet.com/blog",
    "href": "https://www.fortinet.com/blog",
    "prev": "80",
    "curr": "741",
    "chg": "+661",
    "pct": "+33.0%"
   }
  ],
  "total": {
   "prev": "109",
   "curr": "13,602",
   "chg": "+13,493",
   "pct": "+12378.9%"
  }
 },
 {
  "title": "/products (GA) — Top Gaining URLs",
  "icon": "📦",
  "col": "URL",
  "wowPct": "+18.54%",
  "wowAbs": "+2,555",
  "items": [
   {
    "label": "fortinet.com/products/next-generation-firewall",
    "href": "https://www.fortinet.com/products/next-generation-firewall",
    "prev": "1,994",
    "curr": "2,241",
    "chg": "+247",
    "pct": "+12.4%"
   },
   {
    "label": "fortinet.com/products/fortigate/fortios",
    "href": "https://www.fortinet.com/products/fortigate/fortios",
    "prev": "160",
    "curr": "300",
    "chg": "+140",
    "pct": "+87.5%"
   },
   {
    "label": "fortinet.com/products/endpoint-security/forticlient",
    "href": "https://www.fortinet.com/products/endpoint-security/forticlient",
    "prev": "1,766",
    "curr": "1,850",
    "chg": "+84",
    "pct": "+4.8%"
   }
  ],
  "total": {
   "prev": "3,920",
   "curr": "4,391",
   "chg": "+471",
   "pct": "+12.0%"
  }
 },
 {
  "title": "International Markets · /products — Top Gaining URLs",
  "icon": "🌍",
  "col": "URL",
  "wowPct": "+97.7%",
  "wowAbs": "+1,069",
  "items": [
   {
    "label": "fortinet.com/jp/products/next-generation-firewall",
    "href": "https://www.fortinet.com/jp/products/next-generation-firewall",
    "prev": "801",
    "curr": "1,494",
    "chg": "+693",
    "pct": "+86.5%"
   },
   {
    "label": "fortinet.com/jp/products/fortigate/fortios",
    "href": "https://www.fortinet.com/jp/products/fortigate/fortios",
    "prev": "103",
    "curr": "294",
    "chg": "+191",
    "pct": "+185.4%"
   },
   {
    "label": "fortinet.com/jp/products",
    "href": "https://www.fortinet.com/jp/products",
    "prev": "190",
    "curr": "375",
    "chg": "+185",
    "pct": "+97.4%"
   }
  ],
  "total": {
   "prev": "1,094",
   "curr": "2,163",
   "chg": "+1,069",
   "pct": "+97.7%"
  },
  "intlFor": "/products (GA) — Top Gaining URLs"
 },
 {
  "title": "/about-us (GA) — Top Gaining URLs",
  "icon": "🏢",
  "col": "URL",
  "wowPct": "+24.38%",
  "wowAbs": "+1,075",
  "items": [
   {
    "label": "fortinet.com/corporate/about-us/newsroom",
    "href": "https://www.fortinet.com/corporate/about-us/newsroom",
    "prev": "48",
    "curr": "147",
    "chg": "+99",
    "pct": "+206.3%"
   },
   {
    "label": "fortinet.com/corporate/about-us/contact-us",
    "href": "https://www.fortinet.com/corporate/about-us/contact-us",
    "prev": "516",
    "curr": "578",
    "chg": "+62",
    "pct": "+12.0%"
   },
   {
    "label": "fortinet.com/corporate/about-us/newsroom/press-releases",
    "href": "https://www.fortinet.com/corporate/about-us/newsroom/press-releases",
    "prev": "29",
    "curr": "77",
    "chg": "+48",
    "pct": "+165.5%"
   }
  ],
  "total": {
   "prev": "593",
   "curr": "802",
   "chg": "+209",
   "pct": "+35.2%"
  }
 },
 {
  "title": "International Markets · /about-us — Top Gaining URLs",
  "icon": "🌍",
  "col": "URL",
  "wowPct": "+133.7%",
  "wowAbs": "+587",
  "items": [
   {
    "label": "fortinet.com/jp/corporate/about-us/company",
    "href": "https://www.fortinet.com/jp/corporate/about-us/company",
    "prev": "297",
    "curr": "681",
    "chg": "+384",
    "pct": "+129.3%"
   },
   {
    "label": "fortinet.com/jp/corporate/about-us/about-us",
    "href": "https://www.fortinet.com/jp/corporate/about-us/about-us",
    "prev": "125",
    "curr": "257",
    "chg": "+132",
    "pct": "+105.6%"
   },
   {
    "label": "fortinet.com/jp/corporate/about-us/newsroom/press-releases",
    "href": "https://www.fortinet.com/jp/corporate/about-us/newsroom/press-releases",
    "prev": "17",
    "curr": "88",
    "chg": "+71",
    "pct": "+417.6%"
   }
  ],
  "total": {
   "prev": "439",
   "curr": "1,026",
   "chg": "+587",
   "pct": "+133.7%"
  },
  "intlFor": "/about-us (GA) — Top Gaining URLs"
 },
 {
  "title": "Direct (Relevant traffic) — Top Gaining URLs",
  "icon": "🧭",
  "col": "URL",
  "wowPct": "+45.24%",
  "wowAbs": "+40,587",
  "items": [
   {
    "label": "fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "href": "https://www.fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "prev": "0",
    "curr": "38,906",
    "chg": "+38,906",
    "pct": "+3890600%"
   },
   {
    "label": "fortinet.com/blog",
    "href": "https://www.fortinet.com/blog",
    "prev": "294",
    "curr": "1,109",
    "chg": "+815",
    "pct": "+277.2%"
   },
   {
    "label": "fortinet.com/support/contact",
    "href": "https://www.fortinet.com/support/contact",
    "prev": "2,194",
    "curr": "2,766",
    "chg": "+572",
    "pct": "+26.1%"
   }
  ],
  "total": {
   "prev": "2,488",
   "curr": "42,781",
   "chg": "+40,293",
   "pct": "+1619.5%"
  }
 },
 {
  "title": "Referrals (GA) — Top Gaining URLs",
  "icon": "🔗",
  "col": "URL",
  "wowPct": "+107.41%",
  "wowAbs": "+12,692",
  "items": [
   {
    "label": "fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "href": "https://www.fortinet.com/blog/ciso-collective/fortinet-releases-security-hardening-release-for-multiple-products",
    "prev": "0",
    "curr": "9,638",
    "chg": "+9,638",
    "pct": "+963800%"
   },
   {
    "label": "fortinet.com/blog/ciso-collective/update-on-fortinet-use-of-frontier-ai",
    "href": "https://www.fortinet.com/blog/ciso-collective/update-on-fortinet-use-of-frontier-ai",
    "prev": "13",
    "curr": "440",
    "chg": "+427",
    "pct": "+3284.6%"
   },
   {
    "label": "fortinet.com",
    "href": "https://www.fortinet.com/",
    "prev": "1,121",
    "curr": "1,477",
    "chg": "+356",
    "pct": "+31.8%"
   }
  ],
  "total": {
   "prev": "1,134",
   "curr": "11,555",
   "chg": "+10,421",
   "pct": "+919.0%"
  }
 }
];

const GlCard = ({s,extra}:{s:typeof GL_SECTIONS[number];extra?:typeof GL_SECTIONS[number]}) => {
  const grid = '1fr 140px 140px 90px 90px';
  const col = (v:string) => v.startsWith('-') ? '#D93025' : '#059669';
  const hd = {fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase' as const,letterSpacing:'.07em',textAlign:'right' as const};
  const mono = {fontFamily:"'DM Mono',monospace"};
  const renderBody = (sec:typeof GL_SECTIONS[number]) => (
    <>
      <div style={{display:'grid',gridTemplateColumns:grid,gap:8,padding:'6px 12px',marginBottom:2,borderBottom:'1px solid var(--border)'}}>
        <span style={{...hd,textAlign:'left'}}>{sec.col}</span>
        <span style={hd}>{GL_PERIOD_PREV}</span>
        <span style={hd}>{GL_PERIOD_CUR}</span>
        <span style={hd}>Change</span>
        <span style={hd}>% Change</span>
      </div>
      {sec.items.map((r,i)=>(
        <div key={i} style={{display:'grid',gridTemplateColumns:grid,gap:8,padding:'9px 12px',borderRadius:7,background:i%2===0?'var(--surface2)':'transparent',marginBottom:4,alignItems:'center'}}>
          {r.href
            ? <a href={r.href} target="_blank" rel="noopener noreferrer" style={{fontSize:11,fontWeight:700,color:'#1A56DB',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',textDecoration:'none',display:'block',cursor:'pointer',...mono}}>{r.label}</a>
            : <span style={{fontSize:11,fontWeight:700,color:'var(--text)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',...mono}}>{r.label}</span>}
          <span style={{fontSize:12,fontWeight:700,color:'var(--text)',textAlign:'right',...mono}}>{r.prev}</span>
          <span style={{fontSize:12,fontWeight:700,color:'var(--text)',textAlign:'right',...mono}}>{r.curr}</span>
          <span style={{fontSize:12,fontWeight:800,color:col(r.chg),textAlign:'right',...mono}}>{r.chg}</span>
          <span style={{fontSize:12,fontWeight:800,color:col(r.pct),textAlign:'right',...mono}}>{r.pct}</span>
        </div>
      ))}
      <div style={{display:'grid',gridTemplateColumns:grid,gap:8,padding:'9px 12px',borderTop:'2px solid var(--border)',marginTop:4,alignItems:'center'}}>
        <span style={{fontSize:11,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.05em'}}>Top {sec.items.length} Total</span>
        <span style={{fontSize:13,fontWeight:900,color:'var(--text)',textAlign:'right',...mono}}>{sec.total.prev}</span>
        <span style={{fontSize:13,fontWeight:900,color:'var(--text)',textAlign:'right',...mono}}>{sec.total.curr}</span>
        <span style={{fontSize:13,fontWeight:900,color:col(sec.total.chg),textAlign:'right',...mono}}>{sec.total.chg}</span>
        <span style={{fontSize:13,fontWeight:900,color:col(sec.total.pct),textAlign:'right',...mono}}>{sec.total.pct}</span>
      </div>
    </>
  );
  return (
    <div className="fn-card fn-full" style={{marginBottom:16}}>
      <div className="fn-card-head">
        <div className="fn-card-icon" style={{background:'rgba(124,58,237,.08)'}}>{s.icon}</div>
        <span className="fn-card-title">{s.title}</span>
        <span className="fn-card-meta">{GL_PERIOD_PREV} vs {GL_PERIOD_CUR}, 2026</span>
        <div style={{marginLeft:'auto',display:'flex',gap:16,alignItems:'center'}}>
          <div style={{textAlign:'right'}}>
            <div style={{fontSize:9,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.06em',fontWeight:700}}>WoW Change</div>
            <div style={{fontSize:13,fontWeight:900,color:col(s.wowPct),...mono}}>{s.wowPct} <span style={{fontSize:11,color:'var(--text3)',fontWeight:600}}>/ {s.wowAbs}</span></div>
          </div>
        </div>
      </div>
      {renderBody(s)}
      {extra && (
        <div style={{marginTop:18,paddingTop:14,borderTop:'1px dashed var(--border)'}}>
          <div style={{display:'flex',alignItems:'center',gap:8,padding:'0 12px 6px'}}>
            <span style={{fontSize:14}}>{extra.icon}</span>
            <span className="fn-card-title">{extra.title}</span>
            <span style={{marginLeft:'auto',fontSize:13,fontWeight:900,color:col(extra.wowPct),...mono}}>{extra.wowPct} <span style={{fontSize:11,color:'var(--text3)',fontWeight:600}}>/ {extra.wowAbs}</span></span>
          </div>
          {renderBody(extra)}
        </div>
      )}
    </div>
  );
};

const KW_FUNNEL_MAP: Record<string,'TOFU'|'MOFU'|'BOFU'> = {
  // NGFW — TOFU
  'what is a firewall':'TOFU','firewall':'TOFU','web application firewall':'TOFU',
  'firewalls':'TOFU','firewall configuration':'TOFU','hardware firewall':'TOFU',
  'network firewall':'TOFU','network firewall security':'TOFU','waf security':'TOFU',
  'what is enterprise firewall':'MOFU','ngfw definition':'MOFU',
  'advantages to next generation firewalls':'MOFU','next generation enterprise firewall':'MOFU',
  // NGFW — BOFU
  'ngfw':'BOFU','next generation firewall':'BOFU','firewall next generation':'BOFU',
  'next gen firewall':'BOFU','enterprise firewall':'BOFU','small business firewall':'BOFU',
  'business firewall':'BOFU','business firewall solutions':'BOFU','enterprise grade firewall':'BOFU',
  'firewall price':'BOFU','firewall cost':'BOFU','layer 3 firewall':'BOFU',
  'network firewall security price':'BOFU','network firewall price':'BOFU',
  'cheap firewall':'BOFU','firewall security price':'BOFU','nexgen firewall':'BOFU',
  'firewall price comparison':'BOFU','firewall security price in usa':'BOFU',
  'how much is a network firewall':'BOFU','low cost firewall':'BOFU',
  'physical firewall prices':'BOFU','next generation application firewall':'BOFU',
  'add a next generation firewall':'BOFU','ngfw products':'BOFU',
  'next generation firewall appliance':'BOFU','affordable firewall':'BOFU',
  'enterprise firewall router':'BOFU','price of hardware firewall':'BOFU',
  'network firewall cost':'BOFU','network based firewall':'BOFU',
  'enterprise security firewall':'BOFU',
  // SD-WAN — TOFU
  'wan':'TOFU','sd wan':'TOFU','sd-wan':'TOFU','sdwan':'TOFU','wan definition':'TOFU',
  'what is sd-wan':'TOFU','sd wan security':'TOFU','sd wan explained':'TOFU',
  'sd wan technology':'TOFU','what is sd wan':'TOFU',
  // SD-WAN — MOFU
  'sd wan vs mpls':'MOFU','managed sd wan solutions':'MOFU',
  // SD-WAN — BOFU
  'managed sd wan':'BOFU','sd wan companies':'BOFU','top sd wan vendors':'BOFU',
  'top sd wan providers':'BOFU','best sd wan':'BOFU','sd wan vendors comparison':'BOFU',
  'sd wan for small business':'BOFU','sd wan and cloud':'BOFU',
  'sd wan hardware vendors':'BOFU','sd wan multi cloud':'BOFU',
  'small business wan':'BOFU','sd wan ready':'BOFU','managed service sd wan':'BOFU',
  'sd wan managed services':'BOFU',
  // NAC — TOFU
  'access control':'TOFU','byod':'TOFU','iot security':'TOFU',
  'identity access management':'TOFU','network access control':'TOFU',
  'iam identity access management':'TOFU','what is network access control':'TOFU',
  'access control security':'TOFU','bring your own device':'TOFU',
  // NAC — MOFU
  'access control management':'MOFU','access control services':'MOFU',
  'access control list example':'MOFU','types of access control list':'MOFU',
  'identity and access management system':'MOFU','access control technologies':'MOFU',
  // NAC — BOFU
  'nac solutions':'BOFU','iot security solutions':'BOFU','iot firewall':'BOFU',
  'access control solutions':'BOFU','access control devices':'BOFU',
  'network access control products':'BOFU','nac service':'BOFU',
  'nac network access control products':'BOFU','nac technology':'BOFU',
  'network access control software':'BOFU',
  // Zero Trust — TOFU
  'zero trust':'TOFU','zero trust architecture':'TOFU','zero trust security':'TOFU',
  'zero trust network access':'TOFU','what is zero trust':'TOFU',
  'zero trust model':'TOFU','zero trust network':'TOFU',
  'what is zero trust security':'TOFU','what is zero trust networking':'TOFU',
  'what is zero trust network access':'TOFU','zero trust security model':'TOFU',
  'vpn vs ztna':'MOFU',
  // Zero Trust — BOFU
  'ztna':'BOFU',
  // Top Opportunities — TOFU
  'vpn':'TOFU','zero day':'TOFU','cybersecurity':'TOFU','proxy':'TOFU',
  'what is malware':'TOFU','what is phishing':'TOFU','phishing':'TOFU',
  'ips':'TOFU','malware':'TOFU','ddos':'TOFU','ransomware':'TOFU',
  'ddos attack':'TOFU','multi factor authentication':'TOFU','oauth':'TOFU','iam':'TOFU',
  'internet of things':'TOFU','proxy server':'TOFU','what is a proxy server':'TOFU',
  'phishing definition':'TOFU','how does vpn work':'TOFU','malware definition':'TOFU',
  // Top Opportunities — BOFU
  'ethernet switch':'BOFU','vpn service':'BOFU',
  // AI Cybersecurity — TOFU
  'ai in cybersecurity':'TOFU','ai security':'TOFU','deepfake ai':'TOFU',
  'ai data center':'TOFU','ai adoption':'TOFU','ai deepfakes':'TOFU',
  'how can generative ai be used in cybersecurity':'TOFU',
  'artificial intelligence in cybersecurity':'TOFU','ai security risk':'TOFU',
  'ai cybersecurity':'TOFU','cybersecurity and ai':'TOFU','what is ai security':'TOFU',
  // AI Cybersecurity — MOFU
  'aiops':'MOFU','ai secops':'MOFU',
  // AI Cybersecurity — BOFU
  'ai cybersecurity tools':'BOFU','ai security solutions':'BOFU',
  'gen ai security solutions':'BOFU','ai cybersecurity certification':'BOFU',
  'ai cybersecurity software':'BOFU','aiops tools':'BOFU','aiops software':'BOFU',
  'aiops platforms':'BOFU','aiops vendors':'BOFU','ai cybersecurity providers':'BOFU',
  'ai cyber security companies':'BOFU','best ai security companies':'BOFU',
  'ai security vendor':'BOFU','which are the top ai security companies':'BOFU',
  'what companies provide ai security platforms':'BOFU','ai security platfrom':'BOFU',
  'ai security software':'BOFU','ai security services':'BOFU',
  'ai security companies':'BOFU','ai security providers':'BOFU',
  'ai cybersecurity solutions':'BOFU','top ai cybersecurity vendors':'BOFU',
  'list of ai cybersecurity tools':'BOFU','gen ai security platform':'BOFU',
  // OT Security — TOFU
  'ot security':'TOFU','ot cybersecurity':'TOFU','what is ot security':'TOFU',
  'operational technology security':'TOFU','what is operational technology':'TOFU',
  'ot technology':'TOFU','ot network security':'TOFU',
  'operational technology cyber security':'TOFU','ot/ics cybersecurity':'TOFU',
  'ot network architecture':'TOFU',
  // OT Security — BOFU
  'ot security solutions':'BOFU','best ot security for critical infrastructure':'BOFU',
  'ot cyber security companies':'BOFU','ot security companies':'BOFU',
  'ot security assessment':'BOFU','ot security company':'BOFU',
  'best ot security companies':'BOFU','ot cybersecurity vendors':'BOFU',
  // Quantum Security — TOFU
  'post-quantum cryptography':'TOFU','pqc':'TOFU','quantum key distribution':'TOFU',
  'quantum security':'TOFU','qkd':'TOFU','q-day':'TOFU','quantum computing':'TOFU',
  'quantum cryptography':'TOFU','harvest now decrypt later':'TOFU',
  'post quantum readiness':'TOFU','quantum readiness':'TOFU','what is pqc':'TOFU',
  // Quantum Security — MOFU
  'quantum encryption':'MOFU','post-quantum cryptography standards':'MOFU',
  'cryptographic agility':'MOFU',
  // Quantum Security — BOFU
  'pqc migration':'BOFU','quantum security solutions':'BOFU',
  // SASE — TOFU
  'sase':'TOFU','sase meaning':'TOFU','what is sase':'TOFU',
  'secure access service edge':'TOFU','security service edge':'TOFU',
  'sase architecture':'TOFU','sase definition':'TOFU','sase network':'TOFU','sse':'TOFU',
  'sase providers':'MOFU','sase vendors':'MOFU','ai sase':'MOFU','what is sse':'TOFU',
  // SASE — BOFU
  'sase solutions':'BOFU','single vendor sase':'BOFU','ai powered sase':'BOFU',
  'sase provider':'BOFU','sase security platform':'BOFU',
};

// ═══════════════════ UTILS ═══════════════════
function fmtVol(v: number | null | undefined): string {
  if(!v||v===0)return'—';
  if(v>=1000000)return(v/1000000).toFixed(1)+'M';
  if(v>=1000)return(v/1000).toFixed(0)+'K';
  return String(v);
}
function rankColor(r: number | null): string {
  if(!r)return'rgba(226,232,240,0.8)';
  if(r===1)return'rgba(10,122,85,.35)';
  if(r<=3)return'rgba(10,122,85,.22)';
  if(r<=5)return'rgba(26,86,219,.28)';
  if(r<=10)return'rgba(180,83,9,.28)';
  if(r<=20)return'rgba(217,48,37,.25)';
  return'rgba(217,48,37,.4)';
}
function rankTextColor(r: number | null): string {
  if(!r)return'#94A3B8';
  if(r===1)return'#065F46';
  if(r<=5)return'#1E40AF';
  if(r<=10)return'#92400E';
  return'#B71C1C';
}
function catClass(cat: string): string {
  const m: Record<string,string>={'Top Opportunities':'fn-cat-top','NAC':'fn-cat-nac','NGFW':'fn-cat-ngfw','Zero Trust':'fn-cat-zt','SD-WAN':'fn-cat-sdwan','AI Cybersecurity':'fn-cat-ai','OT Security':'fn-cat-ot','Quantum Security':'fn-cat-qsec','SASE':'fn-cat-sase'};
  return m[cat]||'';
}
function rankBadgeClass(r: number | null | undefined): string {
  if(r==null||r===0)return'fn-r-bad';
  if(r===1)return'fn-r1';
  if(r<=5)return'fn-r2';
  if(r<=15)return'fn-r3';
  return'fn-r-bad';
}
function catColor(cat: string): string {
  const m: Record<string,string>={'Top Opportunities':'#D93025','NAC':'#1A56DB','NGFW':'#0A7A55','Zero Trust':'#7C3AED','SD-WAN':'#B45309','AI Cybersecurity':'#F59E0B','OT Security':'#6366F1','Quantum Security':'#EC4899','SASE':'#06B6D4'};
  return m[cat]||'#64748B';
}


// ═══════════════════ TRAFFIC DATA (GSC + GA) ═════════════════════════════
// Source: GSC and Google Analytics · WW · Weekly (Sun–Sat) · Dec 31, 2025 → Oct 28, 2026
const TRAFFIC_WEEKS = ["Dec 31","Jan 7","Jan 14","Jan 21","Jan 28","Feb 4","Feb 11","Feb 18","Feb 25","Mar 4","Mar 11","Mar 18","Mar 25","Apr 1","Apr 8","Apr 15","Apr 22","Apr 29","May 6","May 13","May 20","May 27","Jun 3","Jun 10","Jun 17","Jun 24","Jul 1","Jul 8","Jul 15","Jul 22","Jul 29","Aug 5","Aug 12","Aug 19","Aug 26","Sep 2","Sep 9","Sep 16","Sep 23","Sep 30","Oct 7","Oct 14","Oct 21","Oct 28"];

const TRAFFIC_DATA = {
  allOrganic:    [210631,176959,316108,334632,364458,378345,381452,378974,338014,369274,368718,375747,347444,356155,315669,340454,360656,356914,313707,337993,339539,337851,299861,312500,323536,320217,316566,292047,295550,296426,286447,282713,275762,248282,266180,261225,270161,279346,285662,283336,284951,279517,267163,315927],
  branded:       [94649,78586,142605,149523,157485,166374,166231,164636,144463,156891,160076,161115,147779,149305,134728,143435,150963,150830,131068,143951,144878,144807,124964,135587,141935,144808,146688,136851,136376,136031,130392,129066,125682,114823,119056,117587,120028,120522,123289,124744,126752,123579,118120,145779],
  nonBranded:    [39288,40198,49403,48703,58219,53000,54194,54751,51917,56701,54652,57196,54727,56595,51413,54790,55508,52613,50198,52563,52384,51477,53723,53212,51608,49493,47593,44792,45258,49945,49541,47616,47821,46272,50583,48192,49893,51530,50569,50195,50413,48386,47117,48255],
  cyberglossary: [28520,26589,39739,41834,45887,48672,52580,52634,47755,53200,51533,50918,47597,49458,42574,49203,50212,49308,44057,43776,44339,42874,39714,40927,41433,39499,34981,31242,33064,33968,31122,31575,30970,28903,33015,31935,33641,34806,34225,33387,33363,34253,34041,35264],
  homePage:      [4015,4194,7729,7354,8766,10028,9409,9416,8592,9150,9092,9112,8097,8091,7579,7921,8061,8308,7562,7443,7215,7125,6534,7257,7480,7532,6862,6273,6476,7034,6604,6676,6394,6462,6623,6407,6455,6523,6575,6786,6550,6468,6307,7988],
  blog:          [2367,2035,3287,3044,4489,6859,4721,3944,3377,3629,3651,3661,3397,3195,2908,3226,3179,4108,2765,2583,2837,2845,2358,2663,2870,4331,8003,4199,3436,2887,2496,2345,2221,1982,2184,2148,2112,2040,2257,2004,2059,2674,2248,18442],
  articles:      [105,103,202,242,253,293,300,295,302,320,300,307,289,284,250,272,287,272,272,267,271,512,223,266,266,301,260,223,274,252,197,188,192,192,186,192,195,223,214,192,194,203,182,219],
  solutions:     [1924,1476,3234,3607,3987,4180,4220,4071,3690,3911,3884,3875,3439,3756,3280,3748,4087,3995,3352,3447,3678,3808,3307,3394,3625,3437,3252,2724,3005,2958,2840,2791,2747,2575,2768,2750,2984,2723,2739,2511,2443,2599,2571,2892],
  products:      [11506,8012,17221,17963,19108,24515,21018,20441,18352,19705,19869,20187,18187,18320,16348,18329,18971,19683,16354,17264,19084,18894,16757,18090,18741,17792,17544,15656,16173,16032,15130,15109,15177,15297,16775,16650,16806,15258,14657,13891,14643,14264,13784,16339],
  aboutUs:       [3449,2575,5423,5305,5821,5941,6116,5757,5285,5674,5792,6404,5733,5700,5105,6373,6783,6953,5191,5223,5664,5684,5497,5638,5734,5735,5170,5063,5991,5981,5638,6149,5959,5596,6338,6015,5176,5289,5206,4601,4901,4590,4409,5484],
  directGA:         [86307,70744,115528,128971,109499,116029,129917,132972,143019,103659,108183,137028,109527,172648,144528,121981,126870,147052,125088,134833,139674,161698,174868,211459,190773,178866,137219,118425,121673,97430,94872,108806,80664,79635,93322,113930,97017,86343,98178,109243,94012,86982,108138,150125],
  directValid:      [84818,69655,113813,126840,107416,104294,106257,99542,93837,100631,106607,122660,108027,114502,100915,109946,115443,122067,123372,133085,137827,160335,173188,190245,189354,177375,130958,93841,97883,95654,92233,90687,79426,77517,86569,86469,84631,82858,89254,84207,91441,84178,89718,130305],
  directDownloads:  [67661,55300,88620,100997,80696,77972,77950,71720,69697,74282,79827,95874,82542,89435,76641,84386,89510,96310,100756,108863,113223,134726,150400,165439,164061,151928,104612,67503,77458,77959,74905,74030,63034,61210,69769,70394,68463,67302,73146,67872,73413,66277,71787,108780],
  referrals:        [8173,6700,10133,10290,11142,12690,12115,11349,9783,10671,10872,11469,10297,10249,9866,11459,10878,11521,10057,10872,11487,12067,10627,11341,10831,10640,13624,10239,10810,11337,11299,10729,10384,9278,10623,10570,10810,10424,11842,10866,18594,18312,11816,24508],
};

// WoW change values (Oct 21 → Oct 28)
const TRAFFIC_WOW = {
  allOrganic:       {pct: 18.25,  abs:48764},
  branded:          {pct: 23.42,  abs:27659},
  nonBranded:       {pct:  2.42,  abs:1138},
  cyberglossary:    {pct:  3.59,  abs:1223},
  homePage:         {pct: 26.65,  abs:1681},
  blog:             {pct:720.37,  abs:16194},
  articles:         {pct: 20.33,  abs:37},
  solutions:        {pct: 12.49,  abs:321},
  products:         {pct: 18.54,  abs:2555},
  aboutUs:          {pct: 24.38,  abs:1075},
  directGA:         {pct: 38.83,  abs:41987},
  directValid:      {pct: 45.24,  abs:40587},
  directDownloads:  {pct: 51.53,  abs:36993},
  referrals:        {pct:107.41,  abs:12692},
};

type KwRow = {kw:string;cat:string;funnel:string;sv:number;prev:string;cur:number|string};
// Oct 28, 2026 (wk44) · source: Wow Dashboard Data - 9 Category With AIO Data.csv · one row per tracked keyword/category, so list length = KPI count
const RANK_11_100:KwRow[] = [
  {kw:"vpn",cat:"Top Opportunities",funnel:"TOFU",sv:673000,prev:'1',cur:15},
  {kw:"phishing",cat:"Top Opportunities",funnel:"TOFU",sv:49500,prev:'-',cur:26},
  {kw:"ips",cat:"Top Opportunities",funnel:"TOFU",sv:49500,prev:'17',cur:21},
  {kw:"malware",cat:"Top Opportunities",funnel:"TOFU",sv:40500,prev:'15',cur:15},
  {kw:"iot",cat:"Top Opportunities",funnel:"TOFU",sv:27100,prev:'34',cur:31},
  {kw:"phishing definition",cat:"Top Opportunities",funnel:"TOFU",sv:27100,prev:'26',cur:39},
  {kw:"encryption",cat:"Top Opportunities",funnel:"TOFU",sv:22200,prev:'16',cur:16},
  {kw:"internet of things",cat:"Top Opportunities",funnel:"TOFU",sv:22200,prev:'48',cur:25},
  {kw:"quantum cryptography",cat:"Quantum Security",funnel:"TOFU",sv:18100,prev:'39',cur:33},
  {kw:"Sse",cat:"SASE",funnel:"TOFU",sv:14800,prev:'10',cur:12},
  {kw:"single sign on",cat:"Top Opportunities",funnel:"TOFU",sv:12100,prev:'1',cur:20},
  {kw:"two factor authentication",cat:"Top Opportunities",funnel:"TOFU",sv:12100,prev:'13',cur:14},
  {kw:"malware definition",cat:"Top Opportunities",funnel:"TOFU",sv:8100,prev:'18',cur:15},
  {kw:"zero trust architecture",cat:"Zero Trust",funnel:"TOFU",sv:6600,prev:'1',cur:22},
  {kw:"aiops",cat:"AI Cybersecurity",funnel:"TOFU",sv:5400,prev:'14',cur:25},
  {kw:"ai data center",cat:"AI Cybersecurity",funnel:"TOFU",sv:5400,prev:'-',cur:18},
  {kw:"identity access management",cat:"NAC",funnel:"TOFU",sv:2900,prev:'-',cur:35},
  {kw:"list of ai cybersecurity tools",cat:"AI Cybersecurity",funnel:"BOFU",sv:2400,prev:'47',cur:21},
  {kw:"PQC",cat:"Quantum Security",funnel:"TOFU",sv:1900,prev:'24',cur:26},
  {kw:"ai cybersecurity risks",cat:"AI Cybersecurity",funnel:"TOFU",sv:1600,prev:'-',cur:27},
  {kw:"nac network",cat:"NAC",funnel:"TOFU",sv:1300,prev:'1',cur:19},
  {kw:"what are ai data centers",cat:"AI Cybersecurity",funnel:"TOFU",sv:1000,prev:'1',cur:22},
  {kw:"deepfakes meaning",cat:"AI Cybersecurity",funnel:"TOFU",sv:1000,prev:'1',cur:23},
  {kw:"ai adoption framework",cat:"AI Cybersecurity",funnel:"MOFU",sv:1000,prev:'24',cur:18},
  {kw:"what is access control",cat:"NAC",funnel:"TOFU",sv:1000,prev:'1',cur:21},
  {kw:"managed sd wan",cat:"SD-WAN",funnel:"TOFU",sv:1000,prev:'4',cur:20},
  {kw:"Generative ai security",cat:"AI Cybersecurity",funnel:"TOFU",sv:720,prev:'1',cur:37},
  {kw:"how do deepfakes work",cat:"AI Cybersecurity",funnel:"TOFU",sv:720,prev:'15',cur:32},
  {kw:"what does deepfake mean",cat:"AI Cybersecurity",funnel:"TOFU",sv:720,prev:'1',cur:18},
  {kw:"access control management",cat:"NAC",funnel:"TOFU",sv:720,prev:'49',cur:19},
  {kw:"sd wan explained",cat:"SD-WAN",funnel:"TOFU",sv:720,prev:'1',cur:21},
  {kw:"ai security software",cat:"AI Cybersecurity",funnel:"BOFU",sv:590,prev:'13',cur:25},
  {kw:"sd wan providers",cat:"SD-WAN",funnel:"TOFU",sv:590,prev:'37',cur:16},
  {kw:"ai cybersecurity threats",cat:"AI Cybersecurity",funnel:"TOFU",sv:480,prev:'12',cur:12},
  {kw:"generative ai in cybersecurity",cat:"AI Cybersecurity",funnel:"MOFU",sv:480,prev:'14',cur:14},
  {kw:"artificial intelligence data center",cat:"AI Cybersecurity",funnel:"TOFU",sv:480,prev:'1',cur:32},
  {kw:"Sase Providers",cat:"SASE",funnel:"TOFU",sv:480,prev:'1',cur:21},
  {kw:"layer 7 firewall",cat:"NGFW",funnel:"TOFU",sv:390,prev:'41',cur:17},
  {kw:"sd wan vendors",cat:"SD-WAN",funnel:"MOFU",sv:390,prev:'-',cur:14},
  {kw:"stateless firewall",cat:"NGFW",funnel:"TOFU",sv:320,prev:'2',cur:20},
  {kw:"ai security monitoring",cat:"AI Cybersecurity",funnel:"MOFU",sv:260,prev:'9',cur:22},
  {kw:"ethernet switching",cat:"Top Opportunities",funnel:"TOFU",sv:260,prev:'1',cur:20},
  {kw:"ai driven security",cat:"AI Cybersecurity",funnel:"MOFU",sv:210,prev:'17',cur:23},
  {kw:"preparing for ai adoption",cat:"AI Cybersecurity",funnel:"MOFU",sv:210,prev:'3',cur:22},
  {kw:"ot security companies",cat:"OT Security",funnel:"BOFU",sv:210,prev:'17',cur:19},
  {kw:"sd wan companies",cat:"SD-WAN",funnel:"BOFU",sv:210,prev:'17',cur:23},
  {kw:"generative ai for cybersecurity",cat:"AI Cybersecurity",funnel:"MOFU",sv:170,prev:'-',cur:37},
  {kw:"how to secure iot devices",cat:"NAC",funnel:"TOFU",sv:170,prev:'5',cur:19},
  {kw:"ai cybersecurity incidents",cat:"AI Cybersecurity",funnel:"TOFU",sv:140,prev:'2',cur:18},
  {kw:"aiops meaning",cat:"AI Cybersecurity",funnel:"TOFU",sv:140,prev:'28',cur:15},
  {kw:"aiops monitoring",cat:"AI Cybersecurity",funnel:"MOFU",sv:140,prev:'65',cur:40},
  {kw:"artificial intelligence risk management",cat:"AI Cybersecurity",funnel:"TOFU",sv:140,prev:'-',cur:56},
  {kw:"ics/ot",cat:"OT Security",funnel:"TOFU",sv:140,prev:'35',cur:14},
  {kw:"ot vulnerabilities",cat:"OT Security",funnel:"TOFU",sv:140,prev:'15',cur:90},
  {kw:"ot cyber security companies",cat:"OT Security",funnel:"BOFU",sv:140,prev:'-',cur:12},
  {kw:"sd wan software",cat:"SD-WAN",funnel:"TOFU",sv:140,prev:'-',cur:21},
  {kw:"business sd wan",cat:"SD-WAN",funnel:"MOFU",sv:140,prev:'47',cur:24},
  {kw:"sdn in the wan",cat:"SD-WAN",funnel:"TOFU",sv:140,prev:'3',cur:22},
  {kw:"risks of ai in cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:110,prev:'-',cur:25},
  {kw:"ai data center architecture",cat:"AI Cybersecurity",funnel:"MOFU",sv:110,prev:'45',cur:16},
  {kw:"ot security monitoring",cat:"OT Security",funnel:"TOFU",sv:110,prev:'24',cur:14},
  {kw:"quantum readiness",cat:"Quantum Security",funnel:"TOFU",sv:110,prev:'21',cur:43},
  {kw:"wan providers",cat:"SD-WAN",funnel:"TOFU",sv:110,prev:'32',cur:40},
  {kw:"sd wan security features",cat:"SD-WAN",funnel:"TOFU",sv:110,prev:'5',cur:22},
  {kw:"cloud managed sd wan",cat:"SD-WAN",funnel:"MOFU",sv:110,prev:'26',cur:92},
  {kw:"aiops framework",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'21',cur:25},
  {kw:"aiops capabilities",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'-',cur:40},
  {kw:"ai security services",cat:"AI Cybersecurity",funnel:"BOFU",sv:90,prev:'10',cur:11},
  {kw:"access control in network security",cat:"NAC",funnel:"TOFU",sv:90,prev:'1',cur:23},
  {kw:"ot network architecture",cat:"OT Security",funnel:"MOFU",sv:90,prev:'24',cur:23},
  {kw:"ot cybersecurity vendors",cat:"OT Security",funnel:"BOFU",sv:90,prev:'18',cur:18},
  {kw:"sd wan vendors comparison",cat:"SD-WAN",funnel:"BOFU",sv:90,prev:'-',cur:44},
  {kw:"sd wan requirements",cat:"SD-WAN",funnel:"TOFU",sv:90,prev:'5',cur:24},
  {kw:"is sd wan better than mpls",cat:"SD-WAN",funnel:"TOFU",sv:90,prev:'4',cur:21},
  {kw:"sd wan vs mpls cost comparison",cat:"SD-WAN",funnel:"TOFU",sv:90,prev:'3',cur:20},
  {kw:"next gen firewall services",cat:"NGFW",funnel:"MOFU",sv:70,prev:'4',cur:47},
  {kw:"features of next generation firewall",cat:"NGFW",funnel:"MOFU",sv:70,prev:'1',cur:15},
  {kw:"ot cyber security framework",cat:"OT Security",funnel:"MOFU",sv:70,prev:'3',cur:24},
  {kw:"industrial ot cybersecurity",cat:"OT Security",funnel:"MOFU",sv:70,prev:'-',cur:49},
  {kw:"ot/ics cybersecurity",cat:"OT Security",funnel:"MOFU",sv:70,prev:'108',cur:15},
  {kw:"Crypto-Agility",cat:"Quantum Security",funnel:"TOFU",sv:70,prev:'17',cur:25},
  {kw:"define sd wan",cat:"SD-WAN",funnel:"TOFU",sv:70,prev:'1',cur:20},
  {kw:"diy vs managed sd wan",cat:"SD-WAN",funnel:"TOFU",sv:70,prev:'2',cur:17},
  {kw:"sd wan visibility",cat:"SD-WAN",funnel:"MOFU",sv:70,prev:'-',cur:64},
  {kw:"sd wan automation",cat:"SD-WAN",funnel:"MOFU",sv:70,prev:'52',cur:35},
  {kw:"what does aiops stand for",cat:"AI Cybersecurity",funnel:"TOFU",sv:50,prev:'-',cur:38},
  {kw:"what are aiops",cat:"AI Cybersecurity",funnel:"TOFU",sv:50,prev:'15',cur:31},
  {kw:"types of access control list",cat:"NAC",funnel:"TOFU",sv:50,prev:'9',cur:13},
  {kw:"business firewall solutions",cat:"NGFW",funnel:"BOFU",sv:50,prev:'4',cur:22},
  {kw:"next generation firewall benefits",cat:"NGFW",funnel:"MOFU",sv:50,prev:'5',cur:21},
  {kw:"sd wan appliances",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'-',cur:36},
  {kw:"wan cost",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'24',cur:13},
  {kw:"benefits of ai data center",cat:"AI Cybersecurity",funnel:"MOFU",sv:40,prev:'1',cur:16},
  {kw:"benefits of access control list",cat:"NAC",funnel:"TOFU",sv:40,prev:'4',cur:34},
  {kw:"what is next generation firewalls",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:21},
  {kw:"ngfw definition",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:21},
  {kw:"how network firewall is different from application firewall",cat:"NGFW",funnel:"TOFU",sv:40,prev:'2',cur:20},
  {kw:"application firewall and network firewall",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:20},
  {kw:"enterprise firewall router",cat:"NGFW",funnel:"BOFU",sv:40,prev:'33',cur:30},
  {kw:"iot and ot security",cat:"OT Security",funnel:"TOFU",sv:40,prev:'31',cur:15},
  {kw:"wan sd wan",cat:"SD-WAN",funnel:"TOFU",sv:40,prev:'18',cur:18},
  {kw:"enterprise grade firewall",cat:"NGFW",funnel:"BOFU",sv:30,prev:'15',cur:11},
  {kw:"ngfw network",cat:"NGFW",funnel:"TOFU",sv:30,prev:'12',cur:23},
  {kw:"firewall price comparison",cat:"NGFW",funnel:"BOFU",sv:30,prev:'1',cur:21},
  {kw:"secure web gateway vs next generation firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'21',cur:24},
  {kw:"what is the next generation firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:21},
  {kw:"next generation firewall features list",cat:"NGFW",funnel:"MOFU",sv:30,prev:'1',cur:15},
  {kw:"ngfw layer 7 firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'4',cur:23},
  {kw:"next generation firewall meaning",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:21},
  {kw:"ot it security",cat:"OT Security",funnel:"MOFU",sv:30,prev:'1',cur:21},
  {kw:"Ai Powered Sase",cat:"SASE",funnel:"BOFU",sv:30,prev:'14',cur:12},
  {kw:"sd wan connectivity",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'2',cur:15},
  {kw:"sd wan price comparison",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'9',cur:22},
  {kw:"difference between wan and sd wan",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'7',cur:21},
  {kw:"why use sd wan",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'1',cur:16},
  {kw:"sd wan lan",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'28',cur:23},
  {kw:"sd wan access",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'10',cur:26},
  {kw:"sd wan aggregation",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'1',cur:17},
  {kw:"sd wan multi cloud",cat:"SD-WAN",funnel:"BOFU",sv:30,prev:'4',cur:21},
  {kw:"sd wan data center",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'12',cur:23},
  {kw:"small business wan",cat:"SD-WAN",funnel:"BOFU",sv:30,prev:'1',cur:21},
  {kw:"ngfw magic quadrant",cat:"NGFW",funnel:"MOFU",sv:20,prev:'2',cur:19},
  {kw:"how much is a network firewall",cat:"NGFW",funnel:"BOFU",sv:20,prev:'1',cur:21},
  {kw:"ngfw firewall features",cat:"NGFW",funnel:"MOFU",sv:20,prev:'1',cur:24},
  {kw:"affordable firewall",cat:"NGFW",funnel:"BOFU",sv:20,prev:'6',cur:24},
  {kw:"post quantum readiness",cat:"Quantum Security",funnel:"TOFU",sv:20,prev:'-',cur:45},
  {kw:"sd wan price list",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'10',cur:26},
  {kw:"sd wan cost calculator",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'3',cur:14},
  {kw:"sd wan ready",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'17',cur:30},
  {kw:"sd-wan aggregation",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'1',cur:14},
  {kw:"ai cybersecurity providers",cat:"AI Cybersecurity",funnel:"BOFU",sv:10,prev:'25',cur:33},
  {kw:"top ai cybersecurity vendors",cat:"AI Cybersecurity",funnel:"BOFU",sv:10,prev:'7',cur:14},
  {kw:"ai security use case",cat:"AI Cybersecurity",funnel:"MOFU",sv:0,prev:'18',cur:18},
  {kw:"ai security platfrom",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'54',cur:36},
];

const NOT_RANKING:KwRow[] = [
  {kw:"zero day",cat:"Top Opportunities",funnel:"TOFU",sv:368000,prev:'-',cur:'-'},
  {kw:"what is malware",cat:"Top Opportunities",funnel:"TOFU",sv:135000,prev:'24',cur:'-'},
  {kw:"quantum computing",cat:"Quantum Security",funnel:"TOFU",sv:74000,prev:'-',cur:'-'},
  {kw:"saml",cat:"Top Opportunities",funnel:"TOFU",sv:18100,prev:'18',cur:'-'},
  {kw:"multi factor authentication",cat:"Top Opportunities",funnel:"TOFU",sv:14800,prev:'-',cur:'-'},
  {kw:"vpn service",cat:"Top Opportunities",funnel:"MOFU",sv:9900,prev:'-',cur:'-'},
  {kw:"phishing email",cat:"Top Opportunities",funnel:"TOFU",sv:9900,prev:'-',cur:'-'},
  {kw:"ai governance",cat:"AI Cybersecurity",funnel:"TOFU",sv:8100,prev:'-',cur:'-'},
  {kw:"frontier ai",cat:"AI Cybersecurity",funnel:"TOFU",sv:3600,prev:'-',cur:'-'},
  {kw:"ai in risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:3600,prev:'-',cur:'-'},
  {kw:"ai risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:3600,prev:'-',cur:'-'},
  {kw:"ai governance framework",cat:"AI Cybersecurity",funnel:"TOFU",sv:2900,prev:'-',cur:'-'},
  {kw:"bring your own device",cat:"NAC",funnel:"TOFU",sv:2400,prev:'-',cur:'-'},
  {kw:"aiops tools",cat:"AI Cybersecurity",funnel:"BOFU",sv:1900,prev:'15',cur:'-'},
  {kw:"access control solutions",cat:"NAC",funnel:"BOFU",sv:1900,prev:'-',cur:'-'},
  {kw:"iam identity access management",cat:"NAC",funnel:"TOFU",sv:1900,prev:'1',cur:'-'},
  {kw:"What Is Sse",cat:"SASE",funnel:"TOFU",sv:1900,prev:'-',cur:'-'},
  {kw:"aiops platforms",cat:"AI Cybersecurity",funnel:"BOFU",sv:1300,prev:'-',cur:'-'},
  {kw:"ai risk management framework",cat:"AI Cybersecurity",funnel:"MOFU",sv:1300,prev:'-',cur:'-'},
  {kw:"ai risk assessment",cat:"AI Cybersecurity",funnel:"MOFU",sv:1300,prev:'-',cur:'-'},
  {kw:"agentic ai security",cat:"AI Cybersecurity",funnel:"TOFU",sv:1000,prev:'-',cur:'-'},
  {kw:"HNDL",cat:"Quantum Security",funnel:"TOFU",sv:1000,prev:'-',cur:'-'},
  {kw:"ai operations",cat:"AI Cybersecurity",funnel:"MOFU",sv:880,prev:'-',cur:'-'},
  {kw:"enterprise ai adoption",cat:"AI Cybersecurity",funnel:"MOFU",sv:720,prev:'-',cur:'-'},
  {kw:"ai adoption challenges",cat:"AI Cybersecurity",funnel:"MOFU",sv:720,prev:'-',cur:'-'},
  {kw:"ai security companies",cat:"AI Cybersecurity",funnel:"BOFU",sv:720,prev:'1',cur:'-'},
  {kw:"ai prompt injection",cat:"AI Cybersecurity",funnel:"TOFU",sv:590,prev:'1',cur:'-'},
  {kw:"ai cybersecurity certification",cat:"AI Cybersecurity",funnel:"BOFU",sv:590,prev:'-',cur:'-'},
  {kw:"aiops software",cat:"AI Cybersecurity",funnel:"BOFU",sv:590,prev:'25',cur:'-'},
  {kw:"access control devices",cat:"NAC",funnel:"BOFU",sv:590,prev:'-',cur:'-'},
  {kw:"quantum day",cat:"Quantum Security",funnel:"TOFU",sv:480,prev:'-',cur:'-'},
  {kw:"managed sd wan solutions",cat:"SD-WAN",funnel:"TOFU",sv:480,prev:'-',cur:'-'},
  {kw:"ai siem",cat:"AI Cybersecurity",funnel:"MOFU",sv:390,prev:'-',cur:'-'},
  {kw:"ai security best practices",cat:"AI Cybersecurity",funnel:"MOFU",sv:390,prev:'-',cur:'-'},
  {kw:"artificial intelligence risk management framework",cat:"AI Cybersecurity",funnel:"MOFU",sv:320,prev:'-',cur:'-'},
  {kw:"fully managed sd wan",cat:"SD-WAN",funnel:"MOFU",sv:320,prev:'26',cur:'-'},
  {kw:"ai and risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:260,prev:'-',cur:'-'},
  {kw:"ai for risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:260,prev:'-',cur:'-'},
  {kw:"ai adoption by industry",cat:"AI Cybersecurity",funnel:"TOFU",sv:260,prev:'-',cur:'-'},
  {kw:"ai adoption statistics",cat:"AI Cybersecurity",funnel:"TOFU",sv:260,prev:'-',cur:'-'},
  {kw:"sd wan router",cat:"SD-WAN",funnel:"TOFU",sv:260,prev:'-',cur:'-'},
  {kw:"aiops vendors",cat:"AI Cybersecurity",funnel:"BOFU",sv:210,prev:'68',cur:'-'},
  {kw:"harvest now decrypt later",cat:"Quantum Security",funnel:"TOFU",sv:210,prev:'-',cur:'-'},
  {kw:"ai adoption in healthcare",cat:"AI Cybersecurity",funnel:"MOFU",sv:170,prev:'-',cur:'-'},
  {kw:"ai security frameworks",cat:"AI Cybersecurity",funnel:"MOFU",sv:140,prev:'34',cur:'-'},
  {kw:"aiops definition",cat:"AI Cybersecurity",funnel:"TOFU",sv:140,prev:'-',cur:'-'},
  {kw:"ai adoption rate",cat:"AI Cybersecurity",funnel:"TOFU",sv:140,prev:'-',cur:'-'},
  {kw:"how to setup a firewall",cat:"NGFW",funnel:"TOFU",sv:140,prev:'1',cur:'-'},
  {kw:"Cryptographic Agility",cat:"Quantum Security",funnel:"TOFU",sv:140,prev:'1',cur:'-'},
  {kw:"enterprise aiops",cat:"AI Cybersecurity",funnel:"MOFU",sv:110,prev:'1',cur:'-'},
  {kw:"top sd wan providers",cat:"SD-WAN",funnel:"BOFU",sv:110,prev:'-',cur:'-'},
  {kw:"ai model risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'-',cur:'-'},
  {kw:"enterprise ai adoption trends",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'-',cur:'-'},
  {kw:"best sd wan",cat:"SD-WAN",funnel:"BOFU",sv:90,prev:'62',cur:'-'},
  {kw:"best sd wan providers",cat:"SD-WAN",funnel:"MOFU",sv:90,prev:'53',cur:'-'},
  {kw:"best sd wan vendors",cat:"SD-WAN",funnel:"MOFU",sv:90,prev:'17',cur:'-'},
  {kw:"ai impact on data centers",cat:"AI Cybersecurity",funnel:"MOFU",sv:70,prev:'-',cur:'-'},
  {kw:"aiops trends",cat:"AI Cybersecurity",funnel:"MOFU",sv:70,prev:'-',cur:'-'},
  {kw:"ai adoption in financial services",cat:"AI Cybersecurity",funnel:"MOFU",sv:70,prev:'-',cur:'-'},
  {kw:"layer 3 firewall",cat:"NGFW",funnel:"BOFU",sv:70,prev:'62',cur:'-'},
  {kw:"best ot security companies",cat:"OT Security",funnel:"BOFU",sv:70,prev:'-',cur:'-'},
  {kw:"NIST PQC standards",cat:"Quantum Security",funnel:"TOFU",sv:70,prev:'-',cur:'-'},
  {kw:"top sd wan vendors",cat:"SD-WAN",funnel:"BOFU",sv:70,prev:'-',cur:'-'},
  {kw:"what is ai risk management",cat:"AI Cybersecurity",funnel:"TOFU",sv:50,prev:'-',cur:'-'},
  {kw:"enterprise ai adoption challenges",cat:"AI Cybersecurity",funnel:"MOFU",sv:50,prev:'-',cur:'-'},
  {kw:"leading sd wan vendors",cat:"SD-WAN",funnel:"MOFU",sv:50,prev:'-',cur:'-'},
  {kw:"ai security challenges",cat:"AI Cybersecurity",funnel:"MOFU",sv:40,prev:'1',cur:'-'},
  {kw:"ai and machine learning for risk management",cat:"AI Cybersecurity",funnel:"MOFU",sv:40,prev:'-',cur:'-'},
  {kw:"nac service",cat:"NAC",funnel:"BOFU",sv:40,prev:'-',cur:'-'},
  {kw:"ai data center trends",cat:"AI Cybersecurity",funnel:"MOFU",sv:30,prev:'-',cur:'-'},
  {kw:"5th generation firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'6',cur:'-'},
  {kw:"sd wan hardware vendors",cat:"SD-WAN",funnel:"BOFU",sv:30,prev:'-',cur:'-'},
  {kw:"ai security for enterprise",cat:"AI Cybersecurity",funnel:"MOFU",sv:20,prev:'-',cur:'-'},
  {kw:"cheap firewall",cat:"NGFW",funnel:"BOFU",sv:20,prev:'29',cur:'-'},
  {kw:"what is HNDL",cat:"Quantum Security",funnel:"TOFU",sv:20,prev:'-',cur:'-'},
  {kw:"gen ai security solutions",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'-',cur:'-'},
  {kw:"data center challenges in ai",cat:"AI Cybersecurity",funnel:"MOFU",sv:0,prev:'-',cur:'-'},
  {kw:"deepfake ai best practices",cat:"AI Cybersecurity",funnel:"MOFU",sv:0,prev:'-',cur:'-'},
  {kw:"deepfake ai challenges",cat:"AI Cybersecurity",funnel:"MOFU",sv:0,prev:'-',cur:'-'},
  {kw:"what industries benefit most from ai adoption",cat:"AI Cybersecurity",funnel:"TOFU",sv:0,prev:'-',cur:'-'},
  {kw:"what frameworks guide successful ai adoption",cat:"AI Cybersecurity",funnel:"TOFU",sv:0,prev:'-',cur:'-'},
  {kw:"gen ai security platform",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'-',cur:'-'},
];

const AIO_KEYWORDS:KwRow[] = [
  {kw:"cybersecurity",cat:"Top Opportunities",funnel:"TOFU",sv:201000,prev:'1',cur:1},
  {kw:"what is a firewall",cat:"NGFW",funnel:"TOFU",sv:135000,prev:'1',cur:1},
  {kw:"what is a firewall",cat:"Top Opportunities",funnel:"TOFU",sv:135000,prev:'1',cur:1},
  {kw:"wan",cat:"SD-WAN",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"ddos",cat:"Top Opportunities",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"iam",cat:"Top Opportunities",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"wan",cat:"Top Opportunities",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"ransomware",cat:"Top Opportunities",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"proxy server",cat:"Top Opportunities",funnel:"TOFU",sv:33100,prev:'1',cur:1},
  {kw:"firewall",cat:"NGFW",funnel:"TOFU",sv:27100,prev:'1',cur:1},
  {kw:"firewall",cat:"Top Opportunities",funnel:"TOFU",sv:27100,prev:'1',cur:1},
  {kw:"AI in cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:22200,prev:'1',cur:1},
  {kw:"ddos attack",cat:"Top Opportunities",funnel:"TOFU",sv:18100,prev:'1',cur:1},
  {kw:"what is a proxy server",cat:"Top Opportunities",funnel:"TOFU",sv:18100,prev:'1',cur:1},
  {kw:"Sase",cat:"SASE",funnel:"TOFU",sv:14800,prev:'1',cur:1},
  {kw:"ethernet switch",cat:"Top Opportunities",funnel:"BOFU",sv:14800,prev:'-',cur:1},
  {kw:"sase",cat:"Top Opportunities",funnel:"TOFU",sv:14800,prev:'1',cur:1},
  {kw:"access control",cat:"NAC",funnel:"TOFU",sv:12100,prev:'18',cur:1},
  {kw:"oauth",cat:"Top Opportunities",funnel:"TOFU",sv:12100,prev:'1',cur:1},
  {kw:"access control",cat:"Top Opportunities",funnel:"TOFU",sv:12100,prev:'18',cur:1},
  {kw:"byod",cat:"NAC",funnel:"TOFU",sv:9900,prev:'1',cur:1},
  {kw:"qos",cat:"Top Opportunities",funnel:"TOFU",sv:9900,prev:'1',cur:1},
  {kw:"byod",cat:"Top Opportunities",funnel:"TOFU",sv:9900,prev:'1',cur:1},
  {kw:"post-quantum cryptography",cat:"Quantum Security",funnel:"TOFU",sv:8100,prev:'1',cur:1},
  {kw:"ddos meaning",cat:"Top Opportunities",funnel:"TOFU",sv:8100,prev:'1',cur:1},
  {kw:"sd wan",cat:"SD-WAN",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"sd-wan",cat:"SD-WAN",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"sdwan",cat:"SD-WAN",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"wan definition",cat:"SD-WAN",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"sd wan",cat:"Top Opportunities",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"sd-wan",cat:"Top Opportunities",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"sdwan",cat:"Top Opportunities",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"encryption definition",cat:"Top Opportunities",funnel:"TOFU",sv:6600,prev:'1',cur:1},
  {kw:"deepfake ai",cat:"AI Cybersecurity",funnel:"TOFU",sv:5400,prev:'4',cur:1},
  {kw:"firewalls",cat:"NGFW",funnel:"TOFU",sv:5400,prev:'1',cur:1},
  {kw:"firewall configuration",cat:"NGFW",funnel:"TOFU",sv:5400,prev:'1',cur:1},
  {kw:"iot security",cat:"OT Security",funnel:"TOFU",sv:5400,prev:'1',cur:1},
  {kw:"firewalls",cat:"Top Opportunities",funnel:"TOFU",sv:5400,prev:'1',cur:1},
  {kw:"ztna",cat:"Zero Trust",funnel:"BOFU",sv:5400,prev:'1',cur:1},
  {kw:"zero trust security",cat:"Zero Trust",funnel:"TOFU",sv:5400,prev:'1',cur:1},
  {kw:"ai cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:4400,prev:'1',cur:1},
  {kw:"network firewall security",cat:"NGFW",funnel:"TOFU",sv:4400,prev:'1',cur:1},
  {kw:"ngfw",cat:"NGFW",funnel:"BOFU",sv:4400,prev:'1',cur:1},
  {kw:"Sase Meaning",cat:"SASE",funnel:"TOFU",sv:4400,prev:'1',cur:1},
  {kw:"how does vpn work",cat:"Top Opportunities",funnel:"TOFU",sv:4400,prev:'9',cur:1},
  {kw:"iot security",cat:"NAC",funnel:"TOFU",sv:3600,prev:'1',cur:1},
  {kw:"network firewall",cat:"NGFW",funnel:"TOFU",sv:3600,prev:'7',cur:1},
  {kw:"ot security",cat:"OT Security",funnel:"MOFU",sv:3600,prev:'1',cur:1},
  {kw:"What Is Sase",cat:"SASE",funnel:"TOFU",sv:3600,prev:'1',cur:1},
  {kw:"what is ddos",cat:"Top Opportunities",funnel:"TOFU",sv:3600,prev:'1',cur:1},
  {kw:"network firewall",cat:"Top Opportunities",funnel:"TOFU",sv:3600,prev:'7',cur:1},
  {kw:"network access control",cat:"NAC",funnel:"TOFU",sv:2900,prev:'1',cur:1},
  {kw:"quantum encryption",cat:"Quantum Security",funnel:"TOFU",sv:2900,prev:'1',cur:1},
  {kw:"Secure Access Service Edge",cat:"SASE",funnel:"TOFU",sv:2900,prev:'1',cur:1},
  {kw:"wide area network",cat:"SD-WAN",funnel:"TOFU",sv:2900,prev:'1',cur:1},
  {kw:"zero trust network access",cat:"Zero Trust",funnel:"TOFU",sv:2900,prev:'1',cur:1},
  {kw:"ai adoption",cat:"AI Cybersecurity",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"ai cybersecurity tools",cat:"AI Cybersecurity",funnel:"BOFU",sv:2400,prev:'1',cur:1},
  {kw:"what is an ai data center",cat:"AI Cybersecurity",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"ai deepfakes",cat:"AI Cybersecurity",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"network security firewall",cat:"NGFW",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"network security firewall",cat:"NGFW",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"next generation firewall",cat:"NGFW",funnel:"BOFU",sv:2400,prev:'1',cur:1},
  {kw:"next gen firewall",cat:"NGFW",funnel:"BOFU",sv:2400,prev:'1',cur:1},
  {kw:"what is sd-wan",cat:"SD-WAN",funnel:"TOFU",sv:2400,prev:'1',cur:1},
  {kw:"what is aiops",cat:"AI Cybersecurity",funnel:"TOFU",sv:1900,prev:'22',cur:1},
  {kw:"what is iam",cat:"NAC",funnel:"TOFU",sv:1900,prev:'1',cur:1},
  {kw:"Sase Solutions",cat:"SASE",funnel:"TOFU",sv:1900,prev:'1',cur:1},
  {kw:"what is sd wan",cat:"SD-WAN",funnel:"TOFU",sv:1900,prev:'30',cur:1},
  {kw:"zero trust network",cat:"Zero Trust",funnel:"TOFU",sv:1900,prev:'1',cur:1},
  {kw:"ai security solutions",cat:"AI Cybersecurity",funnel:"BOFU",sv:1600,prev:'1',cur:1},
  {kw:"what does a firewall do",cat:"NGFW",funnel:"TOFU",sv:1600,prev:'1',cur:1},
  {kw:"ot cybersecurity",cat:"OT Security",funnel:"TOFU",sv:1600,prev:'1',cur:1},
  {kw:"Security Service Edge",cat:"SASE",funnel:"TOFU",sv:1600,prev:'1',cur:1},
  {kw:"sd wan solutions",cat:"SD-WAN",funnel:"TOFU",sv:1600,prev:'1',cur:1},
  {kw:"software defined wan",cat:"SD-WAN",funnel:"TOFU",sv:1600,prev:'3',cur:1},
  {kw:"what is zero trust security",cat:"Zero Trust",funnel:"TOFU",sv:1600,prev:'1',cur:1},
  {kw:"access control security",cat:"NAC",funnel:"TOFU",sv:1300,prev:'2',cur:2},
  {kw:"stateful firewall",cat:"NGFW",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"what is waf",cat:"NGFW",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"waf security",cat:"NGFW",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"Sase Architecture",cat:"SASE",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"sd wan meaning",cat:"SD-WAN",funnel:"TOFU",sv:1300,prev:'3',cur:1},
  {kw:"zero trust model",cat:"Zero Trust",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"zero trust security model",cat:"Zero Trust",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"what is zero trust architecture",cat:"Zero Trust",funnel:"TOFU",sv:1300,prev:'1',cur:1},
  {kw:"cybersecurity and ai",cat:"AI Cybersecurity",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"iot device security",cat:"NAC",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"iot security solutions",cat:"NAC",funnel:"BOFU",sv:1000,prev:'1',cur:1},
  {kw:"network access control solutions",cat:"NAC",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"waf meaning",cat:"NGFW",funnel:"TOFU",sv:1000,prev:'4',cur:1},
  {kw:"stateful vs stateless firewall",cat:"NGFW",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"stateful inspection firewall",cat:"NGFW",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"firewall as a service",cat:"NGFW",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"what is ot security",cat:"OT Security",funnel:"MOFU",sv:1000,prev:'1',cur:1},
  {kw:"operational technology security",cat:"OT Security",funnel:"MOFU",sv:1000,prev:'1',cur:1},
  {kw:"quantum key distribution",cat:"Quantum Security",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"Sase Definition",cat:"SASE",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"Sase Vs Sse",cat:"SASE",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"802.1 x",cat:"Top Opportunities",funnel:"TOFU",sv:1000,prev:'1',cur:1},
  {kw:"ai red teaming",cat:"AI Cybersecurity",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"ai cybersecurity solutions",cat:"AI Cybersecurity",funnel:"BOFU",sv:880,prev:'1',cur:1},
  {kw:"access control technologies",cat:"NAC",funnel:"MOFU",sv:880,prev:'1',cur:1},
  {kw:"internet of things security",cat:"NAC",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"what is iot security",cat:"NAC",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"quantum security",cat:"Quantum Security",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"QKD",cat:"Quantum Security",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"sd wan vs mpls",cat:"SD-WAN",funnel:"TOFU",sv:880,prev:'1',cur:1},
  {kw:"ai security definition",cat:"AI Cybersecurity",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"what is ai security",cat:"AI Cybersecurity",funnel:"TOFU",sv:720,prev:'4',cur:1},
  {kw:"access control lists",cat:"NAC",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"acl network",cat:"NAC",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"identity and access management system",cat:"NAC",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"network firewalls",cat:"NGFW",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"firewall next generation",cat:"NGFW",funnel:"BOFU",sv:720,prev:'1',cur:1},
  {kw:"what is operational technology",cat:"OT Security",funnel:"MOFU",sv:720,prev:'1',cur:1},
  {kw:"q-day",cat:"Quantum Security",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"Sase Benefits",cat:"SASE",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"sd wan security",cat:"SD-WAN",funnel:"MOFU",sv:720,prev:'1',cur:1},
  {kw:"network firewalls",cat:"Top Opportunities",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"zero trust access",cat:"Zero Trust",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"what is zero trust network access",cat:"Zero Trust",funnel:"TOFU",sv:720,prev:'1',cur:1},
  {kw:"what is identity and access management",cat:"NAC",funnel:"TOFU",sv:590,prev:'7',cur:1},
  {kw:"how does a firewall work",cat:"NGFW",funnel:"TOFU",sv:590,prev:'1',cur:1},
  {kw:"utm firewall",cat:"NGFW",funnel:"TOFU",sv:590,prev:'1',cur:1},
  {kw:"proxy firewall",cat:"NGFW",funnel:"TOFU",sv:590,prev:'1',cur:1},
  {kw:"zero trust networking",cat:"Zero Trust",funnel:"TOFU",sv:590,prev:'1',cur:1},
  {kw:"ai adoption strategy",cat:"AI Cybersecurity",funnel:"MOFU",sv:480,prev:'1',cur:1},
  {kw:"network access control list",cat:"NAC",funnel:"TOFU",sv:480,prev:'1',cur:1},
  {kw:"waf firewall",cat:"NGFW",funnel:"TOFU",sv:480,prev:'5',cur:1},
  {kw:"firewalls explained",cat:"NGFW",funnel:"TOFU",sv:480,prev:'1',cur:1},
  {kw:"ot technology",cat:"OT Security",funnel:"MOFU",sv:480,prev:'1',cur:1},
  {kw:"ot security solutions",cat:"OT Security",funnel:"BOFU",sv:480,prev:'1',cur:1},
  {kw:"Secure Access Service Edge SASE",cat:"SASE",funnel:"TOFU",sv:480,prev:'1',cur:1},
  {kw:"Sase Platform",cat:"SASE",funnel:"TOFU",sv:480,prev:'1',cur:1},
  {kw:"sd wan benefits",cat:"SD-WAN",funnel:"TOFU",sv:480,prev:'1',cur:1},
  {kw:"Artificial intelligence in cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"artificial intelligence for it operations",cat:"AI Cybersecurity",funnel:"MOFU",sv:390,prev:'1',cur:1},
  {kw:"nac solutions",cat:"NAC",funnel:"BOFU",sv:390,prev:'6',cur:1},
  {kw:"what is network access control",cat:"NAC",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"nac cyber security",cat:"NAC",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"what is nac in networking",cat:"NAC",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"security firewall",cat:"NGFW",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"security firewall",cat:"NGFW",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"network based firewall",cat:"NGFW",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"next generation firewall ngfw",cat:"NGFW",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"operational technology cyber security",cat:"OT Security",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"ot security meaning",cat:"OT Security",funnel:"MOFU",sv:390,prev:'1',cur:1},
  {kw:"ot environment",cat:"OT Security",funnel:"MOFU",sv:390,prev:'1',cur:1},
  {kw:"ot devices",cat:"OT Security",funnel:"MOFU",sv:390,prev:'1',cur:1},
  {kw:"quantum safe encryption",cat:"Quantum Security",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"Sase Vs Casb",cat:"SASE",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"Sase Services",cat:"SASE",funnel:"TOFU",sv:390,prev:'2',cur:1},
  {kw:"sd wan definition",cat:"SD-WAN",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"sd wan technology",cat:"SD-WAN",funnel:"TOFU",sv:390,prev:'1',cur:1},
  {kw:"ai security risk",cat:"AI Cybersecurity",funnel:"TOFU",sv:320,prev:'5',cur:1},
  {kw:"ai security threats",cat:"AI Cybersecurity",funnel:"TOFU",sv:320,prev:'19',cur:1},
  {kw:"access control definition",cat:"NAC",funnel:"TOFU",sv:320,prev:'4',cur:1},
  {kw:"iot network security",cat:"NAC",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"iot network security",cat:"NAC",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"network access control software",cat:"NAC",funnel:"TOFU",sv:320,prev:'6',cur:1},
  {kw:"business firewall",cat:"NGFW",funnel:"BOFU",sv:320,prev:'1',cur:1},
  {kw:"what is a network firewall",cat:"NGFW",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"enterprise firewall",cat:"NGFW",funnel:"BOFU",sv:320,prev:'11',cur:1},
  {kw:"waf vs firewall",cat:"NGFW",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"Sase Network",cat:"SASE",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"Sase Provider",cat:"SASE",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"Sase Vendor",cat:"SASE",funnel:"TOFU",sv:320,prev:'1',cur:1},
  {kw:"role of ai in cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"iam definition",cat:"NAC",funnel:"TOFU",sv:260,prev:'2',cur:1},
  {kw:"access control methods",cat:"NAC",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"access control meaning",cat:"NAC",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"what is firewall in networking",cat:"NGFW",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"physical firewall",cat:"NGFW",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"what is a stateful firewall",cat:"NGFW",funnel:"TOFU",sv:260,prev:'2',cur:1},
  {kw:"benefits of sd wan",cat:"SD-WAN",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"wan aggregation",cat:"SD-WAN",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"software defined wide area network",cat:"SD-WAN",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"sdn wan",cat:"SD-WAN",funnel:"TOFU",sv:260,prev:'1',cur:1},
  {kw:"ztna security",cat:"Zero Trust",funnel:"TOFU",sv:260,prev:'6',cur:1},
  {kw:"ai cybersecurity software",cat:"AI Cybersecurity",funnel:"BOFU",sv:210,prev:'1',cur:1},
  {kw:"ai powered cybersecurity",cat:"AI Cybersecurity",funnel:"MOFU",sv:210,prev:'1',cur:1},
  {kw:"nac security",cat:"NAC",funnel:"TOFU",sv:210,prev:'3',cur:1},
  {kw:"acls networking",cat:"NAC",funnel:"TOFU",sv:210,prev:'1',cur:5},
  {kw:"nac network access",cat:"NAC",funnel:"TOFU",sv:210,prev:'1',cur:1},
  {kw:"how firewall works",cat:"NGFW",funnel:"TOFU",sv:210,prev:'1',cur:1},
  {kw:"firewall as a service providers",cat:"NGFW",funnel:"TOFU",sv:210,prev:'2',cur:1},
  {kw:"perimeter firewall",cat:"NGFW",funnel:"TOFU",sv:210,prev:'1',cur:1},
  {kw:"cloud firewall service",cat:"NGFW",funnel:"TOFU",sv:210,prev:'2',cur:1},
  {kw:"sd wan device",cat:"SD-WAN",funnel:"TOFU",sv:210,prev:'4',cur:1},
  {kw:"sd wan advantages",cat:"SD-WAN",funnel:"MOFU",sv:210,prev:'1',cur:1},
  {kw:"strategic ai adoption",cat:"AI Cybersecurity",funnel:"MOFU",sv:170,prev:'1',cur:1},
  {kw:"ai cyber security companies",cat:"AI Cybersecurity",funnel:"BOFU",sv:170,prev:'17',cur:1},
  {kw:"firewall price",cat:"NGFW",funnel:"BOFU",sv:170,prev:'1',cur:1},
  {kw:"hardware vs software firewall",cat:"NGFW",funnel:"TOFU",sv:170,prev:'1',cur:1},
  {kw:"ot security tools",cat:"OT Security",funnel:"TOFU",sv:170,prev:'5',cur:1},
  {kw:"quantum computing security",cat:"Quantum Security",funnel:"TOFU",sv:170,prev:'1',cur:5},
  {kw:"what is PQC",cat:"Quantum Security",funnel:"TOFU",sv:170,prev:'-',cur:1},
  {kw:"Sase Vs Ztna",cat:"SASE",funnel:"TOFU",sv:170,prev:'1',cur:1},
  {kw:"Sase Vs Vpn",cat:"SASE",funnel:"TOFU",sv:170,prev:'1',cur:1},
  {kw:"access control list example",cat:"NAC",funnel:"TOFU",sv:140,prev:'25',cur:1},
  {kw:"access control list in networking",cat:"NAC",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"nac network security",cat:"NAC",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"hardware firewall vs software firewall",cat:"NGFW",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"proxy server firewall",cat:"NGFW",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"benefits of firewall",cat:"NGFW",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"what is ot cybersecurity",cat:"OT Security",funnel:"MOFU",sv:140,prev:'1',cur:1},
  {kw:"operational technology definition",cat:"OT Security",funnel:"MOFU",sv:140,prev:'1',cur:1},
  {kw:"ot infrastructure",cat:"OT Security",funnel:"MOFU",sv:140,prev:'1',cur:1},
  {kw:"VPN vs ZTNA",cat:"Zero Trust",funnel:"TOFU",sv:140,prev:'1',cur:1},
  {kw:"ai secops",cat:"AI Cybersecurity",funnel:"MOFU",sv:110,prev:'7',cur:1},
  {kw:"acl firewall",cat:"NAC",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"nac network access control",cat:"NAC",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"access control examples",cat:"NAC",funnel:"TOFU",sv:110,prev:'4',cur:1},
  {kw:"nac it",cat:"NAC",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"nac technology",cat:"NAC",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"acls security",cat:"NAC",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"utm vs firewall",cat:"NGFW",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"sd wan explanation",cat:"SD-WAN",funnel:"TOFU",sv:110,prev:'5',cur:1},
  {kw:"what is wan aggregation",cat:"SD-WAN",funnel:"TOFU",sv:110,prev:'1',cur:1},
  {kw:"ai based security system",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'-',cur:1},
  {kw:"deepfake attacks",cat:"AI Cybersecurity",funnel:"MOFU",sv:90,prev:'5',cur:1},
  {kw:"what is ai adoption",cat:"AI Cybersecurity",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"how firewalls work",cat:"NGFW",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"firewall cost",cat:"NGFW",funnel:"BOFU",sv:90,prev:'1',cur:1},
  {kw:"network firewall price",cat:"NGFW",funnel:"BOFU",sv:90,prev:'1',cur:1},
  {kw:"firewall vs waf",cat:"NGFW",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"next generation firewall appliance",cat:"NGFW",funnel:"BOFU",sv:90,prev:'1',cur:1},
  {kw:"next generation firewall vs utm",cat:"NGFW",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"what is ot in cybersecurity",cat:"OT Security",funnel:"MOFU",sv:90,prev:'1',cur:1},
  {kw:"ot networking",cat:"OT Security",funnel:"MOFU",sv:90,prev:'1',cur:1},
  {kw:"ot security assessment",cat:"OT Security",funnel:"BOFU",sv:90,prev:'1',cur:1},
  {kw:"Sd-Wan Vs Sase",cat:"SASE",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"mpls to sd wan",cat:"SD-WAN",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"sd wan with mpls",cat:"SD-WAN",funnel:"TOFU",sv:90,prev:'1',cur:1},
  {kw:"ai based security",cat:"AI Cybersecurity",funnel:"MOFU",sv:70,prev:'6',cur:1},
  {kw:"what is deepfake ai",cat:"AI Cybersecurity",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"adoption of ai for cybersecurity",cat:"AI Cybersecurity",funnel:"MOFU",sv:70,prev:'1',cur:1},
  {kw:"security for iot devices",cat:"NAC",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"software firewall vs hardware firewall",cat:"NGFW",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"distributed firewall",cat:"NGFW",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"network firewall security price",cat:"NGFW",funnel:"BOFU",sv:70,prev:'1',cur:1},
  {kw:"what is proxy firewall",cat:"NGFW",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"what are software firewalls",cat:"NGFW",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"next generation firewall vs waf",cat:"NGFW",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"network firewall cost",cat:"NGFW",funnel:"BOFU",sv:70,prev:'2',cur:2},
  {kw:"iot/ot security",cat:"OT Security",funnel:"TOFU",sv:70,prev:'12',cur:1},
  {kw:"operational technology examples",cat:"OT Security",funnel:"MOFU",sv:70,prev:'1',cur:1},
  {kw:"securing ot networks",cat:"OT Security",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"sd wan overview",cat:"SD-WAN",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"advantages of sd wan",cat:"SD-WAN",funnel:"MOFU",sv:70,prev:'1',cur:1},
  {kw:"what is zero trust networking",cat:"Zero Trust",funnel:"TOFU",sv:70,prev:'1',cur:1},
  {kw:"ai automation in cybersecurity",cat:"AI Cybersecurity",funnel:"MOFU",sv:50,prev:'1',cur:1},
  {kw:"nac tools",cat:"NAC",funnel:"TOFU",sv:50,prev:'3',cur:1},
  {kw:"network access control device",cat:"NAC",funnel:"TOFU",sv:50,prev:'1',cur:4},
  {kw:"what is iam security",cat:"NAC",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"cyber security in iot devices",cat:"NAC",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"what is utm firewall",cat:"NGFW",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"firewall vs utm",cat:"NGFW",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"border firewall",cat:"NGFW",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"benefits of firewall security",cat:"NGFW",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"How Does Sase Work",cat:"SASE",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"definition sd wan",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'3',cur:1},
  {kw:"sd wan security concerns",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"what does sd wan mean",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"diy sd wan",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"difference between sdn and sd wan",cat:"SD-WAN",funnel:"TOFU",sv:50,prev:'1',cur:1},
  {kw:"ai security examples",cat:"AI Cybersecurity",funnel:"TOFU",sv:40,prev:'1',cur:1},
  {kw:"network access control products",cat:"NAC",funnel:"BOFU",sv:40,prev:'1',cur:1},
  {kw:"firewall defined",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:1},
  {kw:"configuration of firewall",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:1},
  {kw:"how network firewall works",cat:"NGFW",funnel:"TOFU",sv:40,prev:'1',cur:1},
  {kw:"next generation firewall security",cat:"NGFW",funnel:"MOFU",sv:40,prev:'1',cur:1},
  {kw:"what does ot stand for in cyber security",cat:"OT Security",funnel:"MOFU",sv:40,prev:'1',cur:1},
  {kw:"cyber security for operational technology",cat:"OT Security",funnel:"TOFU",sv:40,prev:'1',cur:1},
  {kw:"Ai Sase",cat:"SASE",funnel:"MOFU",sv:40,prev:'1',cur:1},
  {kw:"sdwan explained",cat:"SD-WAN",funnel:"TOFU",sv:40,prev:'4',cur:1},
  {kw:"sd wan pricing model",cat:"SD-WAN",funnel:"TOFU",sv:40,prev:'3',cur:1},
  {kw:"sd wan bandwidth",cat:"SD-WAN",funnel:"MOFU",sv:40,prev:'1',cur:1},
  {kw:"what is nac security",cat:"NAC",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"security on iot devices",cat:"NAC",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"cyber security iot devices",cat:"NAC",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"application proxy firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"firewall security price",cat:"NGFW",funnel:"BOFU",sv:30,prev:'1',cur:1},
  {kw:"working of firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"nexgen firewall",cat:"NGFW",funnel:"BOFU",sv:30,prev:'1',cur:1},
  {kw:"how hardware firewall works",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"next generation enterprise firewall",cat:"NGFW",funnel:"MOFU",sv:30,prev:'1',cur:1},
  {kw:"ngfw products",cat:"NGFW",funnel:"BOFU",sv:30,prev:'1',cur:1},
  {kw:"difference between next generation firewall and standard firewall",cat:"NGFW",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"what is q-day",cat:"Quantum Security",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"sd wan vs. mpls",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"sd wan what is it",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'3',cur:1},
  {kw:"sdn wan vs mpls",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'1',cur:1},
  {kw:"sd wan software defined wide area network",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'3',cur:1},
  {kw:"sd wan solutions with dynamic routing",cat:"SD-WAN",funnel:"MOFU",sv:30,prev:'5',cur:1},
  {kw:"sd wan brands",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'15',cur:2},
  {kw:"what is sd wan and how does it work",cat:"SD-WAN",funnel:"TOFU",sv:30,prev:'1',cur:4},
  {kw:"ai security benefits",cat:"AI Cybersecurity",funnel:"MOFU",sv:20,prev:'1',cur:1},
  {kw:"what is ai in cybersecurity",cat:"AI Cybersecurity",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"deepfake ai technology",cat:"AI Cybersecurity",funnel:"MOFU",sv:20,prev:'4',cur:1},
  {kw:"best ai security companies",cat:"AI Cybersecurity",funnel:"BOFU",sv:20,prev:'1',cur:7},
  {kw:"ai security providers",cat:"AI Cybersecurity",funnel:"BOFU",sv:20,prev:'1',cur:1},
  {kw:"nac computer",cat:"NAC",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"nac server",cat:"NAC",funnel:"TOFU",sv:20,prev:'3',cur:1},
  {kw:"network access control methods",cat:"NAC",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"nac computer security",cat:"NAC",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"nac network access control products",cat:"NAC",funnel:"BOFU",sv:20,prev:'1',cur:1},
  {kw:"how to secure iot network",cat:"NAC",funnel:"TOFU",sv:20,prev:'1',cur:3},
  {kw:"transparent firewalls",cat:"NGFW",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"layer 2 firewall",cat:"NGFW",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"network firewall definition",cat:"NGFW",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"firewall security price in usa",cat:"NGFW",funnel:"BOFU",sv:20,prev:'1',cur:1},
  {kw:"difference between application level firewall and network level firewall",cat:"NGFW",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"add a next generation firewall",cat:"NGFW",funnel:"BOFU",sv:20,prev:'1',cur:1},
  {kw:"next generation firewalls ngfw",cat:"NGFW",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"price of hardware firewall",cat:"NGFW",funnel:"BOFU",sv:20,prev:'1',cur:1},
  {kw:"ngfw tools",cat:"NGFW",funnel:"MOFU",sv:20,prev:'4',cur:1},
  {kw:"Shor's and Grover's Algorithms",cat:"Quantum Security",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"Quantum-Risk Assessment",cat:"Quantum Security",funnel:"MOFU",sv:20,prev:'1',cur:1},
  {kw:"sdn wan solutions",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'1',cur:1},
  {kw:"sd wan software defined wan",cat:"SD-WAN",funnel:"TOFU",sv:20,prev:'4',cur:1},
  {kw:"acl access control lists",cat:"NAC",funnel:"TOFU",sv:10,prev:'1',cur:1},
  {kw:"physical firewall prices",cat:"NGFW",funnel:"BOFU",sv:10,prev:'1',cur:1},
  {kw:"Quantum-Safe Security",cat:"Quantum Security",funnel:"TOFU",sv:10,prev:'1',cur:1},
  {kw:"sd wan security measures",cat:"SD-WAN",funnel:"MOFU",sv:10,prev:'6',cur:1},
  {kw:"how ai security works",cat:"AI Cybersecurity",funnel:"TOFU",sv:0,prev:'1',cur:10},
  {kw:"ai cybersecurity applications",cat:"AI Cybersecurity",funnel:"MOFU",sv:0,prev:'1',cur:1},
  {kw:"ai security vendor",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'1',cur:1},
  {kw:"which are the top ai security companies",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'1',cur:1},
  {kw:"what companies provide ai security platforms",cat:"AI Cybersecurity",funnel:"BOFU",sv:0,prev:'1',cur:1},
  {kw:"what is quatum security",cat:"Quantum Security",funnel:"TOFU",sv:0,prev:'1',cur:1},
];

const POS_CATS = ['All','NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities','AI Cybersecurity','OT Security','Quantum Security','SASE'];
const WOW_ROWS = Object.entries(CAT_KEYWORDS)
  .filter(([c])=>POS_CATS.includes(c))
  .flatMap(([c,l])=>l.map(k=>({keyword:k.keyword,category:c,vol:k.vol_jan26,prev:(k.ranks[42]??101) as number,cur:(k.ranks[43]??101) as number})));
const POS_GAIN = WOW_ROWS.filter(r=>r.cur<r.prev&&r.prev<=100).sort((a,b)=>(b.prev-b.cur)-(a.prev-a.cur)||b.vol-a.vol);
const POS_LOSS = WOW_ROWS.filter(r=>r.cur>r.prev&&r.cur<=100).sort((a,b)=>(b.cur-b.prev)-(a.cur-a.prev)||b.vol-a.vol);

const RISK_ROWS = Object.entries(CAT_KEYWORDS).flatMap(([c,l])=>l.map(k=>({keyword:k.keyword,category:c,vol:k.vol_jan26,funnel:(k.funnel||'TOFU') as 'TOFU'|'MOFU'|'BOFU',base:k.ranks[0] as number|null,prev:k.ranks[42] as number|null,cur:k.ranks[43] as number|null})))
  .filter((r,i,a)=>a.findIndex(x=>x.keyword===r.keyword)===i);
const RISK = (()=>{
  const lostSinceDec = RISK_ROWS.filter(r=>r.base!=null&&r.cur!=null&&r.cur>r.base);
  const droppedSinceDec = RISK_ROWS.filter(r=>r.base!=null&&r.cur==null).sort((a,b)=>b.vol-a.vol);
  const atRisk = RISK_ROWS.filter(r=>r.cur==null||r.cur>10).sort((a,b)=>b.vol-a.vol);
  const highRisk = RISK_ROWS.filter(r=>r.cur!=null&&r.cur>10&&r.cur<=40).sort((a,b)=>b.vol-a.vol);
  const perCat = Object.keys(CAT_STATS).map(c=>({
    cat:c,
    declining:CAT_STATS[c].declining,
    notRanking:CAT_STATS[c].not_ranking,
    total:CAT_STATS[c].total,
  })).sort((a,b)=>(b.declining+b.notRanking)-(a.declining+a.notRanking));
  const sumCats = (k:'declining'|'not_ranking')=>Object.values(CAT_STATS).reduce((a,s)=>a+s[k],0);
  return {
    decliners:sumCats('declining'),
    notRanking:sumCats('not_ranking'),
    lostSinceDecCount:lostSinceDec.length,
    droppedCount:droppedSinceDec.length,
    droppedTop:droppedSinceDec.slice(0,12),
    topVol:atRisk[0],
    mostAffected:perCat[0],
    priority:(['TOFU','MOFU','BOFU'] as const).flatMap(f=>highRisk.filter(r=>r.funnel===f).slice(0,5)),
    highRiskCount:highRisk.length,
  };
})();

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCat, setSelectedCat] = useState<string>('NGFW');
  const [posFilter, setPosFilter] = useState<Record<string,string>>({gain:'All',loss:'All',solid:'All',vol:'All'});
  const [selectedFunnel, setSelectedFunnel] = useState<'All'|'TOFU'|'MOFU'|'BOFU'>('All');
  const [selectedRankFilter, setSelectedRankFilter] = useState<'All'|'Rank1'|'Page1'|'Page2_10'|'NotRanking'|'Funnel'>('All');
  const [selectedBlFunnel, setSelectedBlFunnel] = useState<'TOFU'|'MOFU'|'BOFU'>('TOFU');
  const [posInited, setPosInited] = useState(false);
  const [trafficInited, setTrafficInited] = useState(false);
  const [modal1100, setModal1100] = useState(false);
  const [modalNR, setModalNR] = useState(false);
  const [modalAIO, setModalAIO] = useState(false);

  const chartsRef = useRef<Record<string, Chart>>({});

  function makeChart(id: string, cfg: object) {
    if(chartsRef.current[id]) { chartsRef.current[id].destroy(); }
    const ctx = document.getElementById(id) as HTMLCanvasElement | null;
    if(!ctx) return;
    Chart.defaults.color = '#64748B';
    (Chart.defaults as any).borderColor = '#E2E8F0';
    chartsRef.current[id] = new Chart(ctx, cfg as any);
  }

  // Overview charts
  useEffect(() => {
    setTimeout(() => {
      // Weekly R1 Line — 9 categories, 31 weeks
      makeChart('weeklyR1Chart', {
        type:'line',
        data:{
          labels:WEEKS,
          datasets:[
            ...['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities'].map(cat=>({
              label:cat, data:WEEKLY_PAGE1[cat], borderColor:catColor(cat),
              backgroundColor:'transparent', borderWidth:2.5, pointRadius:2.5, pointHoverRadius:6, tension:.35
            })),
            ...['AI Cybersecurity','OT Security','Quantum Security','SASE'].map(cat=>({
              label:cat, data:WEEKLY_PAGE1[cat], borderColor:catColor(cat),
              backgroundColor:'transparent', borderWidth:2, pointRadius:2, pointHoverRadius:5, tension:.35, borderDash:[5,3]
            }))
          ]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:10,color:'#334155',padding:8}}},
          scales:{
            x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},maxRotation:30,color:'#64748B'}},
            y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'},title:{display:true,text:'# at Page 1 (Rank 1–10)',font:{size:10},color:'#64748B'}}
          }
        }
      });

      // Weekly Average Position Line Chart — 9 categories
      makeChart('avgRankChart', {
        type:'line',
        data:{
          labels:WEEKS,
          datasets:[
            ...['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities'].map(cat=>({
              label:cat, data:WEEKLY_AVG_RANK[cat], borderColor:catColor(cat),
              backgroundColor:'transparent', borderWidth:2.5, pointRadius:2, pointHoverRadius:6, tension:.35, spanGaps:true
            })),
            ...['AI Cybersecurity','OT Security','Quantum Security','SASE'].map(cat=>({
              label:cat, data:WEEKLY_AVG_RANK[cat], borderColor:catColor(cat),
              backgroundColor:'transparent', borderWidth:2, pointRadius:2, pointHoverRadius:5, tension:.35, borderDash:[5,3], spanGaps:true
            }))
          ]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{legend:{position:'top',labels:{font:{size:9,weight:'600'},boxWidth:9,color:'#334155',padding:8}}},
          scales:{
            x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},maxRotation:30,color:'#64748B'}},
            y:{reverse:true,min:1,grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'},title:{display:true,text:'Avg Position (lower = better)',font:{size:10},color:'#64748B'}}
          }
        }
      });

      // Trend Line — 44 weeks (Oct 28)
      makeChart('trendLine', {
        type:'line',
        data:{
          labels:WEEKS,
          datasets:[
            {label:'vpn (673K)',data:[41,29,31,33,20,17,25,16,24,null,29,10,17,1,1,1,1,1,17,1,1,1,1,11,1,8,7,8,1,7,8,20,1,13,1,14,19,14,13,12,1,1,1,15],borderColor:'#D93025',backgroundColor:'transparent',borderWidth:2.5,pointRadius:2,tension:.35,spanGaps:true},
            {label:'cybersecurity (201K)',data:[7,8,9,9,8,1,23,10,9,19,8,19,8,1,1,23,1,17,1,11,36,16,9,null,5,7,9,1,1,1,36,1,31,null,1,1,null,1,1,null,24,34,1,1],borderColor:'#1A56DB',backgroundColor:'transparent',borderWidth:2,pointRadius:2,tension:.35,spanGaps:true},
            {label:'proxy (201K)',data:[5,4,5,20,10,7,4,1,9,11,1,7,7,1,9,6,8,20,1,6,6,1,4,5,4,1,11,6,8,6,6,3,5,3,6,3,2,2,3,21,2,6,3,5],borderColor:'#0E7490',backgroundColor:'transparent',borderWidth:2,pointRadius:2,tension:.35},
            {label:'what is malware (135K)',data:[3,1,6,6,1,4,6,1,1,1,8,4,5,5,6,18,14,16,13,16,18,15,1,20,20,18,18,20,null,21,23,1,20,26,32,null,21,19,25,23,20,17,24,null],borderColor:'#7C3AED',backgroundColor:'transparent',borderWidth:2,pointRadius:2,tension:.35},
            {label:'what is phishing (74K)',data:[1,4,4,7,11,8,6,1,9,1,3,1,6,5,1,1,1,1,8,1,1,1,null,1,1,10,1,8,1,10,8,21,10,8,1,8,14,1,9,7,8,8,1,8],borderColor:'#0A7A55',backgroundColor:'transparent',borderWidth:2,pointRadius:2,tension:.35,spanGaps:true},
            {label:'phishing (49.5K)',data:[12,16,17,13,16,16,12,19,5,1,16,26,10,1,6,1,1,1,1,1,1,48,1,1,1,1,1,49,27,57,19,20,26,29,28,24,25,50,67,26,null,null,null,26],borderColor:'#059669',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,tension:.35,borderDash:[4,2]},
            {label:'ips (49.5K)',data:[26,19,18,16,15,17,1,1,1,1,1,18,14,1,1,23,1,1,1,1,21,null,21,21,1,9,13,12,12,7,9,13,10,1,35,7,6,22,15,21,12,21,17,21],borderColor:'#DC2626',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,tension:.35,borderDash:[4,2],spanGaps:true},
            {label:'ddos (33.1K)',data:[4,4,4,4,1,5,4,1,1,1,1,1,1,1,1,1,1,1,1,5,1,1,1,1,6,1,1,1,1,1,1,5,1,1,1,7,1,8,1,1,1,1,1,1],borderColor:'#2563EB',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,tension:.35,borderDash:[4,2]},
            {label:'ransomware (33.1K)',data:[4,3,4,1,1,4,4,4,6,5,5,4,4,1,1,1,1,1,1,1,4,5,5,7,1,6,1,6,6,4,8,7,7,5,1,6,6,9,1,6,6,6,1,1],borderColor:'#9333EA',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,tension:.35,borderDash:[4,2]}
          ]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:12,color:'#334155',padding:8}}},
          scales:{
            x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},maxRotation:30,color:'#64748B'}},
            y:{reverse:true,min:1,max:60,grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'},title:{display:true,text:'Position (1 = Best)',font:{size:10},color:'#64748B'}}
          }
        }
      });

      // WoW Sentiment Distribution — Oct 21→Oct 28 · from 9_Category_With_AIO.csv
      makeChart('wowDistChart', {
        type:'bar',
        data:{
          labels:['↑20+','↑10-20','↑5-10','↑1-5','Stable','↓1-5','↓5-10','↓10-20','↓20+'],
          datasets:[{
            label:'Keywords',
            data:WOW_DIST,
            backgroundColor:['#0A7A55','#059669','#10B981','#6EE7B7','#CBD5E1','#FCA5A5','#F87171','#EF4444','#DC2626'],
            borderRadius:5,borderSkipped:false
          }]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{legend:{display:false}},
          scales:{
            x:{grid:{display:false},ticks:{font:{size:9},maxRotation:30,color:'#64748B'}},
            y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'}}
          }
        }
      });

      // Net WoW per category — Oct 21 → Oct 28 (week-over-week)
      const wowCats = ['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities','AI Cybersecurity','OT Security','Quantum Security','SASE'];
      const wowLabels = ['NGFW','SD-WAN','NAC','Zero Trust','Top Opps','AI Cyber','OT Sec','Quantum','SASE'];
      makeChart('netWowChart', {
        type:'bar',
        data:{
          labels:wowLabels,
          datasets:[
            {label:'↑ Gaining (WoW)',data:wowCats.map(c=>WOW_STATS[c]?.improving||0),backgroundColor:'rgba(10,122,85,.65)',borderRadius:5,borderSkipped:false},
            {label:'→ Stable',data:wowCats.map(c=>WOW_STATS[c]?.stable||0),backgroundColor:'rgba(203,213,225,.7)',borderRadius:5,borderSkipped:false},
            {label:'↓ Losing (WoW)',data:wowCats.map(c=>WOW_STATS[c]?.declining||0),backgroundColor:'rgba(217,48,37,.55)',borderRadius:5,borderSkipped:false}
          ]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{
            legend:{position:'top',labels:{font:{size:11,weight:'600'},boxWidth:12,color:'#334155',padding:12}},
            tooltip:{callbacks:{title:(items:any)=>`${items[0].label} · Oct 21 → Oct 28`}}
          },
          scales:{
            x:{stacked:true,grid:{display:false},ticks:{font:{size:10},color:'#64748B'}},
            y:{stacked:true,grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'}}
          }
        }
      });


      {
        const all9 = ['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities','AI Cybersecurity','OT Security','Quantum Security','SASE'];
        const cc = [...all9].sort((a,b)=>CAT_STATS[b].total-CAT_STATS[a].total);
        const ca = [...all9].sort((a,b)=>CAT_STATS[a].avg_rank-CAT_STATS[b].avg_rank);
        const lab = {id:'valueLabels',afterDatasetsDraw(ch:any){const c=ch.ctx;c.save();c.font='800 12px DM Sans';c.fillStyle='#0B1220';c.textAlign='center';ch.data.datasets.forEach((d:any,i:number)=>{ch.getDatasetMeta(i).data.forEach((b:any,j:number)=>{c.fillText(String(d.data[j]),b.x,b.y-6);});});c.restore();}};
        const opt = (title:string,extra:object={})=>({responsive:true,maintainAspectRatio:false,layout:{padding:{top:20}},plugins:{legend:{position:'top',labels:{font:{size:13,weight:'700'},color:'#0B1220',boxWidth:14}}},scales:{x:{grid:{display:false},ticks:{font:{size:12,weight:'700'},color:'#0B1220',maxRotation:40}},y:{beginAtZero:true,grid:{color:'#E2E8F0'},ticks:{font:{size:12,weight:'700'},color:'#334155'},title:{display:true,text:title,font:{size:12,weight:'700'}},...extra}}});
        makeChart('catTotalsChart',{type:'bar',plugins:[lab],data:{labels:cc,datasets:[
          {label:'Total KWs',data:cc.map(c=>CAT_STATS[c].total),backgroundColor:'#1A56DB',borderRadius:5},
          {label:'Page 1',data:cc.map(c=>CAT_STATS[c].valid),backgroundColor:'#0A7A55',borderRadius:5},
          {label:'NR (Not Ranking)',data:cc.map(c=>CAT_STATS[c].not_ranking),backgroundColor:'#D93025',borderRadius:5}]},options:opt('Keywords')});
        makeChart('catAvgChart',{type:'bar',plugins:[lab],data:{labels:ca,datasets:[
          {label:'Avg Position',data:ca.map(c=>CAT_STATS[c].avg_rank),backgroundColor:ca.map(c=>catColor(c)),borderRadius:5}]},options:{...opt('Avg Position'),plugins:{legend:{display:false}}}});
      }

      // Cat bar — 9 categories Oct 28
      makeChart('catBarChart', {
        type:'bar',
        data:{
          labels:['NGFW','SD-WAN','NAC','ZeroTrust','TopOpps','AI Cyber','OT Sec','Quantum','SASE'],
          datasets:[
            {label:'Page 1',data:['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities','AI Cybersecurity','OT Security','Quantum Security','SASE'].map(c=>CAT_STATS[c].valid),backgroundColor:'rgba(10,122,85,.75)',borderRadius:5,borderSkipped:false},
            {label:'Total',data:[141,130,80,20,49,136,46,28,30],backgroundColor:'rgba(10,122,85,.18)',borderRadius:5,borderSkipped:false}
          ]
        },
        options:{
          responsive:true,maintainAspectRatio:false,
          plugins:{legend:{position:'top',labels:{font:{size:11,weight:'600'},boxWidth:12,color:'#334155',padding:12}}},
          scales:{
            x:{grid:{display:false},ticks:{font:{size:9},color:'#64748B'}},
            y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B'}}
          }
        }
      });
    }, 100);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const renderPositionCharts = useCallback(() => {
    // Vol-weighted Page 1 (rank 1-10) capture rate per category — computed from full CSV Aug 12
    const catLabels = ['NGFW','SASE','SD-WAN','NAC','Zero Trust','OT Sec','Top Opps','Quantum','AI Cyber'];
    const catColors = [
      'rgba(10,122,85,.70)',
      'rgba(6,182,212,.70)',
      'rgba(180,83,9,.70)',
      'rgba(26,86,219,.70)',
      'rgba(124,58,237,.70)',
      'rgba(99,102,241,.70)',
      'rgba(217,48,37,.70)',
      'rgba(236,72,153,.70)',
      'rgba(245,158,11,.70)',
    ];
    // Pre-computed: page1Vol / totalVol × 100 per category (all keywords, Oct 28)
    const velScores = [99.3,68.2,92.8,78.8,84.6,93.4,39.6,13.8,50.7]; // Oct 28

    const velCtx = document.getElementById('velocityChart') as HTMLCanvasElement | null;
    if (!velCtx) return;
    if (chartsRef.current['velocityChart']) chartsRef.current['velocityChart'].destroy();
    chartsRef.current['velocityChart'] = new Chart(velCtx, {
      type: 'bar',
      data: {
        labels: catLabels,
        datasets: [{
          label: '% Vol at Page 1',
          data: velScores,
          backgroundColor: catColors,
          borderRadius: 7,
          borderSkipped: false,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx: any) => ` ${ctx.parsed.x}% of tracked vol at Page 1 (rank 1–10)`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: '#F1F5F9' },
            ticks: { color: '#64748B', font: { size: 11 }, callback: (v: any) => `${v}%` },
            max: 100,
          },
          y: {
            grid: { display: false },
            ticks: { color: '#334155', font: { size: 12, weight: '600' } },
          },
        },
      },
    } as any);

    // Force a resize so the chart fills its container correctly
    setTimeout(() => {
      chartsRef.current['velocityChart']?.resize();
    }, 50);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function openFromHome(tab: string, cat?: string) {
    if(cat) setSelectedCat(cat);
    handleTabSwitch(tab);
  }

  function handleTabSwitch(id: string) {
    setActiveTab(id);
    window.scrollTo({top:0,behavior:'smooth'});
    if(id === 'position' && !posInited) {
      setPosInited(true);
      setTimeout(() => { renderPositionCharts(); window.dispatchEvent(new Event('resize')); }, 100);
    }
    if(id === 'traffic' && !trafficInited) {
      setTrafficInited(true);
      setTimeout(() => { renderTrafficCharts(); window.dispatchEvent(new Event('resize')); }, 100);
    }
    // Trigger chart resize after tab becomes visible
    setTimeout(() => window.dispatchEvent(new Event('resize')), 60);
  }

  const renderTrafficCharts = useCallback(() => {
    // GSC — Organic search traffic trend (area + lines)
    makeChart('trafficOrgChart', {
      type:'line',
      data:{
        labels: TRAFFIC_WEEKS,
        datasets:[
          {label:'All Organic',data:TRAFFIC_DATA.allOrganic,borderColor:'#1A56DB',backgroundColor:'rgba(26,86,219,.07)',borderWidth:2.5,pointRadius:2.5,pointHoverRadius:6,tension:.38,fill:true},
          {label:'Branded',data:TRAFFIC_DATA.branded,borderColor:'#7C3AED',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[5,3]},
          {label:'Non-Branded',data:TRAFFIC_DATA.nonBranded,borderColor:'#0A7A55',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38},
        ]
      },
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:10,color:'#334155',padding:10}},tooltip:{callbacks:{label:(ctx:any)=>`${ctx.dataset.label}: ${Number(ctx.raw)?.toLocaleString()}`}}},scales:{x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},autoSkip:false,minRotation:45,maxRotation:45,color:'#64748B'}},y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B',callback:(v:any)=>v>=1000?`${(v/1000).toFixed(0)}K`:v},title:{display:true,text:'Weekly Sessions (GSC)',font:{size:10},color:'#64748B'}}}}
    });

    // GA — Page-level traffic 33-week line
    makeChart('trafficPageChart', {
      type:'line',
      data:{
        labels: TRAFFIC_WEEKS,
        datasets:[
          {label:'/cyberglossary',data:TRAFFIC_DATA.cyberglossary,borderColor:'#D93025',backgroundColor:'transparent',borderWidth:2.5,pointRadius:2,pointHoverRadius:6,tension:.38},
          {label:'/products',data:TRAFFIC_DATA.products,borderColor:'#B45309',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38},
          {label:'/home page',data:TRAFFIC_DATA.homePage,borderColor:'#0E7490',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38},
          {label:'/blog',data:TRAFFIC_DATA.blog,borderColor:'#059669',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[4,2]},
          {label:'/solutions',data:TRAFFIC_DATA.solutions,borderColor:'#7C3AED',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[4,2]},
          {label:'/about-us',data:TRAFFIC_DATA.aboutUs,borderColor:'#EC4899',backgroundColor:'transparent',borderWidth:1.5,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[4,2]},
        ]
      },
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:10,color:'#334155',padding:8}},tooltip:{callbacks:{label:(ctx:any)=>`${ctx.dataset.label}: ${Number(ctx.raw)?.toLocaleString()}`}}},scales:{x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},maxRotation:30,autoSkip:false,color:'#64748B',callback:(val:any,idx:number)=>(idx===41||(idx%4===0&&idx<39))?val:''}},y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B',callback:(v:any)=>v>=1000?`${(v/1000).toFixed(0)}K`:v},title:{display:true,text:'Weekly Sessions (GA)',font:{size:10},color:'#64748B'}}}}
    });

    // GA — Direct traffic comparison: Direct vs Direct (Valid)
    makeChart('trafficDirectChart', {
      type:'line',
      data:{
        labels: TRAFFIC_WEEKS,
        datasets:[
          {label:'Direct (All)',data:TRAFFIC_DATA.directGA,borderColor:'#7C3AED',backgroundColor:'rgba(124,58,237,.07)',borderWidth:2.5,pointRadius:2.5,pointHoverRadius:6,tension:.38,fill:true},
          {label:'Direct (Valid — excl. email/live-chat/Nexus)',data:TRAFFIC_DATA.directValid,borderColor:'#F59E0B',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[5,3]},
          {label:'Direct (Valid — excl. Downloads)',data:TRAFFIC_DATA.directDownloads,borderColor:'#0E7490',backgroundColor:'transparent',borderWidth:2,pointRadius:2,pointHoverRadius:5,tension:.38,borderDash:[3,4]},
        ]
      },
      options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:10,color:'#334155',padding:10}},tooltip:{callbacks:{label:(ctx:any)=>`${ctx.dataset.label}: ${Number(ctx.raw)?.toLocaleString()}`}}},scales:{x:{grid:{color:'#F1F5F9'},ticks:{font:{size:9},autoSkip:false,minRotation:45,maxRotation:45,color:'#64748B'}},y:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B',callback:(v:any)=>v>=1000?`${(v/1000).toFixed(0)}K`:v},title:{display:true,text:'Weekly Sessions (GA)',font:{size:10},color:'#64748B'}}}}
    });

    // GA — Horizontal bar: page sessions Oct 21 vs Oct 28
    makeChart('trafficPageBarChart', {
      type:'bar',
      data:{
        labels:['/cyberglossary','/products','/home page','/blog','/solutions','/about-us','/articles'],
        datasets:[
          {label:'Oct 21',data:[TRAFFIC_DATA.cyberglossary[42],TRAFFIC_DATA.products[42],TRAFFIC_DATA.homePage[42],TRAFFIC_DATA.blog[42],TRAFFIC_DATA.solutions[42],TRAFFIC_DATA.aboutUs[42],TRAFFIC_DATA.articles[42]],backgroundColor:'rgba(100,116,139,.4)',borderRadius:3,borderSkipped:false},
          {label:'Oct 28',data:[TRAFFIC_DATA.cyberglossary[43],TRAFFIC_DATA.products[43],TRAFFIC_DATA.homePage[43],TRAFFIC_DATA.blog[43],TRAFFIC_DATA.solutions[43],TRAFFIC_DATA.aboutUs[43],TRAFFIC_DATA.articles[43]],backgroundColor:['rgba(217,48,37,.75)','rgba(180,83,9,.75)','rgba(14,116,144,.75)','rgba(5,150,105,.75)','rgba(124,58,237,.75)','rgba(236,72,153,.75)','rgba(100,116,139,.75)'],borderRadius:3,borderSkipped:false},
        ]
      },
      options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'top',labels:{font:{size:10,weight:'600'},boxWidth:10,color:'#334155',padding:8}},tooltip:{callbacks:{label:(ctx:any)=>`${ctx.dataset.label}: ${Number(ctx.raw)?.toLocaleString()}`}}},scales:{x:{grid:{color:'#F1F5F9'},ticks:{font:{size:10},color:'#64748B',callback:(v:any)=>v>=1000?`${(v/1000).toFixed(0)}K`:v}},y:{grid:{display:false},ticks:{font:{size:10,weight:'600'},color:'#334155'}}}}
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Solid R1 list — keywords at #1 for most of 34 weeks

  const volWeightedCats = [
    {name:'NGFW',score:32.7,color:'var(--green)'},
    {name:'SD-WAN',score:44.8,color:'var(--amber)'},
    {name:'NAC',score:26.2,color:'var(--blue)'},
    {name:'Zero Trust',score:9.6,color:'var(--purple)'},
    {name:'Top Opps',score:15.6,color:'var(--red)'}
  ];

  const scorecardStatuses: Record<string,{label:string;color:string}> = {
    'NGFW':{label:'⚠ Softening',color:'var(--amber)'},
    'SD-WAN':{label:'⚠ Softening',color:'var(--amber)'},
    'NAC':{label:'⚠ Declining',color:'var(--red)'},
    'Zero Trust':{label:'⚠ Declining',color:'var(--red)'},
    'Top Opportunities':{label:'⚠ Declining',color:'var(--red)'},
    'AI Cybersecurity':{label:'🆕 New',color:'#F59E0B'},
    'OT Security':{label:'✅ Stable',color:'var(--green)'},
    'Quantum Security':{label:'🆕 New',color:'#EC4899'},
    'SASE':{label:'🆕 New · 50% P1',color:'#06B6D4'}
  };

  function buildCatTableHtml(kws: KW[]): string {
    function sparklineSvg(ranks: (number|null)[]): string {
      const W = 120, H = 28, NR = 101;
      const mapped = ranks.map(r => (r === null || r === undefined) ? NR : r);
      const anyRanked = mapped.some(r => r < NR);
      if (!anyRanked) return `<svg width="${W}" height="${H}"></svg>`;
      const maxR = Math.max(...mapped);
      const pts: string[] = [];
      mapped.forEach((r, i) => {
        const x = (i / (mapped.length - 1)) * (W - 4) + 2;
        const y = maxR === 1 ? 2 : ((r - 1) / (maxR - 1)) * (H - 4) + 2;
        pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
      });
      return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><polyline points="${pts.join(' ')}" fill="none" stroke="#1E293B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${pts[pts.length-1].split(',')[0]}" cy="${pts[pts.length-1].split(',')[1]}" r="2.5" fill="#1E293B"/></svg>`;
    }
    function cellStyle(r: number | null): string {
      if (r === null || r === undefined) return 'text-align:center;color:#94A3B8;font-size:11px;font-family:\'DM Mono\',monospace;font-weight:600';
      const bg = rankColor(r);
      const col = rankTextColor(r);
      return `text-align:center;background:${bg};color:${col};font-weight:700;font-size:12px;font-family:'DM Mono',monospace`;
    }
    return `<table style="width:100%;border-collapse:collapse;font-size:12px">
      <thead><tr style="border-bottom:2px solid #E2E8F0">
        <th style="text-align:left;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap;min-width:180px">Keyword</th>
        <th style="text-align:right;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Vol<br/><span style="font-weight:500;font-size:9px">Search</span></th>
        <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Baseline<br/><span style="font-weight:500;font-size:9px">Dec 31</span></th>
        <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Oct 21<br/><span style="font-weight:500;font-size:9px">Prev Week</span></th>
        <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#1A56DB;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Oct 28<br/><span style="font-weight:500;font-size:9px">Latest</span></th>
        <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Δ WoW<br/><span style="font-weight:500;font-size:9px">WoW Oct 21 → Oct 28</span></th>
        <th style="text-align:center;padding:8px 16px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">44-Week Trend<br/><span style="font-weight:500;font-size:9px">Dec → Oct 28</span></th>
      </tr></thead>
      <tbody>
      ${kws.map((d,i) => {
        const dec31 = d.ranks[0];
        const aug12 = d.ranks[42] ?? null;  // Oct 21 (prev week)
        const aug19 = d.ranks[43] ?? d.current_rank;  // Oct 28 (latest)
        const chg = (aug19 !== null && aug12 !== null) ? (aug19 - aug12) : null;
        const chgColor = chg === null ? '#64748B' : chg < 0 ? '#0A7A55' : chg > 0 ? '#D93025' : '#64748B';
        const chgLabel = chg === null ? '—' : chg < 0 ? `↑${Math.abs(chg)}` : chg > 0 ? `↓${chg}` : '—';
        const vol = d.vol_jan26 >= 1000 ? `${(d.vol_jan26/1000).toFixed(d.vol_jan26>=10000?0:1)}K` : d.vol_jan26 > 0 ? String(d.vol_jan26) : '—';
        return `<tr style="border-bottom:1px solid #F1F5F9;background:${i%2===0?'#ffffff':'#FAFBFC'}">
          <td style="padding:7px 12px;font-weight:700;color:#0F172A;white-space:nowrap">${d.keyword}</td>
          <td style="padding:7px 12px;text-align:right;font-size:11px;font-family:'DM Mono',monospace;font-weight:600;color:#64748B;white-space:nowrap">${vol}</td>
          <td style="${cellStyle(dec31)};padding:7px 12px">${dec31??101}</td>
          <td style="${cellStyle(aug12)};padding:7px 12px">${aug12??101}</td>
          <td style="${cellStyle(aug19)};padding:7px 12px;border:1.5px solid rgba(26,86,219,.25)">${aug19??101}</td>
          <td style="text-align:center;padding:7px 12px;font-weight:700;font-size:12px;font-family:'DM Mono',monospace;color:${chgColor}">${chgLabel}</td>
          <td style="padding:5px 16px;text-align:center">${sparklineSvg(d.ranks)}</td>
        </tr>`;
      }).join('')}
      </tbody>
    </table>`;
  }

  const B = (t:string|number)=><strong>{t}</strong>;
  const tf = (k:keyof typeof TRAFFIC_DATA)=>{const v=TRAFFIC_DATA[k][43];return v>=100000?Math.round(v/1000)+'K':v>=1000?(v/1000).toFixed(1)+'K':String(v);};
  const sg = (n:number)=>`${n>=0?'+':'−'}${Math.abs(n).toLocaleString()}`;
  const ab = (n:number)=>`${Math.abs(n).toFixed(2)}%`;
  const sp = (n:number)=>`${n>=0?'+':'−'}${Math.abs(n).toFixed(2)}%`;

  const overviewInsights: InsightItem[] = [
    {tone:'red',title:'Page 1 slipped this week',body:<>{B('444 of 660')} tracked keywords rank on Page 1 (67.3%), down {B(47)} from 491 last week. Rank #1 fell to {B(329)} ({B('−28')} WoW).</>},
    {tone:'blue',title:'Not Ranking held steady',body:<>{B(82)} keywords are not ranking, {B('−1')} vs 83 last week. {B('AI Cybersecurity')} still holds {B(48)} of them (59%), the main remaining gap.</>},
    {tone:'amber',title:'Room to recover',body:<>{B(RANK_11_100.length)} keywords sit on Pages 2–10 (ranks 11–100), up from 86 last week as {B('NGFW')} and {B('SD-WAN')} slid off Page 1. They are the nearest-term opportunity to push back onto Page 1.</>},
  ];
  const tvR1 = TOP_VOL.filter(d=>d.current_rank===1).length;
  const tvNR = TOP_VOL.filter(d=>d.current_rank===null).length;
  const kwperfInsights: InsightItem[] = [
    {tone:'green',title:'Rank #1 wins on high volume',body:<>{B(tvR1)} of the {B(TOP_VOL.length)} highest-volume keywords hold position #1 this week.</>,icon:'ok'},
    {tone:'blue',title:'Funnel mix of #1 rankings',body:<>Of {B(329)} keywords at #1, {B(293)} are TOFU/MOFU and {B(36)} are BOFU. Bottom-funnel #1s slipped by only 2 WoW, while TOFU/MOFU lost 26.</>},
    {tone:'red',title:'High-volume gaps',body:<>{B(tvNR)} top-volume keywords are not ranking, led by {B('zero day')} (368K SV) and {B('what is malware')} (135K SV, dropped from #24). {B('vpn')} (673K) slipped from #1 to {B('#15')}.</>,icon:'warn'},
  ];
  const topGain = POS_GAIN[0], topLoss = POS_LOSS[0];
  const posInsights: InsightItem[] = [
    {tone:POS_GAIN.length>=POS_LOSS.length?'green':'amber',title:POS_GAIN.length>=POS_LOSS.length?'Gainers lead the week':'Decliners outnumber gainers',body:<>{B(POS_GAIN.length)} keywords improved vs {B(POS_LOSS.length)} that declined WoW. Biggest jump: {B(topGain.keyword)} (#{topGain.prev} → #{topGain.cur}).</>},
    {tone:'red',title:'Biggest drop to recover',body:<>{B(topLoss.keyword)} fell #{topLoss.prev} → #{topLoss.cur}. Only keywords ranked in both weeks are listed, so NR moves are excluded.</>},
    {tone:'blue',title:'Stable core, volatile edge',body:<>{B(solidR1.length)} keywords have held #1 for 24+ weeks, while the top {B(volatileKws.length)} zig-zag keywords reverse direction up to {B(volatileKws[0].reversals)} times across 44 weeks.</>},
  ];
  const cs = CAT_STATS[selectedCat], ws = WOW_STATS[selectedCat], wm = WOW_MOVERS[selectedCat];
  const catInsights: InsightItem[] = cs && ws ? [
    {tone:cs.pct as number>=75?'green':'amber',title:`${selectedCat}: Page 1 coverage`,body:<>{B(`${cs.valid} of ${cs.total}`)} keywords are on Page 1 ({B(`${cs.pct}%`)}), with {B(cs.rank1)} at #1 and an average position of {B(cs.avg_rank)}.</>,icon:'ok'},
    {tone:ws.net>=0?'green':'red',title:ws.net>=0?'Net gain week over week':'Net loss week over week',body:<>{B(ws.improving)} keywords improved and {B(ws.declining)} declined, a net of {B(`${ws.net>=0?'+':'−'}${Math.abs(ws.net)}`)}. {wm?.gainers[0]&&<>Top gain: {B(wm.gainers[0].kw)} (#{wm.gainers[0].from} → #{wm.gainers[0].to}). </>}{wm?.decliners[0]&&<>Top drop: {B(wm.decliners[0].kw)} (#{wm.decliners[0].from} → #{wm.decliners[0].to}).</>}</>,icon:ws.net>=0?'up':'down'},
    {tone:cs.not_ranking>10?'red':'blue',title:cs.not_ranking>0?'Growth opportunity':'Full visibility',body:cs.not_ranking>0?<>{B(cs.not_ranking)} keywords are not ranking ({B(`${Math.round(cs.not_ranking/cs.total*100)}%`)} of the set). Content for these terms is the largest upside.</>:<>Every tracked keyword in this category ranks in the top 100. Focus on lifting Page 1 keywords to #1.</>,icon:'info'},
  ] : [
    {tone:'blue',title:'Backlink view',body:<>Compare keywords with and without backlinks to see where link-building lifts rankings.</>},
    {tone:'green',title:'Page 1 leaders',body:<>{B(444)} of 660 keywords rank on Page 1 and {B(329)} sit at #1 across all categories.</>},
    {tone:'amber',title:'Watch list',body:<>{B(82)} keywords are not ranking. Select a category tab to see its share.</>},
  ];
  const riskInsights: InsightItem[] = [
    {tone:'red',title:'Biggest single risk',body:<>{B('zero day')} (368K SV) and {B('what is malware')} (135K SV, dropped off from #24) are off the SERP. Together they represent 503K monthly searches. In total, {B(RISK.notRanking)} of 660 keywords are not ranking and {B(RISK.decliners)} declined week over week ({RISK.mostAffected.cat} is most affected).</>},
    {tone:'amber',title:'AI Cybersecurity exposure',body:<>{B(`${CAT_STATS['AI Cybersecurity'].not_ranking} of ${CAT_STATS['AI Cybersecurity'].total}`)} AI Cybersecurity keywords are not ranking, {B(CAT_STATS['AI Cybersecurity'].declining)} declined WoW (23 lost positions, 8 dropped off), and only {B(`${CAT_STATS['AI Cybersecurity'].pct}%`)} are on Page 1, the weakest coverage of the 9 categories.</>},
    {tone:'blue',title:'NGFW and SD-WAN losing Page 1',body:<>{B('NGFW')} declined on {B(39)} keywords (35 lost positions, 4 dropped off) and Page 1 fell from 132 to {B(114)}. {B('SD-WAN')} had {B(49)} decliners and Page 1 fell from 97 to {B(84)}, the largest losses of the 9 categories.</>},
  ];
  const gainInsights: InsightItem[] = [
    {tone:'green',title:'Branded traffic surged',body:<>Branded GSC traffic rose {B('+23.42%')} ({B('+27,659')} clicks); the top 3 URLs gained {B('+12,228')}, led by the {B('security hardening release')} blog post ({B('+8,647')}, new this week) and the {B('fortinet.com')} homepage ({B('+2,076')}, {B('+29.1%')}).</>,icon:'ok'},
    {tone:'green',title:'International markets grew',body:<>The top international URLs rose {B('+51.7%')} ({B('+5,066')}), with {B('/lat/support/product-downloads')} up {B('+2,079')} and the {B('/jp/ hardening release')} post up {B('+2,987')}. {B('forticlient')} keywords gained {B('+2,420')} clicks ({B('+9.1%')}).</>,icon:'ok'},
    {tone:'green',title:'Valid direct traffic jumped',body:<>Direct (Relevant) grew {B('+45.24%')} ({B('+40,587')}), almost entirely the {B('security hardening release')} post ({B('+38,906')} from zero), with {B('/blog')} up {B('+815')} ({B('+277.2%')}).</>,icon:'ok'},
    {tone:'amber',title:'Referrals and blog spiked on one post',body:<>Referrals rose {B('+107.41%')} ({B('+12,692')}) and {B('/blog (GA)')} rose {B('+720.37%')} ({B('+16,194')}); the hardening release post drove {B('+9,638')} and {B('+11,958')}. Top gaining keywords: {B('fortinet')} ({B('+4,326')}) and {B('fortinet vulnerability')} ({B('+1,460')}).</>},
  ];
  const trafficInsights: InsightItem[] = [
    {tone:'green',title:'Organic traffic rebounded',body:<>All Organic Traffic is {B(tf('allOrganic'))}, up {B(ab(TRAFFIC_WOW.allOrganic.pct))} ({B(sg(TRAFFIC_WOW.allOrganic.abs))}) WoW (Oct 21 → Oct 28). Branded is {B(tf('branded'))} and Non-Branded {B(tf('nonBranded'))}.</>,icon:'ok'},
    {tone:'blue',title:'Branded rose faster than non-branded',body:<>Branded rose {B(ab(TRAFFIC_WOW.branded.pct))} ({B(sg(TRAFFIC_WOW.branded.abs))}) while Non-Branded rose {B(ab(TRAFFIC_WOW.nonBranded.pct))} ({B(sg(TRAFFIC_WOW.nonBranded.abs))}), so most of the lift comes from brand queries.</>,icon:'info'},
    {tone:'green',title:'Content pages jumped',body:<>/blog rose {B(ab(TRAFFIC_WOW.blog.pct))} ({B(sg(TRAFFIC_WOW.blog.abs))}), /about-us {B(ab(TRAFFIC_WOW.aboutUs.pct))}, /home page {B(ab(TRAFFIC_WOW.homePage.pct))}, /products {B(ab(TRAFFIC_WOW.products.pct))} and /articles {B(ab(TRAFFIC_WOW.articles.pct))}, while /cyberglossary grew a steadier {B(sp(TRAFFIC_WOW.cyberglossary.pct))}.</>,icon:'ok'},
    {tone:'green',title:'Direct and referral traffic spiked',body:<>Direct (All) rose {B(sp(TRAFFIC_WOW.directGA.pct))} to {B(tf('directGA'))} and Direct (Valid) rose {B(sp(TRAFFIC_WOW.directValid.pct))} to {B(tf('directValid'))}. Referrals rose {B(ab(TRAFFIC_WOW.referrals.pct))} to {B(tf('referrals'))}, largely from the security hardening release post.</>},
  ];

  return (
    <div style={{fontFamily:"'DM Sans',sans-serif",background:'#F5F7FA',color:'#0F172A',fontSize:13,lineHeight:1.5,minHeight:'100vh',overflowX:'hidden'}}>
      <div className="fn-page">

        {/* HEADER */}
        <div className="fn-header">
          <div className="fn-logo-box">
            <ImageWithFallback src={fortinetLogo} alt="Fortinet logo" className="fn-logo-img" />
          </div>
          <div className="fn-header-body">
            <div className="fn-header-eyebrow">SEO INTELLIGENCE</div>
            <div className="fn-header-title">Fortinet Week Over Week Metrics</div>
            <div className="fn-header-sub">Dec 31, 2025 → Oct 28, 2026 · Weekly Avg Base Rank · 660 Keywords · 9 Product Categories</div>
          </div>
          <div className="fn-header-badges">
            <span className="fn-badge fn-badge-green"><span className="fn-live-dot"></span>329 at #1</span>
            <span className="fn-badge fn-badge-blue">44 Weeks Tracked</span>
            <span className="fn-badge fn-badge-amber">Oct 28, 2026</span>
            <span className="fn-badge fn-badge-red">Live</span>
          </div>
        </div>

        {/* TABS */}
        <div className="fn-tabs-bar">
          <button className={`fn-tab-btn fn-tab-home${activeTab==='home'?' active':''}`} onClick={()=>handleTabSwitch('home')} title="Home" aria-label="Home">⌂ Home</button>
          {[
            {id:'traffic',label:'📈 Traffic Overview'},
            {id:'overview',label:'⬡ Position Overview'},
            {id:'kwperf',label:'🔑 Keyword Performance'},
            {id:'position',label:'📍 Keyword Position Insight'},
            {id:'categories',label:'◫ By Category'},
            {id:'risk',label:'⚠ Top Risk'},
            {id:'gainloss',label:'📊 Gain & Loss'}
          ].map(t=>(
            <button
              key={t.id}
              className={`fn-tab-btn${activeTab===t.id?' active':''}`}
              onClick={()=>handleTabSwitch(t.id)}
            >{t.label}</button>
          ))}
        </div>

        {/* ═══ HOME ═══ */}
        <div className={`fn-tab-panel${activeTab==='home'?' active':''}`}>
          <HomePage onOpen={openFromHome} />
        </div>

        {/* ═══ OVERVIEW ═══ */}
        <div className={`fn-tab-panel${activeTab==='overview'?' active':''}`}>
          <TabHead eyebrow="02 — POSITION OVERVIEW" title="Position Overview" sub="Rank #1, Page 1 and not-ranking totals across 660 keywords" accent="#1A56DB" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={overviewInsights} />
          <div className="fn-kpi-strip">
            <div className="fn-kpi fn-kpi-green">
              <div className="fn-kpi-label">Rank #1 Keywords</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val green">329</div>
                <span style={{fontSize:13,fontWeight:700,color:'#D93025',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>▼ 7.8% WoW</span>
              </div>
              <div style={{fontSize:11,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",letterSpacing:'.02em',marginTop:2,marginBottom:2}}>Prev 357</div>
              <div className="fn-kpi-sub">49.8% of all tracked</div>
            </div>
            <div className="fn-kpi fn-kpi-blue">
              <div className="fn-kpi-label">Page 1</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val blue">444</div>
                <span style={{fontSize:13,fontWeight:700,color:'#D93025',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>▼ 9.6% WoW</span>
              </div>
              <div style={{fontSize:11,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",letterSpacing:'.02em',marginTop:2,marginBottom:2}}>Prev 491</div>
              <div className="fn-kpi-sub">67.3% of all tracked keywords</div>
            </div>
            <div className="fn-kpi fn-kpi-cyan">
              <div className="fn-kpi-label">Rank 11–100</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val cyan">{RANK_11_100.length}</div>
                <span style={{fontSize:13,fontWeight:700,color:'#D93025',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>▲ {((RANK_11_100.length-86)/86*100).toFixed(1)}% WoW</span>
              </div>
              <div style={{fontSize:11,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",letterSpacing:'.02em',marginTop:2,marginBottom:2}}>Prev 86</div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:4}}>
                <div className="fn-kpi-sub" style={{margin:0}}>{(RANK_11_100.length/660*100).toFixed(1)}% of all tracked</div>
                <button onClick={()=>setModal1100(true)} style={{fontSize:10,fontWeight:700,color:'#fff',background:'#F97316',border:'none',borderRadius:20,padding:'2px 10px',cursor:'pointer',fontFamily:"'DM Mono',monospace",letterSpacing:'.03em',whiteSpace:'nowrap'}}>VIEW LIST</button>
              </div>
            </div>
            <div className="fn-kpi fn-kpi-amber">
              <div className="fn-kpi-label">Not Ranking</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val amber">{NOT_RANKING.length}</div>
                <span style={{fontSize:13,fontWeight:700,color:'#059669',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>▼ 1.2% WoW</span>
              </div>
              <div style={{fontSize:11,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",letterSpacing:'.02em',marginTop:2,marginBottom:2}}>Prev 83</div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:4}}>
                <div className="fn-kpi-sub" style={{margin:0}}>{(NOT_RANKING.length/660*100).toFixed(1)}% of all tracked</div>
                <button onClick={()=>setModalNR(true)} style={{fontSize:10,fontWeight:700,color:'#fff',background:'#F97316',border:'none',borderRadius:20,padding:'2px 10px',cursor:'pointer',fontFamily:"'DM Mono',monospace",letterSpacing:'.03em',whiteSpace:'nowrap'}}>VIEW LIST</button>
              </div>
            </div>
            <div className="fn-kpi" style={{background:'rgba(99,102,241,.07)',border:'1.5px solid rgba(99,102,241,.25)'}}>
              <div className="fn-kpi-label" style={{color:'#4338CA'}}>AIO Keywords</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val" style={{color:'#4338CA'}}>{AIO_KEYWORDS.length}</div>
                <span style={{fontSize:13,fontWeight:700,color:AIO_KEYWORDS.length>=353?'#059669':'#D93025',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>{AIO_KEYWORDS.length>=353?'▲':'▼'} {(Math.abs(AIO_KEYWORDS.length-353)/353*100).toFixed(1)}% WoW</span>
              </div>
              <div style={{fontSize:11,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",letterSpacing:'.02em',marginTop:2,marginBottom:2}}>Prev 353</div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:4}}>
                <div className="fn-kpi-sub" style={{margin:0}}>{(AIO_KEYWORDS.length/660*100).toFixed(1)}% of all tracked</div>
                <button onClick={()=>setModalAIO(true)} style={{fontSize:10,fontWeight:700,color:'#fff',background:'#4338CA',border:'none',borderRadius:20,padding:'2px 10px',cursor:'pointer',fontFamily:"'DM Mono',monospace",letterSpacing:'.03em',whiteSpace:'nowrap'}}>VIEW LIST</button>
              </div>
            </div>
            <div className="fn-kpi fn-kpi-red">
              <div className="fn-kpi-label">Total Tracked</div>
              <div style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:6}}>
                <div className="fn-kpi-val red">660</div>
                <span style={{fontSize:13,fontWeight:600,color:'#94A3B8',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',letterSpacing:'.01em'}}>0.0% WoW</span>
              </div>
              <div className="fn-kpi-sub">9 product categories</div>
            </div>
          </div>

          {/* Funnel KPI Strip — TOFU / MOFU / BOFU */}
          {(()=>{
            const cols = [
              {
                intent:'TOFU',
                label:'Top of Funnel',
                desc:'Informational / Awareness',
                color:'#1A56DB', colorVar:'var(--blue)', bgVar:'rgba(26,86,219,.07)', border:'rgba(26,86,219,.2)',
                keywords:446, page1:329, rank1:251,
                kwPct:((446/660)*100).toFixed(1),
                p1Pct:((329/446)*100).toFixed(1),
              },
              {
                intent:'MOFU',
                label:'Middle of Funnel',
                desc:'Consideration / Evaluation',
                color:'#0E7490', colorVar:'var(--cyan)', bgVar:'rgba(14,116,144,.07)', border:'rgba(14,116,144,.2)',
                keywords:130, page1:69, rank1:42,
                kwPct:((130/660)*100).toFixed(1),
                p1Pct:((69/130)*100).toFixed(1),
              },
              {
                intent:'BOFU',
                label:'Bottom of Funnel',
                desc:'Commercial / Purchase Intent',
                color:'#7C3AED', colorVar:'var(--purple)', bgVar:'rgba(124,58,237,.07)', border:'rgba(124,58,237,.2)',
                keywords:84, page1:46, rank1:36,
                kwPct:((84/660)*100).toFixed(1),
                p1Pct:((46/84)*100).toFixed(1),
              },
            ];
            return (
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:18}}>
                {cols.map(c=>(
                  <div key={c.intent} style={{background:c.bgVar,border:`1.5px solid ${c.border}`,borderRadius:12,padding:'16px 18px',position:'relative',overflow:'hidden'}}>
                    {/* top accent */}
                    <div style={{position:'absolute',top:0,left:0,right:0,height:3,background:c.color,borderRadius:'12px 12px 0 0'}}/>
                    {/* intent badge + label */}
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10,marginTop:2}}>
                      <span style={{fontSize:10,fontWeight:900,padding:'2px 8px',borderRadius:4,letterSpacing:'.08em',
                        background:c.color,color:'#fff',fontFamily:"'DM Mono',monospace"}}>{c.intent}</span>
                      <div>
                        <div style={{fontSize:10,fontWeight:700,color:'var(--text)',lineHeight:1}}>{c.label}</div>
                        <div style={{fontSize:8,color:'var(--text3)',marginTop:1}}>{c.desc}</div>
                      </div>
                    </div>
                    {/* 3-metric row */}
                    <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8,marginBottom:12}}>
                      {[
                        {label:'Keywords',val:c.keywords,sub:null,color:'var(--text)'},
                        {label:'Rank #1',val:c.rank1,sub:`${((c.rank1/c.keywords)*100).toFixed(0)}% of intent`,color:'#059669'},
                        {label:'Page 1',val:c.page1,sub:`${((c.page1/c.keywords)*100).toFixed(0)}% of intent`,color:c.color},
                      ].map((m,i)=>(
                        <div key={i} style={{background:'rgba(255,255,255,.6)',borderRadius:8,padding:'8px 10px',textAlign:'center',border:'1px solid rgba(0,0,0,.05)'}}>
                          <div style={{fontSize:8,fontWeight:700,color:'var(--text3)',fontFamily:"'DM Mono',monospace",textTransform:'uppercase',letterSpacing:'.05em',marginBottom:4}}>{m.label}</div>
                          <div style={{fontSize:22,fontWeight:900,color:m.color,fontFamily:"'DM Mono',monospace",lineHeight:1}}>{m.val}</div>
                          <div style={{fontSize:8,color:'var(--text3)',marginTop:3}}>{m.sub}</div>
                        </div>
                      ))}
                    </div>
                    {/* Page 1 progress bar */}
                    <div style={{fontSize:8,color:'var(--text3)',fontFamily:"'DM Mono',monospace",marginBottom:3,textTransform:'uppercase',letterSpacing:'.04em'}}>Page 1 Coverage</div>
                    <div style={{height:5,background:'rgba(0,0,0,.07)',borderRadius:3,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${c.p1Pct}%`,background:c.color,borderRadius:3,transition:'width .4s'}}/>
                    </div>
                    <div style={{display:'flex',justifyContent:'space-between',marginTop:3}}>
                      <span style={{fontSize:8,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>{c.page1} of {c.keywords} on Page 1</span>
                      <span style={{fontSize:9,fontWeight:800,color:c.color,fontFamily:"'DM Mono',monospace"}}>{c.p1Pct}%</span>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}

          {/* ══ Category bar charts ══ */}
          <div className="fn-wowstrip">
            {(()=>{
              const g=Object.values(WOW_STATS).reduce((a,w)=>a+w.improving,0), d=Object.values(WOW_STATS).reduce((a,w)=>a+w.declining,0), st=Object.values(WOW_STATS).reduce((a,w)=>a+w.stable,0), n=g-d;
              return [
                {v:g,l:'GAINING',c:'#0A7A55'},{v:d,l:'DECLINING',c:'#D93025'},{v:st,l:'STABLE',c:'#475569'},{v:(n>=0?'+':'')+n,l:'NET WoW',c:n>=0?'#0A7A55':'#D93025'}
              ].map(m=>(<div key={m.l} className="fn-wowstrip-i" style={{borderColor:m.c}}><div className="fn-wowstrip-v" style={{color:m.c}}>{m.v}</div><div className="fn-wowstrip-l">{m.l}</div></div>));
            })()}
          </div>
          <div className="fn-grid2" style={{marginBottom:18}}>
            <div className="fn-card fn-card-blue">
              <div className="fn-card-head"><span className="fn-card-title">Total Keywords · Page 1 · Not Ranking (NR) — Highest to Lowest</span></div>
              <div className="fn-chart-wrap" style={{height:420}}><canvas id="catTotalsChart"></canvas></div>
            </div>
            <div className="fn-card fn-card-green">
              <div className="fn-card-head"><span className="fn-card-title">Average Position — Best to Weakest</span><span className="fn-card-meta">Lower = better · Oct 28</span></div>
              <div className="fn-chart-wrap" style={{height:420}}><canvas id="catAvgChart"></canvas></div>
            </div>
          </div>

          {/* ══ Category Performance — Card Grid ══ */}
          {(()=>{
            const CAT_ORDER = ['NGFW','Zero Trust','SASE','SD-WAN','NAC','OT Security','AI Cybersecurity','Top Opportunities','Quantum Security'];
            const perfOf = (c:string):{level:string;color:string;rank:number;pct:number} => {
              const st = CAT_STATS[c]; if(!st) return {level:'LOW PERFORMANCE',color:'#DC2626',rank:3,pct:0};
              const pct = st.total>0?(st.valid/st.total*100):0;
              if (pct>=90 && st.avg_rank<=3.0) return {level:'VERY GOOD',color:'#059669',rank:0,pct};
              if (pct>=85 && st.avg_rank<=4.0) return {level:'GOOD',color:'#1A56DB',rank:1,pct};
              if (pct>=70)                      return {level:'NEEDS ATTENTION',color:'#D97706',rank:2,pct};
              return {level:'LOW PERFORMANCE',color:'#DC2626',rank:3,pct};
            };
            const SORTED_CATS = [...CAT_ORDER].sort((x,y)=>{const px=perfOf(x),py=perfOf(y); return px.rank-py.rank || py.pct-px.pct;});
            const FUNNEL_CFG: Record<string,{bg:string;text:string;border:string}> = {
              TOFU:{bg:'rgba(26,86,219,.08)',text:'#1A56DB',border:'rgba(26,86,219,.2)'},
              MOFU:{bg:'rgba(6,182,212,.08)',text:'#0E7490',border:'rgba(6,182,212,.2)'},
              BOFU:{bg:'rgba(124,58,237,.08)',text:'#7C3AED',border:'rgba(124,58,237,.2)'},
            };
            const totKw   = Object.values(CAT_STATS).reduce((a,s)=>a+s.total,0);
            const totR1   = Object.values(CAT_STATS).reduce((a,s)=>a+s.rank1,0);
            const totP1   = Object.values(CAT_STATS).reduce((a,s)=>a+s.valid,0);
            const totR11  = RANK_11_100.length;
            const totNR   = Object.values(CAT_STATS).reduce((a,s)=>a+s.not_ranking,0);
            const totAIO  = AIO_KEYWORDS.length;
            const totGain = Object.values(WOW_STATS).reduce((a,w)=>a+w.improving,0);
            const totDec  = Object.values(WOW_STATS).reduce((a,w)=>a+w.declining,0);
            const totSta  = Object.values(WOW_STATS).reduce((a,w)=>a+w.stable,0);
            const netWow  = totGain - totDec;
            return (
              <div>
                {/* Section header + aggregate totals */}
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16,padding:'0 2px'}}>
                  <div style={{display:'flex',alignItems:'center',gap:10}}>
                    <div style={{width:32,height:32,borderRadius:8,background:'rgba(26,86,219,.1)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,flexShrink:0}}>◈</div>
                    <div>
                      <div style={{fontSize:15,fontWeight:800,color:'var(--text)',letterSpacing:'-.01em'}}>Category Performance — Unified Overview</div>
                      <div style={{fontSize:11,color:'var(--text3)',marginTop:1}}>Source: Semrush · All metrics · Oct 28, 2026 · WoW vs Oct 21</div>
                    </div>
                  </div>
                </div>

                {/* 3-column card grid */}
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14}}>
                  {SORTED_CATS.map(cat=>{
                    const s = CAT_STATS[cat];
                    const w = WOW_STATS[cat]||{improving:0,declining:0,stable:0,net:0,bothNr:0,tracked:0,total:s?.total||0};
                    const fm = WOW_MOVERS_FUNNEL[cat]||{TOFU:[],MOFU:[],BOFU:[]};
                    if(!s) return null;
                    const cc = catColor(cat);
                    const p1pct = s.total>0?(s.valid/s.total*100):0;
                    const totalTracked = (w.improving+w.declining+w.stable)||1;
                    const gainPct = w.improving/totalTracked*100;
                    const decPct  = w.declining/totalTracked*100;
                    const staPct  = w.stable/totalTracked*100;
                    const net = w.improving - w.declining;
                    // Performance Indicator — Page 1% + Avg Rank (both required)
                    const perfPct = s.total>0?(s.valid/s.total*100):0;
                    const {level: perfLevel, color: perfColor} = perfOf(cat);
                    const p1Aug26 = (WEEKLY_PAGE1[cat]??[]).slice(-1)[0]??s.valid;
                    const p1Aug19 = (WEEKLY_PAGE1[cat]??[]).slice(-2)[0]??s.valid;
                    const p1Dec31 = (WEEKLY_PAGE1[cat]??[])[0]??s.valid;
                    const p1Wow   = p1Aug26 - p1Aug19;
                    const p1Ytd   = p1Aug26 - p1Dec31;
                    return (
                      <div key={cat} style={{
                        background:'var(--surface)',
                        border:'1px solid var(--border)',
                        borderRadius:12,
                        overflow:'hidden',
                        display:'flex',
                        flexDirection:'column',
                      }}>
                        {/* Category color accent bar */}
                        <div style={{height:4,background:cc,flexShrink:0}}/>

                        {/* Header */}
                        <div style={{padding:'13px 15px 10px',borderBottom:'1px solid var(--border)'}}>
                          <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:10}}>
                            <div>
                              <div style={{fontSize:14,fontWeight:900,color:cc,letterSpacing:'-.015em',lineHeight:1.1}}>{cat}</div>
                              <div style={{fontSize:10,color:'var(--text3)',marginTop:3}}>
                                {(w.improving+w.declining+w.stable)||s.total} of {s.total} tracked
                              </div>
                            </div>
                            <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:4}}>
                              <span style={{fontSize:8,padding:'2px 8px',borderRadius:4,fontWeight:800,letterSpacing:'.04em',
                                background:perfColor+'18',color:perfColor,fontFamily:"'DM Mono',monospace",
                                display:'inline-flex',alignItems:'center',gap:4,whiteSpace:'nowrap'}}>
                                <span style={{width:6,height:6,borderRadius:'50%',background:perfColor,display:'inline-block',flexShrink:0}}/>
                                {perfLevel}
                              </span>
                              {s.isNew&&<span style={{fontSize:8,padding:'2px 6px',borderRadius:4,fontWeight:800,
                                background:'rgba(245,158,11,.15)',color:'#92400E',fontFamily:"'DM Mono',monospace"}}>NEW</span>}
                            </div>
                          </div>
                          {/* Stacked bar: gain / stable / decline */}
                          <div style={{height:6,borderRadius:3,overflow:'hidden',display:'flex',gap:.5}}>
                            {gainPct>0&&<div style={{flex:gainPct,background:'#10B981',transition:'flex .4s'}}/>}
                            {staPct>0&&<div style={{flex:staPct,background:'rgba(100,116,139,.35)',transition:'flex .4s'}}/>}
                            {decPct>0&&<div style={{flex:decPct,background:'#EF4444',transition:'flex .4s'}}/>}
                          </div>
                        </div>

                        {/* Row 1: Total KWs | Rank #1 | Page 1 | AIO */}
                        {(()=>{
                          const AIO_BY_CAT:Record<string,number> = Object.fromEntries(Object.keys(CAT_STATS).map(c=>[c,AIO_KEYWORDS.filter(r=>r.cat===c).length]));
                          const aioVal = AIO_BY_CAT[cat]??0;
                          return (
                            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',borderBottom:'1px solid var(--border)'}}>
                              {[
                                {label:'Total KWs',val:String(s.total),color:'var(--text)',sub:null},
                                {label:'Rank #1',val:String(s.rank1),color:'#059669',sub:`${(s.rank1/s.total*100).toFixed(0)}%`},
                                {label:'Page 1',val:String(s.valid),color:'#1A56DB',sub:`${p1pct.toFixed(0)}%`},
                                {label:'AIO',val:String(aioVal),color:'#4338CA',sub:`${(aioVal/s.total*100).toFixed(0)}%`},
                              ].map((m,i)=>(
                                <div key={i} style={{padding:'9px 8px',textAlign:'center',borderRight:i<3?'1px solid var(--border)':undefined}}>
                                  <div style={{fontSize:15,fontWeight:900,color:m.color,fontFamily:"'DM Mono',monospace",lineHeight:1}}>{m.val}</div>
                                  {m.sub&&<div style={{fontSize:9,color:'var(--text2)',marginTop:1,fontFamily:"'DM Mono',monospace",fontWeight:800}}>{m.sub}</div>}
                                  <div style={{fontSize:7,color:'var(--text3)',marginTop:3,textTransform:'uppercase',letterSpacing:'.07em',fontWeight:700}}>{m.label}</div>
                                </div>
                              ))}
                            </div>
                          );
                        })()}

                        {/* Row 2: Gaining | Declining | Stable | Not Ranking | Avg Rank */}
                        <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',borderBottom:'1px solid var(--border)'}}>
                          {[
                            {label:'↑ Gaining',val:w.improving,color:'#059669',pct:(w.improving/totalTracked*100).toFixed(0)+'%'},
                            {label:'↓ Declining',val:w.declining,color:'#DC2626',pct:(w.declining/totalTracked*100).toFixed(0)+'%'},
                            {label:'→ Stable',val:w.stable,color:'#64748B',pct:(w.stable/totalTracked*100).toFixed(0)+'%'},
                            {label:'Not Ranking',val:s.not_ranking,color:s.not_ranking>0?'#B45309':'var(--text3)',pct:null},
                            {label:'Avg Rank',val:`#${s.avg_rank.toFixed(1)}`,color:s.avg_rank<=3?'#059669':s.avg_rank<=7?'#B45309':'#DC2626',pct:null},
                          ].map((m,i)=>(
                            <div key={i} style={{padding:'8px 6px',textAlign:'center',borderRight:i<4?'1px solid var(--border)':undefined}}>
                              <div style={{fontSize:12,fontWeight:900,color:m.color,fontFamily:"'DM Mono',monospace",lineHeight:1}}>{m.val}</div>
                              {m.pct&&<div style={{fontSize:9,color:'var(--text2)',marginTop:1,fontFamily:"'DM Mono',monospace",fontWeight:800}}>{m.pct}</div>}
                              <div style={{fontSize:7,color:'var(--text3)',marginTop:2,textTransform:'uppercase',letterSpacing:'.06em',fontWeight:700}}>{m.label}</div>
                            </div>
                          ))}
                        </div>

                        {/* Page 1 trajectory */}
                        <div style={{padding:'7px 14px',borderBottom:'1px solid var(--border)',background:'rgba(26,86,219,.03)',display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}}>
                          <span style={{fontSize:11,fontWeight:800,color:'#1A56DB',fontFamily:"'DM Mono',monospace"}}>{p1Aug26}</span>
                          <span style={{fontSize:9,color:'var(--text2)',fontWeight:800}}>on Page 1</span>
                          <span style={{fontSize:9,fontWeight:700,color:p1Wow>=0?'#059669':'#DC2626',fontFamily:"'DM Mono',monospace",background:p1Wow>=0?'rgba(5,150,105,.09)':'rgba(220,38,38,.08)',padding:'1px 5px',borderRadius:3}}>
                            {p1Wow>=0?'+':''}{p1Wow} vs Oct 21
                          </span>
                          <span style={{fontSize:9,fontWeight:700,color:p1Ytd>=0?'#059669':'#DC2626',fontFamily:"'DM Mono',monospace",background:p1Ytd>=0?'rgba(5,150,105,.09)':'rgba(220,38,38,.08)',padding:'1px 5px',borderRadius:3}}>
                            {p1Ytd>=0?'+':''}{p1Ytd} vs Dec 31
                          </span>
                        </div>

                        {/* Top Movers — flat by SV: top 3 gain + top 3 loss across all funnels */}
                        {(()=>{
                          const fmtV=(v:number)=>v>=1000?`${(v/1000).toFixed(v>=10000?0:1)}K`:String(v);
                          const allEntries = (['TOFU','MOFU','BOFU'] as const).flatMap(f=>
                            (fm[f]||[]).map(m=>({...m,funnel:f}))
                          );
                          const topGain = allEntries.filter(m=>m.d>0).sort((a,b)=>b.vol-a.vol).slice(0,3);
                          const topLoss = allEntries.filter(m=>m.d<0).sort((a,b)=>b.vol-a.vol).slice(0,3);
                          const rows = [...topGain,...topLoss];
                          if(rows.length===0) return null;
                          return (
                            <div style={{padding:'10px 13px 12px',flex:1}}>
                              <div style={{fontSize:8,fontWeight:800,color:'var(--text3)',letterSpacing:'.1em',textTransform:'uppercase',marginBottom:6}}>Top Movers · Oct 21→Oct 28</div>
                              {/* column headers */}
                              <div style={{display:'grid',gridTemplateColumns:'1fr 42px 36px 68px',gap:3,marginBottom:4,paddingLeft:14}}>
                                {['Keyword','Funnel','SV','Pos Prev→Curr'].map(h=>(
                                  <span key={h} style={{fontSize:7,fontWeight:700,color:'#94A3B8',letterSpacing:'.05em',textTransform:'uppercase',whiteSpace:'nowrap'}}>{h}</span>
                                ))}
                              </div>
                              <div style={{display:'flex',flexDirection:'column',gap:2}}>
                                {rows.map((m,i)=>{
                                  const isGain=m.d>0;
                                  const mColor=isGain?'#059669':'#DC2626';
                                  const mBg=isGain?'rgba(5,150,105,.06)':'rgba(220,38,38,.05)';
                                  const mBorder=isGain?'rgba(5,150,105,.16)':'rgba(220,38,38,.14)';
                                  const fc=FUNNEL_CFG[m.funnel];
                                  return (
                                    <div key={i} style={{display:'grid',gridTemplateColumns:'1fr 42px 36px 68px',gap:3,
                                      alignItems:'center',padding:'3px 5px',background:mBg,
                                      border:`1px solid ${mBorder}`,borderRadius:4}}>
                                      <div style={{display:'flex',alignItems:'center',gap:4,minWidth:0}}>
                                        <span style={{fontSize:9,color:mColor,fontWeight:900,flexShrink:0}}>{isGain?'↑':'↓'}</span>
                                        <span style={{fontSize:8,color:'var(--text)',fontFamily:"'DM Mono',monospace",
                                          overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{m.kw}</span>
                                      </div>
                                      <span style={{fontSize:7,color:fc.text,fontWeight:800,background:fc.bg,
                                        padding:'1px 4px',borderRadius:3,textAlign:'center',border:`1px solid ${fc.border}`}}>{m.funnel}</span>
                                      <span style={{fontSize:7,color:'#64748B',fontFamily:"'DM Mono',monospace",textAlign:'right'}}>{fmtV(m.vol)}</span>
                                      <span style={{fontSize:8,fontWeight:800,color:mColor,fontFamily:"'DM Mono',monospace",textAlign:'right',whiteSpace:'nowrap'}}>
                                        {m.from===0?101:'#'+m.from}→{m.to===0?101:'#'+m.to}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}

          <div style={{display:'flex',flexDirection:'column',gap:16}}>
            <div className="fn-card fn-full">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(10,122,85,.1)'}}>📈</div>
                <span className="fn-card-title">Weekly Page 1 Count per Category — 44-Week Trajectory</span>
                <span className="fn-card-meta">Dec 2025 → Oct 2026</span>
              </div>
              <div className="fn-chart-wrap" style={{height:220}}><canvas id="weeklyR1Chart"></canvas></div>
            </div>
            <div className="fn-card fn-full">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(26,86,219,.1)'}}>📉</div>
                <span className="fn-card-title">Weekly Average Position per Category — 44-Week Trajectory</span>
                <span className="fn-card-meta">Dec 2025 → Oct 2026 · lower = better</span>
              </div>
              <div className="fn-chart-wrap" style={{height:220}}><canvas id="avgRankChart"></canvas></div>
            </div>
          </div>
        </div>

        {/* ═══ KEYWORD PERFORMANCE OVERVIEW ═══ */}
        <div className={`fn-tab-panel${activeTab==='kwperf'?' active':''}`}>
          <TabHead eyebrow="03 — KEYWORD PERFORMANCE" title="Keyword Performance" sub="Highest-volume keywords, #1 wins and funnel leaders" accent="#7C3AED" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={kwperfInsights} />


          <div className="fn-grid2">
            <div className="fn-card">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(217,48,37,.08)'}}>🎯</div>
                <span className="fn-card-title">Highest-Volume Keywords — Position Status</span>
                <span style={{fontSize:10,fontWeight:600,color:'var(--text3)',marginLeft:6,whiteSpace:'nowrap'}}>{TOP_VOL.length} Keywords</span>
                <span className="fn-card-meta">Oct 28, 2026</span>
              </div>
              {/* column headers */}
              <div style={{display:'flex',alignItems:'center',gap:8,padding:'4px 13.5px 6px',marginBottom:2}}>
                <span style={{flex:1,fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em'}}>Keyword</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:92,textAlign:'center',flexShrink:0}}>Category</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:48,textAlign:'center',flexShrink:0}}>SV</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:72,textAlign:'center',flexShrink:0}}>Funnel</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:28,textAlign:'center',flexShrink:0}}>Pos</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:28,textAlign:'center',flexShrink:0}}>WoW</span>
              </div>
              <div className="fn-scroll-list fn-kwp">
                {TOP_VOL.map((d,i)=>{
                  const funnelLabel = d.funnel||'TOFU';
                  const funnelColor = funnelLabel==='BOFU'?'#7C3AED':funnelLabel==='MOFU'?'#0E7490':'#1A56DB';
                  const funnelBg = funnelLabel==='BOFU'?'rgba(124,58,237,.08)':funnelLabel==='MOFU'?'rgba(6,182,212,.08)':'rgba(26,86,219,.08)';
                  return (
                  <div key={i} className="fn-kw-row">
                    <span className="fn-kw-name">{d.keyword}</span>
                    <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                    <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                    <span style={{fontSize:9,fontWeight:700,color:funnelColor,background:funnelBg,padding:'2px 6px',borderRadius:4,fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',width:72,textAlign:'center',flexShrink:0}}>{funnelLabel}</span>
                    <span className={`fn-kw-rank ${rankBadgeClass(d.current_rank)}`}>{d.current_rank??101}</span>
                    <span className={d.delta===999?(d.current_rank===null?'fn-delta-down':'fn-delta-up'):d.delta<0?'fn-delta-up':d.delta>0?'fn-delta-down':'fn-delta-flat'}>{d.delta===999?(d.current_rank===null?'↓101':'↑NEW'):d.delta<0?'↑'+Math.abs(d.delta):d.delta>0?'↓'+d.delta:'—'}</span>
                  </div>
                  );
                })}
              </div>
            </div>
            <div className="fn-card">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(10,122,85,.08)'}}>✦</div>
                <span className="fn-card-title">High-Volume Rank #1 Wins</span>
                <span style={{fontSize:10,fontWeight:600,color:'var(--text3)',marginLeft:6,whiteSpace:'nowrap'}}>{RANK1_KEYWORDS.length} Keywords</span>
                <span className="fn-card-meta">Vol &gt; 1,000 &amp; currently #1 · Oct 28, 2026</span>
              </div>
              {/* column headers */}
              <div style={{display:'flex',alignItems:'center',gap:8,padding:'4px 13.5px 6px',marginBottom:2}}>
                <span style={{flex:1,fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em'}}>Keyword</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:92,textAlign:'center',flexShrink:0}}>Category</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:48,textAlign:'center',flexShrink:0}}>SV</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:72,textAlign:'center',flexShrink:0}}>Funnel</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:28,textAlign:'center',flexShrink:0}}>Pos</span>
              </div>
              <div className="fn-scroll-list fn-kwp">
                {RANK1_KEYWORDS.map((d,i)=>{
                  const funnelLabel = (d as any).funnel||'TOFU';
                  const funnelColor = funnelLabel==='BOFU'?'#7C3AED':funnelLabel==='MOFU'?'#0E7490':'#1A56DB';
                  const funnelBg = funnelLabel==='BOFU'?'rgba(124,58,237,.08)':funnelLabel==='MOFU'?'rgba(6,182,212,.08)':'rgba(26,86,219,.08)';
                  return (
                  <div key={i} className="fn-kw-row">
                    <span className="fn-kw-name">{d.keyword}</span>
                    <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                    <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                    <span style={{fontSize:9,fontWeight:700,color:funnelColor,background:funnelBg,padding:'2px 6px',borderRadius:4,fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',width:72,textAlign:'center',flexShrink:0}}>{funnelLabel}</span>
                    <span className="fn-kw-rank fn-r1">1</span>
                  </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ── Top Position #1 Keywords by Funnel Stage ── */}
          <div className="fn-grid2" style={{marginBottom:16}}>
            {/* TOFU/MOFU @#1 */}
            <div className="fn-card">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(26,86,219,.1)'}}>🔵</div>
                <span className="fn-card-title">Top TOFU / MOFU Keywords — Position #1</span>
                <span style={{fontSize:10,fontWeight:600,color:'var(--text3)',marginLeft:6,whiteSpace:'nowrap'}}>{TOP_TOFU_R1_KWS.length} Keywords</span>
                <span className="fn-card-meta">Informational intent · sorted by search volume · Oct 28, 2026</span>
              </div>
              {/* per-category rank-1 TOFU/MOFU summary bar */}
              <div style={{display:'flex',gap:6,flexWrap:'wrap',padding:'6px 0 10px'}}>
                {Object.entries(CAT_STATS).map(([cat, s])=>{
                  const color = catColor(cat);
                  const label = cat.replace('Top Opportunities','Top Opps').replace('AI Cybersecurity','AI Cyber').replace('OT Security','OT Sec').replace('Quantum Security','Quantum');
                  return (
                    <div key={cat} style={{display:'flex',alignItems:'center',gap:4,background:'var(--surface2)',borderRadius:6,padding:'3px 8px',opacity:s.tofu_r1===0?.45:1}}>
                      <span style={{width:7,height:7,borderRadius:'50%',background:color,display:'inline-block',flexShrink:0}}></span>
                      <span style={{fontSize:10,fontWeight:700,color:'var(--text2)',fontFamily:"'DM Mono',monospace"}}>{label}</span>
                      <span style={{fontSize:11,fontWeight:800,color,fontFamily:"'DM Mono',monospace"}}>{s.tofu_r1}</span>
                    </div>
                  );
                })}
              </div>
              {/* column headers */}
              <div style={{display:'flex',alignItems:'center',gap:8,padding:'4px 13.5px 6px',marginBottom:2}}>
                <span style={{flex:1,fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em'}}>Keyword</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:92,textAlign:'center',flexShrink:0}}>Category</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:48,textAlign:'center',flexShrink:0}}>SV</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:72,textAlign:'center',flexShrink:0}}>Funnel</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:28,textAlign:'center',flexShrink:0}}>Pos</span>
              </div>
              <div className="fn-scroll-list fn-kwp" style={{maxHeight:300}}>
                {TOP_TOFU_R1_KWS.map((d,i)=>(
                  <div key={i} className="fn-kw-row">
                    <span className="fn-kw-name">{d.keyword}</span>
                    <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                    <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                    <span style={{fontSize:9,fontWeight:700,color:'var(--blue)',background:'rgba(26,86,219,.08)',padding:'2px 6px',borderRadius:4,fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',width:72,textAlign:'center',flexShrink:0}}>TOFU/MOFU</span>
                    <span className="fn-kw-rank fn-r1">1</span>
                  </div>
                ))}
              </div>
            </div>

            {/* BOFU @#1 */}
            <div className="fn-card">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(124,58,237,.1)'}}>🟣</div>
                <span className="fn-card-title">Top BOFU Keywords — Position #1</span>
                <span style={{fontSize:10,fontWeight:600,color:'var(--text3)',marginLeft:6,whiteSpace:'nowrap'}}>{TOP_BOFU_R1_KWS.length} Keywords</span>
                <span className="fn-card-meta">Commercial / purchase intent · sorted by search volume · Oct 28, 2026</span>
              </div>
              {/* per-category rank-1 BOFU summary bar */}
              <div style={{display:'flex',gap:6,flexWrap:'wrap',padding:'6px 0 10px'}}>
                {Object.entries(CAT_STATS).map(([cat, s])=>{
                  const color = catColor(cat);
                  const label = cat.replace('Top Opportunities','Top Opps').replace('AI Cybersecurity','AI Cyber').replace('OT Security','OT Sec').replace('Quantum Security','Quantum');
                  return (
                    <div key={cat} style={{display:'flex',alignItems:'center',gap:4,background:'var(--surface2)',borderRadius:6,padding:'3px 8px',opacity:s.bofu_r1===0?.45:1}}>
                      <span style={{width:7,height:7,borderRadius:'50%',background:color,display:'inline-block',flexShrink:0}}></span>
                      <span style={{fontSize:10,fontWeight:700,color:'var(--text2)',fontFamily:"'DM Mono',monospace"}}>{label}</span>
                      <span style={{fontSize:11,fontWeight:800,color,fontFamily:"'DM Mono',monospace"}}>{s.bofu_r1}</span>
                    </div>
                  );
                })}
              </div>
              {/* column headers */}
              <div style={{display:'flex',alignItems:'center',gap:8,padding:'4px 13.5px 6px',marginBottom:2}}>
                <span style={{flex:1,fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em'}}>Keyword</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:92,textAlign:'center',flexShrink:0}}>Category</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:48,textAlign:'center',flexShrink:0}}>SV</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:72,textAlign:'center',flexShrink:0}}>Funnel</span>
                <span style={{fontSize:8,fontWeight:800,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.07em',width:28,textAlign:'center',flexShrink:0}}>Pos</span>
              </div>
              <div className="fn-scroll-list fn-kwp" style={{maxHeight:300}}>
                {TOP_BOFU_R1_KWS.map((d,i)=>(
                  <div key={i} className="fn-kw-row">
                    <span className="fn-kw-name">{d.keyword}</span>
                    <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                    <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                    <span style={{fontSize:9,fontWeight:700,color:'var(--purple)',background:'rgba(124,58,237,.08)',padding:'2px 6px',borderRadius:4,fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',width:72,textAlign:'center',flexShrink:0}}>BOFU</span>
                    <span className="fn-kw-rank fn-r1">1</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="fn-card fn-full">
            <div className="fn-card-head">
              <div className="fn-card-icon" style={{background:'rgba(124,58,237,.1)'}}>📉</div>
              <span className="fn-card-title">SEO Position Journey — Top 10 High-Volume Keywords</span>
              <span style={{fontSize:10,fontWeight:600,color:'var(--text3)',marginLeft:6,whiteSpace:'nowrap'}}>10 Keywords</span>
              <span className="fn-card-meta">Dec 2025 → Oct 2026 · 44 weeks</span>
            </div>
            <div className="fn-chart-wrap" style={{height:280}}><canvas id="trendLine"></canvas></div>
          </div>
        </div>

        {/* ═══ POSITION TRACKER ═══ */}
        <div className={`fn-tab-panel${activeTab==='position'?' active':''}`}>
          <TabHead eyebrow="04 — KEYWORD POSITION INSIGHT" title="Keyword Position Insight" sub="Who is gaining, slipping, holding and swinging across all 660 keywords" accent="#1A56DB" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={posInsights} />
          {(()=>{
            const gainAll = POS_GAIN.slice(0,20);
            const lossAll = POS_LOSS.slice(0,20);
            const pf = (key:string)=>posFilter[key]||'All';
            const byCat = <T extends {category:string}>(key:string,arr:T[])=>pf(key)==='All'?arr:arr.filter(d=>d.category===pf(key));
            const gain = byCat('gain',gainAll);
            const loss = byCat('loss',lossAll);
            const solid = byCat('solid',solidR1);
            const vol = byCat('vol',volatileKws);
            const chips = (key:string,arr:{category:string}[])=>{
              const counts: Record<string,number> = {};
              arr.forEach(d=>{counts[d.category]=(counts[d.category]||0)+1;});
              const cats = Object.entries(counts).sort((a,b)=>b[1]-a[1]);
              const btn = (label:string,val:string,n:number,color:string)=>{
                const on = pf(key)===val;
                return (<button key={val} type="button" onClick={()=>setPosFilter(f=>({...f,[key]:val}))} aria-pressed={on} className="fn-catchip" style={{borderColor:on?color:'var(--border)',background:on?color:'transparent',color:on?'#fff':'var(--text2)'}}>
                  {val!=='All'&&<span style={{width:6,height:6,borderRadius:'50%',background:on?'#fff':color,display:'inline-block'}}></span>}
                  {label}<b>{n}</b>
                </button>);
              };
              return (<div className="fn-catchips">{btn('All','All',arr.length,'#334155')}{cats.map(([c,n])=>btn(shortCat(c),c,n,catColor(c)))}</div>);
            };
            const shortCat = (c:string)=>c.replace('Top Opportunities','Top Opps');
            const empty = (<div style={{padding:'26px 10px',textAlign:'center',fontSize:12,fontWeight:700,color:'var(--text3)'}}>No keywords in this view</div>);
            const pill = (n:number,color:string,bg:string)=>(<span style={{fontSize:11,fontWeight:800,color,background:bg,borderRadius:12,padding:'3px 10px',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap'}}>{n} keywords</span>);
            return (<>
              <div className="fn-grid2">
                <div className="fn-card fn-card-green">
                  <div className="fn-card-head">
                    <div className="fn-card-icon" style={{background:'rgba(10,122,85,.14)'}}>🚀</div>
                    <span className="fn-card-title">Top Gainers — Biggest Rank Improvements</span>
                    {pill(gain.length,'#0A7A55','rgba(10,122,85,.12)')}
                  </div>
                  <div className="fn-card-meta" style={{marginBottom:8}}>Top 20 · Oct 21 → Oct 28, 2026 · sorted by positions gained</div>
                  {chips('gain',gainAll)}
                  <div className="fn-scroll-list fn-posl">
                    {gain.length===0?empty:gain.map((d,i)=>(
                      <div key={i} className="fn-mover-row fn-mover-up">
                        <span className="fn-mover-kw">{d.keyword}</span>
                        <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{fontSize:8}}>{shortCat(d.category)}</span>
                        <span className="fn-kw-vol">{fmtVol(d.vol)}</span>
                        <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',fontWeight:700}}>#{d.prev}→#{d.cur}</span>
                        <span className={`fn-kw-rank ${rankBadgeClass(d.cur>100?null:d.cur)}`}>{d.cur}</span>
                        <span className="fn-mover-delta fn-mover-delta-up">↑{d.prev-d.cur}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="fn-card fn-card-red">
                  <div className="fn-card-head">
                    <div className="fn-card-icon" style={{background:'rgba(217,48,37,.12)'}}>⚡</div>
                    <span className="fn-card-title">Top Decliners — Biggest Rank Drops</span>
                    {pill(loss.length,'#D93025','rgba(217,48,37,.1)')}
                  </div>
                  <div className="fn-card-meta" style={{marginBottom:8}}>Top 20 · Oct 21 → Oct 28, 2026 · sorted by positions lost</div>
                  {chips('loss',lossAll)}
                  <div className="fn-scroll-list fn-posl">
                    {loss.length===0?empty:loss.map((d,i)=>(
                      <div key={i} className="fn-mover-row fn-mover-down">
                        <span className="fn-mover-kw">{d.keyword}</span>
                        <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{fontSize:8}}>{shortCat(d.category)}</span>
                        <span className="fn-kw-vol">{fmtVol(d.vol)}</span>
                        <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',fontWeight:700}}>#{d.prev}→#{d.cur}</span>
                        <span className={`fn-kw-rank ${rankBadgeClass(d.cur>100?null:d.cur)}`}>{d.cur}</span>
                        <span className="fn-mover-delta fn-mover-delta-down">{d.cur>100?'→101':`↓${d.cur-d.prev}`}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="fn-grid2">
                <div className="fn-card fn-card-blue">
                  <div className="fn-card-head">
                    <div className="fn-card-icon" style={{background:'rgba(10,122,85,.14)'}}>🏆</div>
                    <span className="fn-card-title">Rock-Solid Rank #1 — Consistent Holders</span>
                    {pill(solid.length,'#1A56DB','rgba(26,86,219,.1)')}
                  </div>
                  <div className="fn-card-meta" style={{marginBottom:8}}>Ranked #1 on Oct 28 and #1 for 24+ of 44 weeks (Dec 31 → Oct 28) · {solidR1.length} keywords</div>
                  {chips('solid',solidR1)}
                  <div className="fn-scroll-list fn-posl">
                    {solid.length===0?empty:solid.map((d,i)=>(
                      <div key={i} className="fn-kw-row">
                        <span className="fn-kw-name">{d.keyword}</span>
                        <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{fontSize:8,flexShrink:0}}>{shortCat(d.category)}</span>
                        <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                        <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace",whiteSpace:'nowrap',fontWeight:700}}>{d.r1weeks}/44 wks</span>
                        <span className="fn-kw-rank fn-r1">1</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="fn-card fn-card-amber">
                  <div className="fn-card-head">
                    <div className="fn-card-icon" style={{background:'rgba(180,83,9,.14)'}}>⚠</div>
                    <span className="fn-card-title">Volatile Keywords — High SERP Instability</span>
                    {pill(vol.length,'#B45309','rgba(180,83,9,.12)')}
                  </div>
                  {chips('vol',volatileKws)}
                  <div className="fn-scroll-list fn-posl">
                    {vol.length===0?empty:vol.map((d,i)=>(
                      <div key={i} className="fn-kw-row">
                        <span className="fn-kw-name">{d.keyword}</span>
                        <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{fontSize:8,flexShrink:0}}>{shortCat(d.category)}</span>
                        <span className="fn-kw-vol">{fmtVol(d.vol_jan26)}</span>
                        <span className="fn-kw-rank fn-r3" title={`${d.reversals} direction reversals · ${d.swings} moves of 5+ positions`}>{d.reversals}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>);
          })()}
        </div>


        {/* ═══ CATEGORIES ═══ */}
        <div className={`fn-tab-panel${activeTab==='categories'?' active':''}`}>
          <TabHead eyebrow="05 — BY CATEGORY" title="By Category" sub="Keyword position tables for each product category" accent="#0A7A55" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={catInsights} />
          {(()=>{
            const isBacklinkView = selectedCat === 'Backlink KWs' || selectedCat === 'No Backlink KWs';
            const FUNNELS: Array<'All'|'TOFU'|'MOFU'|'BOFU'> = ['All','TOFU','MOFU','BOFU'];
            const FUNNEL_STYLE: Record<string,{active:string;activeBg:string;border:string}> = {
              All:  {active:'var(--text)',  activeBg:'var(--surface2)', border:'var(--border)'},
              TOFU: {active:'#1A56DB', activeBg:'rgba(26,86,219,.1)',  border:'rgba(26,86,219,.3)'},
              MOFU: {active:'#0E7490', activeBg:'rgba(6,182,212,.1)',  border:'rgba(6,182,212,.3)'},
              BOFU: {active:'#7C3AED', activeBg:'rgba(124,58,237,.1)', border:'rgba(124,58,237,.3)'},
            };
            const RANK_FILTERS: Array<'All'|'Rank1'|'Page1'|'Page2_10'|'NotRanking'|'Funnel'> = ['All','Rank1','Page1','Page2_10','NotRanking','Funnel'];
            const RANK_LABELS: Record<string,string> = {All:'All',Rank1:'Rank 1',Page1:'Page 1',Page2_10:'Page 2–10',NotRanking:'Not Ranking',Funnel:'FUNNEL'};
            const RANK_STYLE: Record<string,{active:string;activeBg:string;border:string}> = {
              All:        {active:'var(--text)',  activeBg:'var(--surface2)',          border:'var(--border)'},
              Rank1:      {active:'#059669',      activeBg:'rgba(5,150,105,.1)',       border:'rgba(5,150,105,.3)'},
              Page1:      {active:'#1A56DB',      activeBg:'rgba(26,86,219,.1)',       border:'rgba(26,86,219,.3)'},
              Page2_10:   {active:'#0E7490',      activeBg:'rgba(6,182,212,.1)',       border:'rgba(6,182,212,.3)'},
              NotRanking: {active:'#DC2626',      activeBg:'rgba(220,38,38,.1)',       border:'rgba(220,38,38,.3)'},
              Funnel:     {active:'#B45309',      activeBg:'rgba(180,83,9,.1)',        border:'rgba(180,83,9,.3)'},
            };
            const BL_FUNNEL_STYLE: Record<string,{active:string;activeBg:string;border:string}> = {
              TOFU: {active:'#1A56DB', activeBg:'rgba(26,86,219,.1)',  border:'rgba(26,86,219,.3)'},
              MOFU: {active:'#0E7490', activeBg:'rgba(6,182,212,.1)',  border:'rgba(6,182,212,.3)'},
              BOFU: {active:'#7C3AED', activeBg:'rgba(124,58,237,.1)', border:'rgba(124,58,237,.3)'},
            };

            // ── Backlink/No Backlink branch ──────────────────────────────────────────
            if (isBacklinkView) {
const baseKws = selectedCat === 'Backlink KWs' ? BACKLINK_KWS : NO_BACKLINK_KWS;
              const getFunnel = (kw: KW) => (kw as any).funnel || 'TOFU';
              let blDisplay: KW[];
              if (selectedRankFilter === 'Rank1') {
                blDisplay = baseKws.filter(kw => kw.current_rank === 1).sort((a,b)=>b.vol_jan26-a.vol_jan26);
              } else if (selectedRankFilter === 'Page1') {
                blDisplay = baseKws.filter(kw => kw.current_rank !== null && kw.current_rank >= 1 && kw.current_rank <= 10).sort((a,b)=>b.vol_jan26-a.vol_jan26);
              } else if (selectedRankFilter === 'Page2_10') {
                blDisplay = baseKws.filter(kw => kw.current_rank !== null && kw.current_rank >= 11 && kw.current_rank <= 100).sort((a,b)=>b.vol_jan26-a.vol_jan26);
              } else if (selectedRankFilter === 'NotRanking') {
                blDisplay = baseKws.filter(kw => kw.current_rank === null).sort((a,b)=>b.vol_jan26-a.vol_jan26);
              } else if (selectedRankFilter === 'Funnel') {
                blDisplay = baseKws.filter(kw => getFunnel(kw) === selectedBlFunnel).sort((a,b)=>b.vol_jan26-a.vol_jan26);
              } else {
                blDisplay = [...baseKws].sort((a,b)=>b.vol_jan26-a.vol_jan26);
              }
              const rankCounts: Record<string,number> = {
                Rank1: baseKws.filter(kw=>kw.current_rank===1).length,
                Page1: baseKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=1&&kw.current_rank<=10).length,
                Page2_10: baseKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=11&&kw.current_rank<=100).length,
                NotRanking: baseKws.filter(kw=>kw.current_rank===null).length,
                Funnel: baseKws.filter(kw=>getFunnel(kw)===selectedBlFunnel).length,
              };
              const blFunnelCounts: Record<string,number> = {
                TOFU: baseKws.filter(kw=>getFunnel(kw)==='TOFU').length,
                MOFU: baseKws.filter(kw=>getFunnel(kw)==='MOFU').length,
                BOFU: baseKws.filter(kw=>getFunnel(kw)==='BOFU').length,
              };

              function buildBacklinkTableHtml(kws: KW[]): string {
                function sparklineSvg(ranks: (number|null)[]): string {
                  const W = 120, H = 28, NR = 101;
                  const mapped = ranks.map(r => (r === null || r === undefined) ? NR : r);
                  const anyRanked = mapped.some(r => r < NR);
                  if (!anyRanked) return `<svg width="${W}" height="${H}"></svg>`;
                  const maxR = Math.max(...mapped);
                  const pts: string[] = [];
                  mapped.forEach((r, i) => {
                    const x = (i / (mapped.length - 1)) * (W - 4) + 2;
                    const y = maxR === 1 ? 2 : ((r - 1) / (maxR - 1)) * (H - 4) + 2;
                    pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
                  });
                  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><polyline points="${pts.join(' ')}" fill="none" stroke="#1E293B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${pts[pts.length-1].split(',')[0]}" cy="${pts[pts.length-1].split(',')[1]}" r="2.5" fill="#1E293B"/></svg>`;
                }
                function cellStyle(r: number | null): string {
                  if (r === null || r === undefined) return 'text-align:center;color:#94A3B8;font-size:11px;font-family:\'DM Mono\',monospace;font-weight:600';
                  const bg = rankColor(r);
                  const col = rankTextColor(r);
                  return `text-align:center;background:${bg};color:${col};font-weight:700;font-size:12px;font-family:'DM Mono',monospace`;
                }
                const funnelBadge = (f: string) => {
                  const colors: Record<string,string> = {TOFU:'#1A56DB',MOFU:'#0E7490',BOFU:'#7C3AED'};
                  const bgs: Record<string,string> = {TOFU:'rgba(26,86,219,.1)',MOFU:'rgba(6,182,212,.1)',BOFU:'rgba(124,58,237,.1)'};
                  const c = colors[f]||'#64748B', b = bgs[f]||'transparent';
                  return `<span style="font-size:9px;font-weight:800;padding:2px 6px;border-radius:4px;background:${b};color:${c};letter-spacing:.04em;font-family:'DM Mono',monospace">${f}</span>`;
                };
                const catBadge = (cat: string) => {
                  const short = cat.replace('Top Opportunities','Top Opps').replace('AI Cybersecurity','AI Cyber').replace('Quantum Security','Quantum').replace('OT Security','OT Sec').replace('Zero Trust','ZeroTrust');
                  return `<span style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;background:rgba(100,116,139,.1);color:#475569;white-space:nowrap">${short}</span>`;
                };
                return `<table style="width:100%;border-collapse:collapse;font-size:12px">
                  <thead><tr style="border-bottom:2px solid #E2E8F0">
                    <th style="text-align:left;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap;min-width:160px">Keyword</th>
                    <th style="text-align:left;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Category</th>
                    <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Funnel</th>
                    <th style="text-align:right;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">SV</th>
                    <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Oct 21<br/><span style="font-weight:500;font-size:9px">Prev Week</span></th>
                    <th style="text-align:center;padding:8px 12px;font-size:10px;font-weight:700;color:#1A56DB;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">Oct 28<br/><span style="font-weight:500;font-size:9px">Latest</span></th>
                    <th style="text-align:center;padding:8px 16px;font-size:10px;font-weight:700;color:#64748B;letter-spacing:.06em;text-transform:uppercase;white-space:nowrap">44-Week Trend<br/><span style="font-weight:500;font-size:9px">Dec → Oct 28</span></th>
                  </tr></thead>
                  <tbody>
                  ${kws.map((d,i) => {
                    const sep02 = d.ranks[42] ?? null;
                    const sep09 = d.ranks[43] ?? d.current_rank;
                    const vol = d.vol_jan26 >= 1000 ? `${(d.vol_jan26/1000).toFixed(d.vol_jan26>=10000?0:1)}K` : d.vol_jan26 > 0 ? String(d.vol_jan26) : '—';
                    const funnel = (d as any).funnel || 'TOFU';
                    const cat = (d as any).category || '';
                    return `<tr style="border-bottom:1px solid #F1F5F9;background:${i%2===0?'#ffffff':'#FAFBFC'}">
                      <td style="padding:7px 12px;font-weight:700;color:#0F172A;white-space:nowrap">${d.keyword}</td>
                      <td style="padding:7px 12px;white-space:nowrap">${catBadge(cat)}</td>
                      <td style="padding:7px 12px;text-align:center">${funnelBadge(funnel)}</td>
                      <td style="padding:7px 12px;text-align:right;font-size:11px;font-family:'DM Mono',monospace;font-weight:600;color:#64748B;white-space:nowrap">${vol}</td>
                      <td style="${cellStyle(sep02)};padding:7px 12px">${sep02??101}</td>
                      <td style="${cellStyle(sep09)};padding:7px 12px;border:1.5px solid rgba(26,86,219,.25)">${sep09??101}</td>
                      <td style="padding:5px 16px;text-align:center">${sparklineSvg(d.ranks)}</td>
                    </tr>`;
                  }).join('')}
                  </tbody>
                </table>`;
              }

              return (
                <div className="fn-card fn-full" style={{marginBottom:14}}>
                  <div className="fn-card-head" style={{flexWrap:'wrap',gap:8}}>
                    <div className="fn-card-icon" style={{background:'rgba(26,86,219,.1)'}}>🔗</div>
                    <span className="fn-card-title">Category Deep-Dive — Keyword Position Table</span>
                    <span className="fn-card-meta">Select category:</span>
                    <select
                      className="fn-select"
                      value={selectedCat}
                      onChange={e=>{setSelectedCat(e.target.value);setSelectedFunnel('All');setSelectedRankFilter('All');setSelectedBlFunnel('TOFU');}}
                    >
                      <option value="NGFW">NGFW (141 keywords)</option>
                      <option value="SD-WAN">SD-WAN (130 keywords)</option>
                      <option value="NAC">NAC (80 keywords)</option>
                      <option value="Zero Trust">Zero Trust (20 keywords)</option>
                      <option value="Top Opportunities">Top Opportunities (49 keywords)</option>
                      <option value="AI Cybersecurity">AI Cybersecurity (136 keywords) 🆕</option>
                      <option value="OT Security">OT Security (46 keywords) 🆕</option>
                      <option value="Quantum Security">Quantum Security (28 keywords) 🆕</option>
                      <option value="SASE">SASE (30 keywords) 🆕</option>
                      <option value="Backlink KWs">Backlink KWs ({BACKLINK_KWS.length} keywords) 🔗</option>
                      <option value="No Backlink KWs">No Backlink KWs ({NO_BACKLINK_KWS.length} keywords) 🔗</option>
                    </select>
                    {/* Rank + Funnel filter pills */}
                    <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                      {RANK_FILTERS.map(rf=>{
                        const isActive = selectedRankFilter===rf;
                        const rs = RANK_STYLE[rf];
                        const count = rf==='All' ? baseKws.length : rankCounts[rf as keyof typeof rankCounts]??0;
                        return (
                          <button key={rf} onClick={()=>setSelectedRankFilter(rf)} style={{
                            fontSize:10,fontWeight:800,padding:'4px 10px',borderRadius:6,cursor:'pointer',
                            border:`1.5px solid ${isActive?rs.border:'var(--border)'}`,
                            background:isActive?rs.activeBg:'transparent',
                            color:isActive?rs.active:'var(--text3)',
                            fontFamily:"'DM Mono',monospace",letterSpacing:'.04em',
                            transition:'all .15s',whiteSpace:'nowrap',
                          }}>
                            {RANK_LABELS[rf]}{rf!=='Funnel'&&<span style={{marginLeft:4,fontSize:9,opacity:.75}}>({count})</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  {/* TOFU / MOFU / BOFU sub-pills — only when FUNNEL is active */}
                  {selectedRankFilter === 'Funnel' && (
                    <div style={{display:'flex',gap:6,padding:'8px 0 4px',borderTop:'1px solid var(--border)'}}>
                      {(['TOFU','MOFU','BOFU'] as const).map(f=>{
                        const isActive = selectedBlFunnel===f;
                        const fs = BL_FUNNEL_STYLE[f];
                        return (
                          <button key={f} onClick={()=>setSelectedBlFunnel(f)} style={{
                            fontSize:10,fontWeight:800,padding:'4px 10px',borderRadius:6,cursor:'pointer',
                            border:`1.5px solid ${isActive?fs.border:'var(--border)'}`,
                            background:isActive?fs.activeBg:'transparent',
                            color:isActive?fs.active:'var(--text3)',
                            fontFamily:"'DM Mono',monospace",letterSpacing:'.04em',
                            transition:'all .15s',
                          }}>
                            {f}<span style={{marginLeft:4,fontSize:9,opacity:.75}}>({blFunnelCounts[f]})</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                  <div style={{display:'flex',gap:10,marginBottom:10,flexWrap:'wrap'}}>
                    <div style={{marginLeft:'auto',fontSize:9,color:'var(--text3)',alignSelf:'center',fontFamily:"'DM Mono',monospace"}}>
                      showing {blDisplay.length} of {baseKws.length} keywords
                    </div>
                  </div>
                  {blDisplay.length === 0 && (
                    <div style={{padding:'20px',textAlign:'center',color:'var(--text3)',fontSize:12}}>
                      No keywords match this filter for {selectedCat}
                    </div>
                  )}
                  <div style={{overflowX:'auto'}} dangerouslySetInnerHTML={{__html: buildBacklinkTableHtml(blDisplay.filter(kw=>!(selectedCat==='No Backlink KWs'&&kw.category==='Top Opportunities'&&['wan','sdwan','firewalls'].includes(kw.keyword.trim().toLowerCase()))))}} />
                </div>
              );
            }

            // ── Standard category branch ─────────────────────────────────────────────
            const allKws = CAT_KEYWORDS[selectedCat]||[];
            const DUP_ONLY: Record<string,string> = {NGFW:'network security firewall',NAC:'iot network security'};
            const dedupeCatRows = (cat:string,rows:KW[])=>{
              const target = DUP_ONLY[cat]; if(!target) return rows;
              let seen = false;
              return rows.filter(k=>{ if(k.keyword.trim().toLowerCase()!==target) return true; if(seen) return false; seen=true; return true; });
            };
            const getKwFunnel = (kw: KW) => (kw as any).funnel || KW_FUNNEL_MAP[kw.keyword.toLowerCase()] || 'TOFU';

            let displayKws: KW[];
            if (selectedRankFilter === 'Rank1') {
              displayKws = allKws.filter(kw=>kw.current_rank===1).sort((a,b)=>b.vol_jan26-a.vol_jan26);
            } else if (selectedRankFilter === 'Page1') {
              displayKws = allKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=1&&kw.current_rank<=10).sort((a,b)=>b.vol_jan26-a.vol_jan26);
            } else if (selectedRankFilter === 'Page2_10') {
              displayKws = allKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=11&&kw.current_rank<=100).sort((a,b)=>b.vol_jan26-a.vol_jan26);
            } else if (selectedRankFilter === 'NotRanking') {
              displayKws = allKws.filter(kw=>kw.current_rank===null).sort((a,b)=>b.vol_jan26-a.vol_jan26);
            } else if (selectedRankFilter === 'Funnel') {
              displayKws = allKws.filter(kw=>getKwFunnel(kw)===selectedBlFunnel).sort((a,b)=>b.vol_jan26-a.vol_jan26);
            } else {
              displayKws = [...allKws].sort((a,b)=>b.vol_jan26-a.vol_jan26);
            }

            const catRankCounts: Record<string,number> = {
              Rank1:      allKws.filter(kw=>kw.current_rank===1).length,
              Page1:      allKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=1&&kw.current_rank<=10).length,
              Page2_10:   allKws.filter(kw=>kw.current_rank!==null&&kw.current_rank>=11&&kw.current_rank<=100).length,
              NotRanking: allKws.filter(kw=>kw.current_rank===null).length,
              Funnel:     allKws.filter(kw=>getKwFunnel(kw)===selectedBlFunnel).length,
            };
            const catFunnelCounts: Record<string,number> = {
              TOFU: allKws.filter(kw=>getKwFunnel(kw)==='TOFU').length,
              MOFU: allKws.filter(kw=>getKwFunnel(kw)==='MOFU').length,
              BOFU: allKws.filter(kw=>getKwFunnel(kw)==='BOFU').length,
            };

            return (
              <div className="fn-card fn-full" style={{marginBottom:14}}>
                <div className="fn-card-head" style={{flexWrap:'wrap',gap:8}}>
                  <div className="fn-card-icon" style={{background:'rgba(26,86,219,.1)'}}>◫</div>
                  <span className="fn-card-title">Category Deep-Dive — Keyword Position Table</span>
                  <span className="fn-card-meta">Select category:</span>
                  <select
                    className="fn-select"
                    value={selectedCat}
                    onChange={e=>{setSelectedCat(e.target.value);setSelectedFunnel('All');setSelectedRankFilter('All');setSelectedBlFunnel('TOFU');}}
                  >
                    <option value="NGFW">NGFW (141 keywords)</option>
                    <option value="SD-WAN">SD-WAN (130 keywords)</option>
                    <option value="NAC">NAC (80 keywords)</option>
                    <option value="Zero Trust">Zero Trust (20 keywords)</option>
                    <option value="Top Opportunities">Top Opportunities (49 keywords)</option>
                    <option value="AI Cybersecurity">AI Cybersecurity (136 keywords) 🆕</option>
                    <option value="OT Security">OT Security (46 keywords) 🆕</option>
                    <option value="Quantum Security">Quantum Security (28 keywords) 🆕</option>
                    <option value="SASE">SASE (30 keywords) 🆕</option>
                    <option value="Backlink KWs">Backlink KWs ({BACKLINK_KWS.length} keywords) 🔗</option>
                    <option value="No Backlink KWs">No Backlink KWs ({NO_BACKLINK_KWS.length} keywords) 🔗</option>
                  </select>
                  {/* Rank + Funnel filter pills — same structure as Backlink branch */}
                  <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                    {RANK_FILTERS.map(rf=>{
                      const isActive = selectedRankFilter===rf;
                      const rs = RANK_STYLE[rf];
                                            const count = rf==='All' ? (CAT_STATS[selectedCat]?.total ?? allKws.length) : catRankCounts[rf as keyof typeof catRankCounts]??0;
                      return (
                        <button key={rf} onClick={()=>setSelectedRankFilter(rf)} style={{
                          fontSize:10,fontWeight:800,padding:'4px 10px',borderRadius:6,cursor:'pointer',
                          border:`1.5px solid ${isActive?rs.border:'var(--border)'}`,
                          background:isActive?rs.activeBg:'transparent',
                          color:isActive?rs.active:'var(--text3)',
                          fontFamily:"'DM Mono',monospace",letterSpacing:'.04em',
                          transition:'all .15s',whiteSpace:'nowrap',
                        }}>
                          {RANK_LABELS[rf]}{rf!=='Funnel'&&<span style={{marginLeft:4,fontSize:9,opacity:.75}}>({count})</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
                {/* TOFU / MOFU / BOFU sub-pills — only when FUNNEL is active */}
                {selectedRankFilter === 'Funnel' && (
                  <div style={{display:'flex',gap:6,padding:'8px 0 4px',borderTop:'1px solid var(--border)'}}>
                    {(['TOFU','MOFU','BOFU'] as const).map(f=>{
                      const isActive = selectedBlFunnel===f;
                      const fs = BL_FUNNEL_STYLE[f];
                      return (
                        <button key={f} onClick={()=>setSelectedBlFunnel(f)} style={{
                          fontSize:10,fontWeight:800,padding:'4px 10px',borderRadius:6,cursor:'pointer',
                          border:`1.5px solid ${isActive?fs.border:'var(--border)'}`,
                          background:isActive?fs.activeBg:'transparent',
                          color:isActive?fs.active:'var(--text3)',
                          fontFamily:"'DM Mono',monospace",letterSpacing:'.04em',
                          transition:'all .15s',
                        }}>
                          {f}<span style={{marginLeft:4,fontSize:9,opacity:.75}}>({catFunnelCounts[f]})</span>
                        </button>
                      );
                    })}
                  </div>
                )}
                <div style={{display:'flex',gap:10,marginBottom:10,flexWrap:'wrap'}}>
                  <div style={{marginLeft:'auto',fontSize:9,color:'var(--text3)',alignSelf:'center',fontFamily:"'DM Mono',monospace"}}>
                    {(()=>{
                                            const dispTotal = allKws.length;
                      const dispShowing = selectedRankFilter==='All'?dispTotal:displayKws.length;
                      return `showing ${dispShowing} of ${dispTotal} keywords`;
                    })()}
                  </div>
                </div>
                {displayKws.length === 0 && (
                  <div style={{padding:'20px',textAlign:'center',color:'var(--text3)',fontSize:12}}>
                    No keywords match this filter for {selectedCat}
                  </div>
                )}
                <div style={{overflowX:'auto'}} dangerouslySetInnerHTML={{__html: buildCatTableHtml(dedupeCatRows(selectedCat,displayKws))}} />
              </div>
            );
          })()}
        </div>

        {/* ═══ TOP RISK ═══ */}
        <div className={`fn-tab-panel${activeTab==='risk'?' active':''}`}>
          <TabHead eyebrow="06 — TOP RISK" title="Top Risk" sub="Not-ranking and declining keywords that need action" accent="#D93025" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={riskInsights} />
          {/* Headline Risk Banner */}
          <div className="fn-card fn-full" style={{marginBottom:16,background:'linear-gradient(135deg,rgba(217,48,37,.06) 0%,rgba(183,28,28,.03) 100%)',border:'1.5px solid rgba(217,48,37,.25)'}}>
            <div style={{display:'flex',alignItems:'center',gap:18,padding:'4px 0'}}>
              <div style={{width:56,height:56,borderRadius:14,background:'rgba(217,48,37,.12)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:26,flexShrink:0}}>⚠</div>
              <div style={{flex:1}}>
                <div style={{fontSize:11,fontWeight:700,color:'var(--red)',fontFamily:"'DM Mono',monospace",textTransform:'uppercase',letterSpacing:'.08em',marginBottom:3}}>Primary SEO Risk — Oct 28, 2026</div>
                <div style={{fontSize:20,fontWeight:800,color:'#0F172A',letterSpacing:'-.3px',marginBottom:4}}>"zero day" — <span style={{color:'var(--red)'}}>Not Ranking · 368K SV</span> · Highest-Volume NR Keyword</div>
                <div style={{fontSize:12,color:'var(--text3)',lineHeight:1.5}}>"zero day" (368K SV) is off the SERP since baseline and "what is malware" (135K SV) dropped off this week from #24. {RISK.notRanking} of 660 keywords are not ranking and {RISK.decliners} declined week over week. {RISK.mostAffected.cat} is the most affected category ({RISK.mostAffected.declining} declining · {RISK.mostAffected.notRanking} not ranking). Immediate action required on NR high-volume keywords and AI Cybersecurity content coverage ({CAT_STATS['AI Cybersecurity'].not_ranking} of {CAT_STATS['AI Cybersecurity'].total} not ranking).</div>
              </div>
              <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4,padding:'12px 20px',background:'rgba(217,48,37,.08)',borderRadius:12,border:'1.5px solid rgba(217,48,37,.2)',flexShrink:0}}>
                <div style={{fontSize:36,fontWeight:900,color:'var(--red)',fontFamily:"'DM Mono',monospace",lineHeight:1}}>101</div>
                <div style={{fontSize:9,fontWeight:700,color:'var(--red)',fontFamily:"'DM Mono',monospace",textTransform:'uppercase',letterSpacing:'.06em'}}>zero day</div>
                <div style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace",marginTop:2}}>368K vol/mo</div>
              </div>
            </div>
          </div>

          {/* Risk KPI strip */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:16}}>
            <div className="fn-kpi fn-kpi-red" style={{padding:'12px 16px'}}>
              <div className="fn-kpi-label">Total Decliners</div>
              <div className="fn-kpi-val red" style={{fontSize:28}}>{RISK.decliners}</div>
              <div className="fn-kpi-sub">Keywords that lost rank or dropped off · Oct 21 → Oct 28</div>
            </div>
            <div className="fn-kpi fn-kpi-amber" style={{padding:'12px 16px'}}>
              <div className="fn-kpi-label">Not Ranking</div>
              <div className="fn-kpi-val amber" style={{fontSize:28}}>{RISK.notRanking}</div>
              <div className="fn-kpi-sub">Of 660 keywords · no position Oct 28</div>
            </div>
            <div className="fn-kpi fn-kpi-red" style={{padding:'12px 16px'}}>
              <div className="fn-kpi-label">Highest Vol at Risk</div>
              <div className="fn-kpi-val red" style={{fontSize:28}}>{fmtVol(RISK.topVol.vol)}</div>
              <div className="fn-kpi-sub">{RISK.topVol.keyword} — {RISK.topVol.cur==null?'Not Ranking':'#'+RISK.topVol.cur}</div>
            </div>
            <div className="fn-kpi fn-kpi-purple" style={{padding:'12px 16px'}}>
              <div className="fn-kpi-label">Most Affected Category</div>
              <div className="fn-kpi-val purple" style={{fontSize:18}}>{RISK.mostAffected.cat}</div>
              <div className="fn-kpi-sub">{RISK.mostAffected.declining} Declining · {RISK.mostAffected.notRanking} Not Ranking</div>
            </div>
          </div>

          <div className="fn-grid2" style={{marginBottom:16,alignItems:'flex-start'}}>
            {/* Top Declining Keywords */}
            <div className="fn-card">
              <div className="fn-card-head">
                <div className="fn-card-icon" style={{background:'rgba(217,48,37,.1)'}}>📉</div>
                <span className="fn-card-title">Top Declining Keywords — Dec 31 → Oct 28</span>
                <span className="fn-card-meta">Baseline to current rank · positions lost</span>
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:8,padding:'4px 0'}}>
                {(()=>{
                  const TRD = Object.entries(CAT_KEYWORDS).flatMap(([c,l])=>l.map(k=>({keyword:k.keyword,category:c,vol_jan26:k.vol_jan26,baseline_rank:k.ranks[0] as number|null,current_rank:k.ranks[43] as number|null})))
                    .filter(k=>POS_CATS.includes(k.category)&&k.baseline_rank!=null&&k.current_rank!=null&&k.baseline_rank<=100&&k.current_rank<=100&&k.current_rank>k.baseline_rank)
                    .map(k=>({...k,delta_baseline:(k.current_rank as number)-(k.baseline_rank as number)}))
                    .sort((x,y)=>y.delta_baseline-x.delta_baseline||y.vol_jan26-x.vol_jan26)
                    .filter((k,i,arr)=>arr.findIndex(z=>z.keyword===k.keyword)===i)
                    .slice(0,15);
                  return TRD.map((d,i)=>(
                  <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',background:'var(--surface)',border:'1.5px solid var(--border)',borderRadius:10,gap:10}}>
                    <span style={{fontWeight:700,fontSize:13,color:'var(--text)',flex:1,minWidth:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{d.keyword}</span>
                    <div style={{display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
                      <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{width:92,textAlign:'center',boxSizing:'border-box',whiteSpace:'nowrap',padding:'3px 0'}}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                      <span style={{fontSize:11,fontFamily:"'DM Mono',monospace",fontWeight:600,color:'var(--text3)',width:48,textAlign:'center'}}>{fmtVol(d.vol_jan26)}</span>
                      <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:5,width:92}}>
                        <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace",fontWeight:600}}>#{d.baseline_rank}</span>
                        <span style={{fontSize:10,color:'var(--text4)'}}>→</span>
                        <span className={`fn-kw-rank ${rankBadgeClass(d.current_rank)}`}>{d.current_rank??101}</span>
                      </div>
                      <span style={{fontSize:12,fontWeight:800,color:'var(--red)',fontFamily:"'DM Mono',monospace",width:40,textAlign:'center'}}>{d.current_rank===null?'→101':`↓${Math.abs(d.delta_baseline)}`}</span>
                    </div>
                  </div>
                  ));
                })()}
              </div>
            </div>

            {/* Not Ranking + High-Priority Risks */}
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div className="fn-card">
                <div className="fn-card-head">
                  <div className="fn-card-icon" style={{background:'rgba(180,83,9,.1)'}}>🚫</div>
                  <span className="fn-card-title">Not Ranking on Oct 28</span>
                  <span className="fn-card-meta">Ranked Dec 31, 2025, now NR — top {Math.min(12,RISK.droppedCount)} by SV shown ({RISK.droppedCount} of {RISK.notRanking} NR total)</span>
                </div>
                <div style={{display:'flex',flexDirection:'column',gap:8,padding:'4px 0'}}>
                  {RISK.droppedTop.map(r=>({keyword:r.keyword,category:r.category,vol:r.vol})).map((d,i)=>(

                    <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',background:'var(--surface)',border:'1.5px solid var(--border)',borderRadius:10,gap:10}}>
                      <span style={{fontWeight:700,fontSize:13,color:'var(--text)',flex:1,minWidth:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{d.keyword}</span>
                      <div style={{display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
                        <span className={`fn-kw-cat fn-pill ${catClass(d.category)}`} style={{width:92,textAlign:'center',boxSizing:'border-box',whiteSpace:'nowrap',padding:'3px 0'}}>{d.category.replace('Top Opportunities','Top Opps')}</span>
                        <span style={{fontSize:11,fontFamily:"'DM Mono',monospace",fontWeight:600,color:'var(--text3)',width:48,textAlign:'center'}}>{fmtVol(d.vol)}</span>
                        <span className="fn-kw-rank fn-r-bad">101</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="fn-card">
                <div className="fn-card-head">
                  <div className="fn-card-icon" style={{background:'rgba(217,48,37,.1)'}}>🎯</div>
                  <span className="fn-card-title">Priority Risk Actions — Oct 2026</span>
                  <span className="fn-card-meta">Top 5 per funnel · ranked #11–#40 (just off Page 1) · not-ranking excluded · SV high to low</span>
                </div>
                {(()=>{
                  type RiskKW = {kw:string;cat:string;sv:number;pos:string|null;funnel:'TOFU'|'MOFU'|'BOFU'};
                  const RISK_KWS: RiskKW[] = RISK.priority.map(r=>({kw:r.keyword,cat:r.category,sv:r.vol,pos:r.cur==null?null:String(r.cur),funnel:r.funnel}));
                  const FUNNEL_CFG = {
                    TOFU:{label:'TOFU',color:'#1A56DB',bg:'rgba(26,86,219,.07)',border:'rgba(26,86,219,.18)',hdr:'rgba(26,86,219,.1)'},
                    MOFU:{label:'MOFU',color:'#0E7490',bg:'rgba(6,182,212,.06)',border:'rgba(6,182,212,.18)',hdr:'rgba(6,182,212,.1)'},
                    BOFU:{label:'BOFU',color:'#7C3AED',bg:'rgba(124,58,237,.06)',border:'rgba(124,58,237,.18)',hdr:'rgba(124,58,237,.1)'},
                  };
                  const posColor = (pos:string|null) => {
                    if(!pos) return '#DC2626';
                    const n = parseInt(pos);
                    if(n===1) return '#059669';
                    if(n<=5)  return '#1A56DB';
                    if(n<=10) return '#B45309';
                    return '#DC2626';
                  };
                  return (
                    <div style={{display:'flex',flexDirection:'column',gap:0}}>
                      {/* Column headers */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 110px 80px 56px 60px',gap:8,
                        padding:'5px 10px 7px',borderBottom:'2px solid var(--border)',marginBottom:4}}>
                        {['Keyword','Category','SV','Funnel','Position'].map((h,i)=>(
                          <span key={i} style={{fontSize:8,fontWeight:800,color:'var(--text3)',
                            textTransform:'uppercase',letterSpacing:'.07em',
                            textAlign:i>=1?'center':'left'}}>{h}</span>
                        ))}
                      </div>
                      {(['TOFU','MOFU','BOFU'] as const).map(funnel=>{
                        const fc = FUNNEL_CFG[funnel];
                        const rows = RISK_KWS.filter(r=>r.funnel===funnel);
                        return (
                          <div key={funnel} style={{marginBottom:10}}>
                            {/* Funnel section header */}
                            <div style={{display:'flex',alignItems:'center',gap:6,padding:'5px 10px',
                              background:fc.hdr,borderRadius:'6px 6px 0 0',borderBottom:`1px solid ${fc.border}`}}>
                              <span style={{width:6,height:6,borderRadius:'50%',background:fc.color,flexShrink:0}}/>
                              <span style={{fontSize:9,fontWeight:800,color:fc.color,
                                fontFamily:"'DM Mono',monospace",letterSpacing:'.07em'}}>{fc.label}</span>
                              <span style={{fontSize:9,color:fc.color,opacity:.7,marginLeft:2}}>
                                {rows.length} keywords · sorted by SV
                              </span>
                            </div>
                            {/* Keyword rows */}
                            {rows.map((r,i)=>(
                              <div key={i} style={{display:'grid',gridTemplateColumns:'1fr 110px 80px 56px 60px',
                                gap:8,padding:'8px 10px',alignItems:'center',
                                background:i%2===0?fc.bg:'transparent',
                                borderBottom:`1px solid ${fc.border}`,
                                borderRadius:i===rows.length-1?'0 0 6px 6px':0}}>
                                {/* Keyword */}
                                <span style={{fontSize:11,fontWeight:700,color:'var(--text)',
                                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{r.kw}</span>
                                {/* Category */}
                                <span style={{fontSize:9,fontWeight:700,padding:'2px 6px',borderRadius:4,
                                  background:catColor(r.cat)+'14',color:catColor(r.cat),
                                  fontFamily:"'DM Mono',monospace",overflow:'hidden',textOverflow:'ellipsis',
                                  whiteSpace:'nowrap',textAlign:'center'}}>
                                  {r.cat.replace('Top Opportunities','Top Opps').replace('AI Cybersecurity','AI Cyber').replace('Quantum Security','Quantum')}
                                </span>
                                {/* SV */}
                                <span style={{fontSize:11,fontWeight:700,color:'var(--text3)',
                                  fontFamily:"'DM Mono',monospace",textAlign:'center'}}>
                                  {r.sv>=1000?`${(r.sv/1000).toFixed(r.sv>=100000?0:1)}K`:r.sv}
                                </span>
                                {/* Funnel badge */}
                                <span style={{fontSize:9,fontWeight:800,color:fc.color,
                                  background:fc.hdr,padding:'2px 5px',borderRadius:4,
                                  fontFamily:"'DM Mono',monospace",textAlign:'center'}}>{funnel}</span>
                                {/* Position */}
                                <div style={{display:'flex',justifyContent:'center'}}>
                                  {r.pos ? (
                                    <span style={{fontSize:10,fontWeight:900,color:posColor(r.pos),
                                      background:posColor(r.pos)+'14',border:`1px solid ${posColor(r.pos)}30`,
                                      padding:'2px 6px',borderRadius:5,fontFamily:"'DM Mono',monospace",
                                      minWidth:28,textAlign:'center'}}>#{r.pos}</span>
                                  ) : (
                                    <span style={{fontSize:9,fontWeight:800,color:'#DC2626',
                                      background:'rgba(220,38,38,.08)',border:'1px solid rgba(220,38,38,.2)',
                                      padding:'2px 5px',borderRadius:5,fontFamily:"'DM Mono',monospace"}}>101</span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>

        </div>

        {/* old heatmap removed */}


        {/* ═══ EXPERT INSIGHTS — removed, see Top Risk tab ═══ */}
        <div style={{display:'none'}}>
          <div className="fn-grid2">
            <div>
              <div className="fn-insight-card fn-insight-green">
                <div className="fn-insight-label" style={{color:'var(--green)'}}>🏆 STRENGTH · NGFW Category Authority</div>
                <div className="fn-insight-title">Fortinet owns the NGFW SERP — categorically</div>
                <div className="fn-insight-text">
                  With <strong>105 of 141 NGFW keywords at Rank #1</strong> (74.5%), including permanent lock-ins like
                  <span className="fn-insight-metric">web application firewall</span>
                  <span className="fn-insight-metric">firewall rules</span>
                  <span className="fn-insight-metric">firewall configuration</span>
                  — these haven't budged from #1 for the entire 16-week period. The Cyberglossary is functioning as a true knowledge moat, not just content marketing.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-cyan">
                <div className="fn-insight-label" style={{color:'var(--cyan)'}}>🚀 BREAKTHROUGH · The VPN Capture of 2026</div>
                <div className="fn-insight-title">673K monthly searches — from Rank 41 to Rank #1</div>
                <div className="fn-insight-text">
                  <strong>"vpn"</strong> is the single highest-impact SEO win in this dataset. Starting at
                  <span className="fn-insight-metric" style={{color:'var(--red)'}}>Rank 41</span> in Dec 2025,
                  it climbed to <span className="fn-insight-metric" style={{color:'var(--green)'}}>Rank #1</span> by Apr 2026 — a <strong>40-position improvement in 16 weeks</strong>. At 673K monthly searches, capturing the #1 position for this keyword alone could represent hundreds of thousands of monthly organic sessions.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-purple">
                <div className="fn-insight-label" style={{color:'var(--purple)'}}>◈ INSIGHT · Zero Trust — Best Rank Consistency Score</div>
                <div className="fn-insight-title">Near-perfect stability at the lowest avg rank</div>
                <div className="fn-insight-text">
                  Zero Trust achieves <strong>Avg Rank 2.6</strong> across 20 keywords — the best of any category. Core terms like
                  <span className="fn-insight-metric">zero trust</span>
                  <span className="fn-insight-metric">ztna</span>
                  <span className="fn-insight-metric">zero trust architecture</span>
                  have been at Rank #1 for every single week tracked. The outlier is <strong>"zero trust security" (5.4K vol)</strong> oscillating between Rank 6–32 — the only crack in an otherwise perfect defensive wall.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-amber">
                <div className="fn-insight-label" style={{color:'var(--amber)'}}>⚠ RISK · Zero Day — Biggest Volume Gap</div>
                <div className="fn-insight-title">368K searches, stuck at Rank 25</div>
                <div className="fn-insight-text">
                  <strong>"zero day"</strong> has <span className="fn-insight-metric">368,000 monthly searches</span> — the second-highest volume in the entire dataset — yet Fortinet is at <strong>Rank 25</strong>, declining with a <span className="fn-insight-metric" style={{color:'var(--red)'}}>−9 delta</span>. This is the most costly unaddressed gap. Moving from Rank 25 to top 5 on this keyword alone could rival dozens of smaller wins combined.
                </div>
              </div>
            </div>
            <div>
              <div className="fn-insight-card fn-insight-blue">
                <div className="fn-insight-label" style={{color:'var(--blue)'}}>📊 PATTERN · SD-WAN's Volume Paradox</div>
                <div className="fn-insight-title">Highest keyword count, highest avg rank — a maintenance challenge</div>
                <div className="fn-insight-text">
                  SD-WAN tracks the most keywords (130) and holds <strong>96 at Rank #1</strong>, but the avg rank of <span className="fn-insight-metric">5.0</span> is the worst of any category. The tail keywords — especially commercial/comparison terms like
                  <span className="fn-insight-metric">best sd wan vendors</span>
                  <span className="fn-insight-metric">sd wan comparison</span>
                  — are dragging the average.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-red">
                <div className="fn-insight-label" style={{color:'var(--red)'}}>🔴 ALERT · SERP Volatility Cluster</div>
                <div className="fn-insight-title">4 high-volume terms showing dangerous instability</div>
                <div className="fn-insight-text">
                  Four keywords with 40K+ monthly volume show multi-position weekly swings:
                  <strong>"cybersecurity"</strong> (201K) ranges Rank 1–23 ·
                  <strong>"proxy"</strong> (201K) ranges Rank 1–20 ·
                  <strong>"malware"</strong> (40.5K) ranges Rank 1–26 ·
                  <strong>"phishing"</strong> (49.5K) ranges Rank 1–26.
                  Collectively these represent <strong>~493K monthly searches</strong> with no stable footing.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-green">
                <div className="fn-insight-label" style={{color:'var(--green)'}}>💡 OPPORTUNITY · Search Volume Surge</div>
                <div className="fn-insight-title">3 keywords where search demand outpaced rankings</div>
                <div className="fn-insight-text">
                  Volume has exploded since 2021:
                  <span className="fn-insight-metric" style={{color:'var(--green)'}}>vpn +3,618%</span>
                  <span className="fn-insight-metric" style={{color:'var(--green)'}}>cybersecurity +806%</span>
                  <span className="fn-insight-metric" style={{color:'var(--green)'}}>ztna +815%</span>
                  These represent secular demand trends. Fortinet is winning on ztna and vpn — but the surge in "cybersecurity" volume (now 201K) while rank still oscillates 1–23 means demand is outpacing content freshness.
                </div>
              </div>
              <div className="fn-insight-card fn-insight-purple">
                <div className="fn-insight-label" style={{color:'var(--purple)'}}>🎯 BOFU · Commercial Keyword Distribution</div>
                <div className="fn-insight-title">NGFW dominates BOFU with 43 product-intent keywords</div>
                <div className="fn-insight-text">
                  Across all 9 categories, <strong>86 BOFU keywords (15.9%)</strong> land on product or solution pages — signalling commercial intent. NGFW leads with <span className="fn-insight-metric" style={{color:'var(--green)'}}>43 BOFU</span> (pricing pages, product pages, solution landing pages). SD-WAN has <span className="fn-insight-metric" style={{color:'var(--amber)'}}>17 BOFU</span> (vendor comparison, solutions). NAC and Zero Trust have minimal BOFU (<span className="fn-insight-metric">3</span> and <span className="fn-insight-metric">1</span> respectively). Top Opportunities has <strong>0 BOFU</strong> — all 47 ranked keywords are informational cyberglossary content, representing a pipeline gap for direct commercial conversion.
                </div>
              </div>
              <div className="fn-insight-card" style={{background:'rgba(14,116,144,.04)',borderColor:'rgba(14,116,144,.18)'}}>
                <div className="fn-insight-label" style={{color:'var(--cyan)'}}>🎯 STRATEGY · Where to focus next 90 days</div>
                <div className="fn-insight-title">Top 3 highest-ROI ranking opportunities</div>
                <div className="fn-insight-text">
                  <strong>1. Zero Day (368K vol, Rank 25):</strong> A dedicated, deeply-linked pillar page could realistically move into top 5.<br/><br/>
                  <strong>2. IAM / Identity (33K, volatile Rank 8–20):</strong> Internal linking restructure from NAC pages could stabilize rank.<br/><br/>
                  <strong>3. "access control solutions" (1.9K, high intent):</strong> Despite massive volatility (Rank 9–70), this commercial intent term would drive direct pipeline — worth a dedicated landing page test.
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="fn-card fn-full" style={{marginTop:4}}>
            <div className="fn-card-head">
              <div className="fn-card-icon" style={{background:'rgba(10,122,85,.1)'}}>⏱</div>
              <span className="fn-card-title">SEO Performance Timeline — Key Milestones Dec 2025 → Apr 2026</span>
            </div>
            <div style={{padding:'6px 0'}}>
              {[
                {dot:{bg:'rgba(217,48,37,.08)',border:'rgba(217,48,37,.25)'},emoji:'📍',week:'WEEK 1 · Dec 31, 2025 — Baseline',text:<><strong>vpn</strong> starts at Rank 41 · <strong>NGFW</strong> begins with 103/141 at #1 · Zero Trust at 16/20 · Campaign baseline established across 419 keywords.</>},
                {dot:{bg:'rgba(26,86,219,.08)',border:'rgba(26,86,219,.25)'},emoji:'📈',week:'WEEKS 4-6 · Jan 21 – Feb 4 — VPN Surge Begins',text:<><strong>vpn</strong> climbs from Rank 33 → Rank 17. <strong>malware</strong> temporarily spikes to Rank 26 then recovers. NGFW maintains 95–103 keywords at #1.</>},
                {dot:{bg:'rgba(124,58,237,.08)',border:'rgba(124,58,237,.25)'},emoji:'⚡',week:'WEEKS 7-9 · Feb 11 – Feb 25 — SERP Flux Period',text:<>Highest volatility window: <strong>cybersecurity</strong> spikes to Rank 23 · <strong>iot</strong> drops to Rank 43 · <strong>phishing</strong> jumps to Rank 19. Industry-wide SERP reshuffle from possible algorithm update.</>},
                {dot:{bg:'rgba(10,122,85,.08)',border:'rgba(10,122,85,.25)'},emoji:'🏆',week:'WEEK 13 · Mar 25 — SD-WAN Peak',text:<>SD-WAN reaches its best week: <strong>96/130 keywords at Rank #1</strong> — highest SD-WAN count ever in this dataset. Sustained through Apr 8.</>},
                {dot:{bg:'rgba(10,122,85,.08)',border:'rgba(10,122,85,.3)'},emoji:'🎯',week:'WEEK 14-15 · Apr 1–8 — VPN Capture Complete',text:<><strong>vpn (673K)</strong> achieves Rank #1. <strong>cybersecurity (201K)</strong> hits Rank #1. <strong>NGFW</strong> reaches 105 keywords at #1 — best position of entire tracked period.</>},
                {dot:{bg:'rgba(26,86,219,.08)',border:'rgba(26,86,219,.3)'},emoji:'📊',week:'WEEK 16 · Apr 15, 2026 — Latest Update',text:<>New week data ingested from SEMrush. <strong>cybersecurity</strong> drops to Rank 23 (−22). <strong>saml</strong> improves to Rank #1 (+9). <strong>network firewalls</strong> holds Rank #1. Portfolio monitoring continues.</>}
              ].map((item,i)=>(
                <div key={i} className="fn-timeline-item">
                  <div className="fn-timeline-dot" style={{background:item.dot.bg,borderColor:item.dot.border}}>{item.emoji}</div>
                  <div className="fn-timeline-body">
                    <div className="fn-timeline-week">{item.week}</div>
                    <div className="fn-timeline-text">{item.text}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Expert Scorecard */}
          <div className="fn-card fn-full" style={{marginTop:14}}>
            <div className="fn-card-head">
              <div className="fn-card-icon" style={{background:'rgba(26,86,219,.1)'}}>◈</div>
              <span className="fn-card-title">Expert SEO Position Assessment — Category Scorecard</span>
            </div>
            <div style={{overflowX:'auto'}}>
            <table className="fn-data-table">
              <thead><tr>
                <th>Category</th><th>Total KWs</th><th>Rank #1</th><th>Coverage</th><th>Avg Rank</th>
                <th style={{color:'var(--blue)'}}>TOFU/MOFU</th>
                <th style={{color:'var(--purple)'}}>BOFU</th>
                <th style={{color:'var(--red)'}}>Not Ranking</th>
                <th>Improving</th><th>Declining</th><th>Balance</th><th>Assessment</th>
              </tr></thead>
              <tbody>
                {['NGFW','SD-WAN','NAC','Zero Trust','Top Opportunities','AI Cybersecurity','OT Security','Quantum Security','SASE'].map(cat=>{
                  const s = CAT_STATS[cat];
                  const st = scorecardStatuses[cat];
                  const net = s.improving - s.declining;
                  const tofuPct = Math.round(s.tofu_mofu / s.total * 100);
                  const bofuPct = Math.round(s.bofu / s.total * 100);
                  const nrPct   = Math.round(s.not_ranking / s.total * 100);
                  return (
                    <tr key={cat}>
                      <td style={{fontWeight:800,color:catColor(cat)}}>{cat}</td>
                      <td style={{fontFamily:"'DM Mono',monospace",fontWeight:600}}>{s.total}</td>
                      <td style={{color:'var(--green)',fontWeight:800,fontFamily:"'DM Mono',monospace"}}>{s.rank1}</td>
                      <td><span style={{background:s.pct>70?'rgba(10,122,85,.1)':s.pct>55?'rgba(180,83,9,.1)':'rgba(217,48,37,.1)',color:s.pct>70?'var(--green)':s.pct>55?'var(--amber)':'var(--red)',padding:'3px 10px',borderRadius:12,fontWeight:800,fontSize:11,fontFamily:"'DM Mono',monospace"}}>{s.pct}%</span></td>
                      <td style={{fontWeight:800,fontFamily:"'DM Mono',monospace"}}>{s.avg_rank}</td>
                      <td>
                        <span style={{display:'inline-flex',alignItems:'center',gap:5}}>
                          <span style={{fontWeight:800,fontFamily:"'DM Mono',monospace",color:'var(--blue)'}}>{s.tofu_mofu}</span>
                          <span style={{fontSize:9,color:'var(--text4)',fontFamily:"'DM Mono',monospace"}}>{tofuPct}%</span>
                        </span>
                      </td>
                      <td>
                        <span style={{display:'inline-flex',alignItems:'center',gap:5}}>
                          <span style={{fontWeight:800,fontFamily:"'DM Mono',monospace",color:'var(--purple)'}}>{s.bofu}</span>
                          <span style={{fontSize:9,color:'var(--text4)',fontFamily:"'DM Mono',monospace"}}>{bofuPct}%</span>
                        </span>
                      </td>
                      <td>
                        <span style={{display:'inline-flex',alignItems:'center',gap:5}}>
                          <span style={{fontWeight:800,fontFamily:"'DM Mono',monospace",color:s.not_ranking>0?'var(--red)':'var(--text4)'}}>{s.not_ranking}</span>
                          {s.not_ranking>0 && <span style={{fontSize:9,color:'var(--text4)',fontFamily:"'DM Mono',monospace"}}>{nrPct}%</span>}
                        </span>
                      </td>
                      <td style={{color:'var(--green)',fontWeight:800,fontFamily:"'DM Mono',monospace"}}>▲{s.improving}</td>
                      <td style={{color:'var(--red)',fontWeight:800,fontFamily:"'DM Mono',monospace"}}>▼{s.declining}</td>
                      <td style={{fontWeight:800,fontFamily:"'DM Mono',monospace",color:net>=0?'var(--green)':'var(--red)'}}>{net>=0?'+':''}{net}</td>
                      <td><span style={{background:'rgba(0,0,0,.05)',color:st.color,padding:'4px 12px',borderRadius:12,fontSize:11,fontWeight:800}}>{st.label}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
          </div>

          {/* Funnel Breakdown Chart */}
          <div className="fn-card fn-full" style={{marginTop:14}}>
            <div className="fn-card-head">
              <div className="fn-card-icon" style={{background:'rgba(26,86,219,.08)'}}>◈</div>
              <span className="fn-card-title">Keyword Funnel Distribution — TOFU/MOFU vs BOFU vs Not Ranking by Category</span>
              <span className="fn-card-meta">Source: Latest Top Rank URL classification · Oct 28, 2026</span>
            </div>
            <div className="fn-chart-wrap" style={{height:220}}><canvas id="funnelChart"></canvas></div>
            <div style={{display:'flex',gap:16,flexWrap:'wrap',marginTop:12,paddingTop:10,borderTop:'1.5px solid var(--border)'}}>
              {[
                {label:'TOFU/MOFU',color:'#1A56DB',desc:'Informational / Cyberglossary URLs — Awareness & Education'},
                {label:'BOFU',color:'#7C3AED',desc:'Product / Solution URLs — Commercial Intent'},
                {label:'Not Ranking',color:'#D93025',desc:'No position Oct 28, 2026 — Dropped off SERP'},
              ].map((item,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:6}}>
                  <div style={{width:10,height:10,borderRadius:3,background:item.color,flexShrink:0}}></div>
                  <span style={{fontSize:10,fontWeight:700,color:'var(--text2)',fontFamily:"'DM Mono',monospace"}}>{item.label}</span>
                  <span style={{fontSize:10,color:'var(--text3)'}}>— {item.desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>


        {/* ═══ GAIN & LOSS ═══ */}
        <div className={`fn-tab-panel${activeTab==='gainloss'?' active':''}`}>
          <TabHead eyebrow="07 — GAIN & LOSS" title="Gain & Loss" sub="Top gaining URLs and keywords behind the traffic movement" accent="#0E7490" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={gainInsights} />

          {GL_SECTIONS.filter(s=>!s.intlFor).map((s,i)=>{
            const intl = GL_SECTIONS.find(x=>x.intlFor===s.title);
            return <GlCard key={i} s={s} extra={intl} />;
          })}


        </div>
        {/* ═══ TRAFFIC OVERVIEW ═══ */}
        <div className={`fn-tab-panel${activeTab==='traffic'?' active':''}`}>
          <TabHead eyebrow="01 — TRAFFIC OVERVIEW" title="Traffic Overview" sub="Organic search and site traffic from GSC and GA" accent="#0A7A55" onHome={()=>handleTabSwitch('home')} />
          <KeyInsights items={trafficInsights} />

          {/* ── Executive Summary Banner ── */}
          <div style={{background:'linear-gradient(135deg,#0F172A 0%,#1E293B 100%)',borderRadius:12,padding:'20px 24px',marginBottom:20,display:'flex',alignItems:'flex-start',gap:24,flexWrap:'wrap'}}>
            <div style={{flex:'1 1 300px'}}>
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
                <span style={{fontSize:11,fontWeight:700,letterSpacing:'.12em',textTransform:'uppercase',color:'#94A3B8'}}>Traffic Performance Report</span>
                <span style={{background:'rgba(26,86,219,.35)',color:'#93C5FD',fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:20,border:'1px solid rgba(147,197,253,.3)'}}>Week of Oct 28, 2026</span>
              </div>
              <div style={{fontSize:22,fontWeight:800,color:'#F8FAFC',lineHeight:1.2,marginBottom:6}}>Organic Traffic</div>
            </div>
            <div style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'center'}}>
              {[
                {src:'GSC',label:'Google Search Console',color:'#10B981',bg:'rgba(16,185,129,.15)',border:'rgba(16,185,129,.3)',desc:'Search impressions & clicks'},
                {src:'GA',label:'Google Analytics',color:'#60A5FA',bg:'rgba(96,165,250,.15)',border:'rgba(96,165,250,.3)',desc:'Sessions, channels & pages'},
              ].map(s=>(
                <div key={s.src} style={{background:s.bg,border:`1px solid ${s.border}`,borderRadius:10,padding:'10px 16px',minWidth:170}}>
                  <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4}}>
                    <span style={{background:s.color,color:'#fff',fontSize:9,fontWeight:800,padding:'2px 6px',borderRadius:4,letterSpacing:'.06em'}}>{s.src}</span>
                    <span style={{fontSize:11,fontWeight:700,color:s.color}}>{s.label}</span>
                  </div>
                  <div style={{fontSize:10,color:'#94A3B8'}}>{s.desc}</div>
                  <div style={{fontSize:9,color:'#64748B',marginTop:2}}>Scope: WW · Sun–Sat</div>
                </div>
              ))}
            </div>
          </div>

          {/* ══ Traffic Metrics — separate GSC and GA blocks ══ */}
          {([
            {src:'GSC',color:'#047857',title:'Complete Traffic Metrics — GSC (Google Search Console)',sub:'All Organic · Branded · Non-Branded · Worldwide · Dec 31, 2025 → Oct 28, 2026',badge:'GSC · Search Console'},
            {src:'GA',color:'#1D4ED8',title:'Complete Traffic Metrics — GA (Google Analytics)',sub:'Pages and Channels · Worldwide · Dec 31, 2025 → Oct 28, 2026',badge:'GA · Analytics'},
          ] as const).map(blk=>(
          <div key={blk.src} style={{background:'#fff',border:`2px solid ${blk.color}`,borderRadius:14,overflow:'hidden',boxShadow:'0 4px 16px rgba(15,23,42,.08)',marginBottom:20}}>
            <div style={{padding:'16px 22px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:12,flexWrap:'wrap',background:blk.color}}>
              <div>
                <div style={{fontSize:16,fontWeight:800,color:'#fff',letterSpacing:'-.01em'}}>{blk.title}</div>
                <div style={{fontSize:11,color:'rgba(255,255,255,.85)',marginTop:2,fontWeight:600}}>{blk.sub}</div>
              </div>
              <span style={{background:'#fff',color:blk.color,fontSize:11,fontWeight:800,padding:'5px 12px',borderRadius:6,letterSpacing:'.04em'}}>{blk.badge}</span>
            </div>
            <div style={{overflowX:'auto'}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead>
                  <tr style={{background:'#F8FAFC',borderBottom:'2px solid #E2E8F0'}}>
                    <th style={{textAlign:'center',padding:'9px 10px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',width:46}}>Source</th>
                    <th style={{textAlign:'left',padding:'9px 14px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',minWidth:180}}>Category</th>
                    <th style={{textAlign:'right',padding:'9px 12px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',whiteSpace:'nowrap'}}>Baseline<br/><span style={{fontWeight:500,fontSize:8}}>Dec 31</span></th>
                    <th style={{textAlign:'right',padding:'9px 12px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',whiteSpace:'nowrap'}}>Oct 21<br/><span style={{fontWeight:500,fontSize:8}}>Prev Week</span></th>
                    <th style={{textAlign:'right',padding:'9px 12px',fontSize:9,fontWeight:700,color:'#1A56DB',letterSpacing:'.06em',textTransform:'uppercase',whiteSpace:'nowrap'}}>Oct 28<br/><span style={{fontWeight:500,fontSize:8}}>Latest</span></th>
                    <th style={{textAlign:'center',padding:'9px 12px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',whiteSpace:'nowrap'}}>WoW Δ<br/><span style={{fontWeight:500,fontSize:8}}>Oct 21 → Oct 28</span></th>
                    <th style={{textAlign:'center',padding:'9px 14px',fontSize:9,fontWeight:700,color:'#64748B',letterSpacing:'.06em',textTransform:'uppercase',whiteSpace:'nowrap'}}>44-Wk Trend</th>
                  </tr>
                </thead>
                <tbody>
                  {([
                    {src:'GSC',srcColor:'#10B981',srcBg:'rgba(16,185,129,.1)',label:'All Organic Traffic',key:'allOrganic',group:'Search'},
                    {src:'GSC',srcColor:'#10B981',srcBg:'rgba(16,185,129,.1)',label:'Branded Traffic',key:'branded',group:''},
                    {src:'GSC',srcColor:'#10B981',srcBg:'rgba(16,185,129,.1)',label:'Non-Branded Traffic',key:'nonBranded',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/cyberglossary',key:'cyberglossary',group:'Pages'},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/products',key:'products',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/home page',key:'homePage',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/blog',key:'blog',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/solutions',key:'solutions',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/about-us',key:'aboutUs',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'/articles',key:'articles',group:''},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'Direct (All)',key:'directGA',group:'Channels'},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'Direct (Valid — excl. email/live-chat/Nexus)',key:'directValid',group:'Channels'},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'Direct (Valid — excl. Downloads)',key:'directDownloads',group:'Channels'},
                    {src:'GA',srcColor:'#3B82F6',srcBg:'rgba(59,130,246,.1)',label:'Referrals',key:'referrals',group:''},
                  ] as const).filter(r=>r.src===blk.src).map((row,i)=>{
                    const data = TRAFFIC_DATA[row.key];
                    const base = data[0], prev = data[42], cur = data[43];
                    const wow = TRAFFIC_WOW[row.key];
                    const pos = wow.pct >= 0;
                    const fmt = (v:number)=>v>=1000?(v>=100000?(v/1000).toFixed(0)+'K':(v/1000).toFixed(1)+'K'):v.toString();
                    const W=110,H=22;
                    const mn=Math.min(...data),mx=Math.max(...data);
                    const pts=data.map((v,idx)=>{const x=(idx/(data.length-1))*(W-2)+1;const y=mx===mn?H/2:((1-(v-mn)/(mx-mn))*(H-4))+2;return `${x.toFixed(1)},${y.toFixed(1)}`;}).join(' ');
                    const sparkCol = '#1E293B';
                    const endX = ((data.length-1)/(data.length-1))*(W-2)+1;
                    const endY = mx===mn?H/2:((1-(cur-mn)/(mx-mn))*(H-4))+2;
                    const isGroupStart = row.group !== '';
                    return (
                      <tr key={row.key} style={{borderBottom:'1px solid #F1F5F9',background:isGroupStart?'#F8FAFC':i%2===0?'#fff':'#FAFBFC'}}>
                        <td style={{padding:'8px 10px',textAlign:'center'}}>
                          <span style={{background:row.srcBg,color:row.srcColor,fontSize:8,fontWeight:800,padding:'2px 6px',borderRadius:4,letterSpacing:'.05em',display:'inline-block'}}>{row.src}</span>
                        </td>
                        <td style={{padding:'8px 14px',fontWeight:700,color:'#0F172A',fontSize:12}}>
                          {row.group && <span style={{display:'inline-block',fontSize:8,fontWeight:700,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'.06em',marginRight:7,background:'#F1F5F9',padding:'1px 5px',borderRadius:3}}>{row.group}</span>}
                          {row.label}
                        </td>
                        <td style={{padding:'8px 12px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:11,color:'#94A3B8',fontWeight:600}}>{fmt(base)}</td>
                        <td style={{padding:'8px 12px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:11,color:'#64748B',fontWeight:600}}>{fmt(prev)}</td>
                        <td style={{padding:'8px 12px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:800,color:'#0F172A',borderLeft:'2px solid rgba(26,86,219,.15)',borderRight:'2px solid rgba(26,86,219,.15)'}}>{fmt(cur)}</td>
                        <td style={{padding:'8px 12px',textAlign:'center'}}>
                          <div style={{display:'inline-flex',flexDirection:'column',alignItems:'center',gap:1,background:pos?'rgba(5,150,105,.06)':'rgba(220,38,38,.06)',padding:'3px 8px',borderRadius:6}}>
                            <span style={{fontSize:11,fontWeight:800,fontFamily:"'DM Mono',monospace",color:pos?'#059669':'#DC2626'}}>{pos?'▲':'▼'} {Math.abs(wow.pct).toFixed(2)}%</span>
                            <span style={{fontSize:8,color:'#94A3B8',fontFamily:"'DM Mono',monospace"}}>{pos?'+':''}{wow.abs.toLocaleString()}</span>
                          </div>
                        </td>
                        <td style={{padding:'6px 14px',textAlign:'center'}}>
                          <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
                            <polyline points={pts} fill="none" stroke={sparkCol} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                            <circle cx={endX} cy={endY} r="2.5" fill={sparkCol}/>
                          </svg>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          ))}

          {/* ══ SECTION 1: GSC — Search Performance ══ */}
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
            <span style={{background:'#10B981',color:'#fff',fontSize:9,fontWeight:800,padding:'3px 8px',borderRadius:5,letterSpacing:'.08em',flexShrink:0}}>GSC</span>
            <span style={{fontSize:13,fontWeight:800,color:'#0F172A',letterSpacing:'-.01em'}}>Google Search Console — Organic Search Traffic</span>
            <div style={{flex:1,height:1,background:'#E2E8F0'}}></div>
            <span style={{fontSize:10,color:'#94A3B8',fontWeight:500}}>Worldwide · Oct 21 → Oct 28, 2026</span>
          </div>

          {/* GSC KPI Cards */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14,marginBottom:16}}>
            {([
              {label:'All Organic Traffic',key:'allOrganic',desc:'Total organic search sessions',icon:'🔍'},
              {label:'Branded Traffic',key:'branded',desc:'Sessions from brand-name queries',icon:'🏷'},
              {label:'Non-Branded Traffic',key:'nonBranded',desc:'Sessions from generic keywords',icon:'🌐'},
            ] as const).map(item=>{
              const data = TRAFFIC_DATA[item.key];
              const cur = data[43], prev = data[42], base = data[0];
              const wow = TRAFFIC_WOW[item.key];
              const pos = wow.pct >= 0;
              const vsBase = cur - base;
              const vsBasePct = ((vsBase / base) * 100).toFixed(1);
              const fmt = (v:number)=>v>=1000?(v>=100000?(v/1000).toFixed(0)+'K':(v/1000).toFixed(1)+'K'):v.toLocaleString();
              const W=80,H=20;
              const mn=Math.min(...data),mx=Math.max(...data);
              const pts=data.map((v,i)=>{const x=(i/(data.length-1))*(W-2)+1;const y=mx===mn?H/2:((1-(v-mn)/(mx-mn))*(H-4))+2;return `${x.toFixed(1)},${y.toFixed(1)}`;}).join(' ');
              return (
                <div key={item.key} style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'16px 20px',boxShadow:'0 1px 4px rgba(0,0,0,.04)',position:'relative',overflow:'hidden'}}>
                  <div style={{position:'absolute',top:0,left:0,right:0,height:3,background:'linear-gradient(90deg,#10B981,#059669)'}}></div>
                  <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:6}}>
                    <div>
                      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                        <span style={{background:'rgba(16,185,129,.12)',color:'#065F46',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GSC</span>
                        <span style={{fontSize:10,fontWeight:700,color:'#64748B',textTransform:'uppercase',letterSpacing:'.05em'}}>{item.icon} {item.label}</span>
                      </div>
                      <div style={{fontSize:28,fontWeight:900,color:'#0F172A',fontFamily:"'DM Mono',monospace",lineHeight:1}}>{fmt(cur)}</div>
                    </div>
                    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{marginTop:4,opacity:.8}}>
                      <polyline points={pts} fill="none" stroke={pos?'#10B981':'#D93025'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div style={{fontSize:10,color:'#64748B',marginBottom:8}}>{item.desc}</div>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',borderTop:'1px solid #F1F5F9',paddingTop:8}}>
                    <div style={{display:'flex',alignItems:'center',gap:5}}>
                      <span style={{fontSize:12,fontWeight:800,fontFamily:"'DM Mono',monospace",color:pos?'#059669':'#DC2626',background:pos?'rgba(5,150,105,.08)':'rgba(220,38,38,.08)',padding:'2px 7px',borderRadius:5}}>
                        {pos?'▲':'▼'} {Math.abs(wow.pct).toFixed(2)}%
                      </span>
                      <span style={{fontSize:9,color:'#94A3B8',fontFamily:"'DM Mono',monospace"}}>{pos?'+':''}{wow.abs.toLocaleString()} vs Oct 21</span>
                    </div>
                    <div style={{textAlign:'right'}}>
                      <div style={{fontSize:9,color:'#94A3B8'}}>vs Dec 31 baseline</div>
                      <div style={{fontSize:10,fontWeight:700,fontFamily:"'DM Mono',monospace",color:vsBase>=0?'#059669':'#DC2626'}}>{vsBase>=0?'+':''}{vsBasePct}%</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* GSC Trend Chart */}
          <div style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'16px 20px',marginBottom:20,boxShadow:'0 1px 4px rgba(0,0,0,.04)'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
              <div>
                <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:2}}>
                  <span style={{background:'rgba(16,185,129,.12)',color:'#065F46',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GSC</span>
                  <span style={{fontSize:12,fontWeight:700,color:'#0F172A'}}>Search Traffic — 44-Week Trend</span>
                </div>
                <div style={{fontSize:10,color:'#94A3B8'}}>All Organic · Branded · Non-Branded · Dec 31, 2025 → Oct 28, 2026</div>
              </div>
              <div style={{display:'flex',gap:6}}>
                {[{c:'#1A56DB',l:'All Organic'},{c:'#7C3AED',l:'Branded',d:true},{c:'#0A7A55',l:'Non-Branded'}].map(s=>(
                  <div key={s.l} style={{display:'flex',alignItems:'center',gap:4}}>
                    <svg width={16} height={8}><line x1="0" y1="4" x2="16" y2="4" stroke={s.c} strokeWidth={s.d?0:2} strokeDasharray={s.d?'3,2':undefined}/>{s.d&&<><line x1="0" y1="4" x2="5" y2="4" stroke={s.c} strokeWidth={2}/><line x1="9" y1="4" x2="16" y2="4" stroke={s.c} strokeWidth={2}/></>}</svg>
                    <span style={{fontSize:9,color:'#64748B',fontWeight:600}}>{s.l}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{height:230}}>
              <canvas id="trafficOrgChart"></canvas>
            </div>
          </div>

          {/* ══ SECTION 2: GA — Page Performance ══ */}
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
            <span style={{background:'#3B82F6',color:'#fff',fontSize:9,fontWeight:800,padding:'3px 8px',borderRadius:5,letterSpacing:'.08em',flexShrink:0}}>GA</span>
            <span style={{fontSize:13,fontWeight:800,color:'#0F172A',letterSpacing:'-.01em'}}>Google Analytics — Page-Level Traffic</span>
            <div style={{flex:1,height:1,background:'#E2E8F0'}}></div>
            <span style={{fontSize:10,color:'#94A3B8',fontWeight:500}}>Worldwide · Oct 21 → Oct 28, 2026</span>
          </div>

          {/* GA Page KPI grid — cur=data[43]=Oct21, prev=data[42]=Oct07 */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:16}}>
            {([
              {label:'/cyberglossary',key:'cyberglossary',color:'#D93025',bg:'rgba(217,48,37,.08)',icon:'📚'},
              {label:'/products',key:'products',color:'#B45309',bg:'rgba(180,83,9,.08)',icon:'📦'},
              {label:'/home page',key:'homePage',color:'#0E7490',bg:'rgba(14,116,144,.08)',icon:'🏠'},
              {label:'/blog',key:'blog',color:'#059669',bg:'rgba(5,150,105,.08)',icon:'✍'},
              {label:'/solutions',key:'solutions',color:'#7C3AED',bg:'rgba(124,58,237,.08)',icon:'💡'},
              {label:'/about-us',key:'aboutUs',color:'#EC4899',bg:'rgba(236,72,153,.08)',icon:'🏢'},
              {label:'/articles',key:'articles',color:'#64748B',bg:'rgba(100,116,139,.08)',icon:'📄'},
            ] as const).map(item=>{
              const data = TRAFFIC_DATA[item.key];
              const cur = data[43], prev = data[42];
              const wow = TRAFFIC_WOW[item.key];
              const pos = wow.pct >= 0;
              const fmt = (v:number)=>v>=1000?(v>=10000?(v/1000).toFixed(0)+'K':(v/1000).toFixed(1)+'K'):v.toLocaleString();
              return (
                <div key={item.key} style={{background:'#fff',border:`1px solid ${item.color}33`,borderRadius:10,padding:'12px 14px',boxShadow:'0 1px 3px rgba(0,0,0,.03)'}}>
                  <div style={{display:'flex',alignItems:'center',gap:5,marginBottom:5}}>
                    <span style={{background:'rgba(59,130,246,.1)',color:'#1D4ED8',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GA</span>
                    <span style={{fontSize:9,fontWeight:700,color:'#64748B'}}>{item.icon} {item.label}</span>
                  </div>
                  <div style={{fontSize:22,fontWeight:900,fontFamily:"'DM Mono',monospace",color:'#0F172A',lineHeight:1,marginBottom:4}}>{fmt(cur)}</div>
                  <div style={{fontSize:9,color:'#94A3B8',marginBottom:5}}>prev: {fmt(prev)}</div>
                  <div style={{display:'flex',alignItems:'center',gap:4}}>
                    <span style={{fontSize:11,fontWeight:800,fontFamily:"'DM Mono',monospace",color:pos?'#059669':'#DC2626'}}>{pos?'▲':'▼'}{Math.abs(wow.pct).toFixed(2)}%</span>
                    <span style={{fontSize:9,color:'#94A3B8'}}>{pos?'+':''}{wow.abs.toLocaleString()}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* GA Charts Row — Page trend + Page bar */}
          <div style={{display:'grid',gridTemplateColumns:'1.4fr 1fr',gap:14,marginBottom:20}}>
            <div style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'16px 20px',boxShadow:'0 1px 4px rgba(0,0,0,.04)'}}>
              <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:2}}>
                <span style={{background:'rgba(59,130,246,.1)',color:'#1D4ED8',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GA</span>
                <span style={{fontSize:12,fontWeight:700,color:'#0F172A'}}>44-Week Page Traffic Trend</span>
              </div>
              <div style={{fontSize:10,color:'#94A3B8',marginBottom:10}}>Key URL traffic by week · Dec 31 → Oct 28</div>
              <div style={{height:210}}>
                <canvas id="trafficPageChart"></canvas>
              </div>
            </div>
            <div style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'16px 20px',boxShadow:'0 1px 4px rgba(0,0,0,.04)'}}>
              <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:2}}>
                <span style={{background:'rgba(59,130,246,.1)',color:'#1D4ED8',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GA</span>
                <span style={{fontSize:12,fontWeight:700,color:'#0F172A'}}>Page Sessions — Oct 21 vs Oct 28</span>
              </div>
              <div style={{fontSize:10,color:'#94A3B8',marginBottom:10}}>WoW comparison by page</div>
              <div style={{height:210}}>
                <canvas id="trafficPageBarChart"></canvas>
              </div>
            </div>
          </div>

          {/* ══ SECTION 3: GA — Direct Traffic ══ */}
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
            <span style={{background:'#3B82F6',color:'#fff',fontSize:9,fontWeight:800,padding:'3px 8px',borderRadius:5,letterSpacing:'.08em',flexShrink:0}}>GA</span>
            <span style={{fontSize:13,fontWeight:800,color:'#0F172A',letterSpacing:'-.01em'}}>Google Analytics — Direct Traffic</span>
            <div style={{flex:1,height:1,background:'#E2E8F0'}}></div>
            <span style={{fontSize:10,color:'#94A3B8',fontWeight:500}}>All Direct · Validated (excl. email / live-chat / Nexus) · excl. Downloads</span>
          </div>

          {/* Direct KPI Cards */}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:14,marginBottom:14}}>
            {([
              {
                key:'directGA',
                label:'Direct (All)',
                note:'All direct sessions incl. email, live chat & Nexus device',
                icon:'⚡',
                color:'#7C3AED',
                accentBg:'linear-gradient(90deg,#7C3AED,#6D28D9)',
              },
              {
                key:'directValid',
                label:'Direct (Valid)',
                note:'Excl. email, live-chat page & Device — Nexus',
                icon:'✅',
                color:'#F59E0B',
                accentBg:'linear-gradient(90deg,#F59E0B,#D97706)',
              },
              {
                key:'directDownloads',
                label:'Direct (Valid — excl. Downloads)',
                note:'Further excl. /downloads traffic for cleanest direct intent signal',
                icon:'📥',
                color:'#0E7490',
                accentBg:'linear-gradient(90deg,#0E7490,#0891B2)',
              },
            ] as const).map(item=>{
              const data = TRAFFIC_DATA[item.key];
              const cur = data[43], prev = data[42], base = data[0];
              const wow = TRAFFIC_WOW[item.key];
              const pos = wow.pct >= 0;
              const fmt = (v:number)=>v>=1000?(v>=100000?(v/1000).toFixed(0)+'K':(v/1000).toFixed(1)+'K'):v.toLocaleString();
              const vsBase = ((cur-base)/base*100);
              // sparkline
              const W=88,H=22;
              const mn=Math.min(...data),mx=Math.max(...data);
              const pts=data.map((v,i)=>{const x=(i/(data.length-1))*(W-2)+1;const y=mx===mn?H/2:((1-(v-mn)/(mx-mn))*(H-4))+2;return `${x.toFixed(1)},${y.toFixed(1)}`;}).join(' ');
              return (
                <div key={item.key} style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'18px 22px',boxShadow:'0 1px 4px rgba(0,0,0,.04)',position:'relative',overflow:'hidden'}}>
                  <div style={{position:'absolute',top:0,left:0,right:0,height:3,background:item.accentBg}}></div>
                  <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:8}}>
                    <div>
                      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4}}>
                        <span style={{background:'rgba(59,130,246,.1)',color:'#1D4ED8',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GA</span>
                        <span style={{fontSize:10,fontWeight:700,color:'#64748B',textTransform:'uppercase',letterSpacing:'.05em'}}>{item.icon} {item.label}</span>
                      </div>
                      <div style={{fontSize:32,fontWeight:900,fontFamily:"'DM Mono',monospace",color:'#0F172A',lineHeight:1}}>{fmt(cur)}</div>
                      <div style={{fontSize:10,color:'#94A3B8',marginTop:4,maxWidth:260}}>{item.note}</div>
                    </div>
                    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{marginTop:6,opacity:.85}}>
                      <polyline points={pts} fill="none" stroke={pos?item.color:'#DC2626'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10,borderTop:'1px solid #F1F5F9',paddingTop:12}}>
                    <div>
                      <div style={{fontSize:9,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:2}}>Prev Week (Oct 21)</div>
                      <div style={{fontSize:14,fontWeight:800,fontFamily:"'DM Mono',monospace",color:'#64748B'}}>{fmt(prev)}</div>
                    </div>
                    <div>
                      <div style={{fontSize:9,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:2}}>WoW Change</div>
                      <div style={{display:'flex',alignItems:'center',gap:4}}>
                        <span style={{fontSize:14,fontWeight:800,fontFamily:"'DM Mono',monospace",color:pos?'#059669':'#DC2626'}}>{pos?'▲':'▼'}{Math.abs(wow.pct).toFixed(2)}%</span>
                      </div>
                      <div style={{fontSize:9,color:'#94A3B8',fontFamily:"'DM Mono',monospace"}}>{pos?'+':''}{wow.abs.toLocaleString()} sessions</div>
                    </div>
                    <div>
                      <div style={{fontSize:9,color:'#94A3B8',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:2}}>vs Dec 31 Baseline</div>
                      <div style={{fontSize:14,fontWeight:800,fontFamily:"'DM Mono',monospace",color:vsBase>=0?'#059669':'#DC2626'}}>{vsBase>=0?'+':''}{vsBase.toFixed(1)}%</div>
                      <div style={{fontSize:9,color:'#94A3B8',fontFamily:"'DM Mono',monospace"}}>baseline: {fmt(base)}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Direct Delta Insight */}
          {(()=>{
            const allCur   = TRAFFIC_DATA.directGA[43];
            const validCur = TRAFFIC_DATA.directValid[43];
            const dlCur    = TRAFFIC_DATA.directDownloads[43];
            const noiseL1  = allCur - validCur;
            const noiseL1Pct = ((noiseL1/allCur)*100).toFixed(1);
            const noiseL2  = validCur - dlCur;
            const noiseL2Pct = ((noiseL2/allCur)*100).toFixed(1);
            const totalNoisePct = (((allCur-dlCur)/allCur)*100).toFixed(1);
            return (
              <div style={{background:'linear-gradient(135deg,#FEF3C7,#FDE68A)',border:'1px solid #FCD34D',borderRadius:10,padding:'12px 18px',marginBottom:14,display:'flex',alignItems:'center',gap:14}}>
                <span style={{fontSize:22,flexShrink:0}}>📊</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:11,fontWeight:800,color:'#92400E',marginBottom:4}}>Direct Traffic Noise Filter — Oct 28, 2026</div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
                    <div style={{fontSize:10,color:'#78350F',lineHeight:1.5}}>
                      <div style={{fontWeight:800,marginBottom:1}}>Layer 1 — Email / Live-Chat / Nexus</div>
                      <strong>{noiseL1.toLocaleString()} sessions ({noiseL1Pct}%)</strong> filtered → Valid: <strong>{validCur.toLocaleString()}</strong>
                    </div>
                    <div style={{fontSize:10,color:'#78350F',lineHeight:1.5}}>
                      <div style={{fontWeight:800,marginBottom:1}}>Layer 2 — /downloads traffic</div>
                      <strong>{noiseL2.toLocaleString()} additional sessions ({noiseL2Pct}%)</strong> filtered → Clean: <strong>{dlCur.toLocaleString()}</strong>
                    </div>
                    <div style={{fontSize:10,color:'#78350F',lineHeight:1.5,background:'rgba(146,64,14,.08)',borderRadius:6,padding:'6px 10px'}}>
                      <div style={{fontWeight:800,marginBottom:1}}>Total Noise Removed</div>
                      <strong>{(allCur-dlCur).toLocaleString()} sessions ({totalNoisePct}%)</strong> of raw Direct are noise. Cleanest signal: <strong>{dlCur.toLocaleString()}</strong>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Direct Trendline Chart */}
          <div style={{background:'#fff',border:'1px solid #E2E8F0',borderRadius:12,padding:'16px 20px',marginBottom:20,boxShadow:'0 1px 4px rgba(0,0,0,.04)'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
              <div>
                <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:2}}>
                  <span style={{background:'rgba(59,130,246,.1)',color:'#1D4ED8',fontSize:8,fontWeight:800,padding:'1px 5px',borderRadius:3,letterSpacing:'.06em'}}>GA</span>
                  <span style={{fontSize:12,fontWeight:700,color:'#0F172A'}}>Direct Traffic — 44-Week Trendline</span>
                </div>
                <div style={{fontSize:10,color:'#94A3B8'}}>All Direct vs Validated Direct · Dec 31, 2025 → Oct 28, 2026</div>
              </div>
              <div style={{display:'flex',gap:12,alignItems:'center',flexWrap:'wrap'}}>
                <div style={{display:'flex',alignItems:'center',gap:5}}>
                  <div style={{width:20,height:3,background:'#7C3AED',borderRadius:2}}></div>
                  <span style={{fontSize:9,fontWeight:600,color:'#64748B'}}>Direct (All)</span>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:5}}>
                  <svg width={20} height={6}><line x1="0" y1="3" x2="5" y2="3" stroke="#F59E0B" strokeWidth={2}/><line x1="8" y1="3" x2="13" y2="3" stroke="#F59E0B" strokeWidth={2}/><line x1="16" y1="3" x2="20" y2="3" stroke="#F59E0B" strokeWidth={2}/></svg>
                  <span style={{fontSize:9,fontWeight:600,color:'#64748B'}}>Direct (Valid — excl. Nexus/email)</span>
                </div>
                <div style={{display:'flex',alignItems:'center',gap:5}}>
                  <svg width={20} height={6}><line x1="0" y1="3" x2="3" y2="3" stroke="#0E7490" strokeWidth={2}/><line x1="6" y1="3" x2="9" y2="3" stroke="#0E7490" strokeWidth={2}/><line x1="12" y1="3" x2="15" y2="3" stroke="#0E7490" strokeWidth={2}/><line x1="18" y1="3" x2="20" y2="3" stroke="#0E7490" strokeWidth={2}/></svg>
                  <span style={{fontSize:9,fontWeight:600,color:'#64748B'}}>Direct (Valid — excl. Downloads)</span>
                </div>
              </div>
            </div>
            <div style={{height:240}}>
              <canvas id="trafficDirectChart"></canvas>
            </div>
          </div>



        </div>


      </div>

      {/* ── Rank 11–100 Modal ── */}
      {modal1100 && (
        <div onClick={()=>setModal1100(false)} style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.55)',zIndex:9000,display:'flex',alignItems:'center',justifyContent:'center',padding:24}}>
          <div onClick={e=>e.stopPropagation()} style={{background:'var(--surface)',borderRadius:12,width:'100%',maxWidth:780,maxHeight:'82vh',display:'flex',flexDirection:'column',boxShadow:'0 24px 64px rgba(0,0,0,0.35)',border:'1px solid var(--border)'}}>
            {/* header */}
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 20px',borderBottom:'1px solid var(--border)',flexShrink:0}}>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <span style={{fontSize:15,fontWeight:700,color:'var(--text1)',fontFamily:"'Inter',sans-serif"}}>Rank 11–100 Keywords</span>
                <span style={{background:'#F97316',color:'#fff',fontSize:11,fontWeight:700,borderRadius:20,padding:'2px 10px',fontFamily:"'DM Mono',monospace"}}>{RANK_11_100.length} Keywords</span>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Source: Semrush</span>
                <button onClick={()=>setModal1100(false)} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text2)',fontSize:18,lineHeight:1,padding:2}}>✕</button>
              </div>
            </div>
            {/* table */}
            <div style={{overflowY:'auto',flex:1}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead style={{position:'sticky',top:0,background:'var(--surface)',zIndex:1}}>
                  <tr style={{borderBottom:'2px solid var(--border)'}}>
                    <th style={{textAlign:'left',padding:'8px 20px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>KEYWORDS</th>
                    <th style={{textAlign:'center',padding:'8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>FUNNEL</th>
                    <th style={{textAlign:'right',padding:'8px 14px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>SV</th>
                    <th style={{textAlign:'right',padding:'8px 20px 8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>POS PREV → CURR</th>
                  </tr>
                </thead>
                <tbody>
                  {RANK_11_100.map((r,i)=>(
                    <tr key={i} style={{borderBottom:'1px solid var(--border)',background:i%2===0?'transparent':'rgba(0,0,0,0.02)'}}>
                      <td style={{padding:'7px 20px',color:'var(--text1)',fontWeight:500,fontFamily:"'Inter',sans-serif",fontSize:12}}>{r.kw}</td>
                      <td style={{padding:'7px 10px',textAlign:'center'}}>
                        <span style={{fontSize:9,fontWeight:700,borderRadius:4,padding:'2px 6px',background:r.funnel==='TOFU'?'rgba(26,86,219,.12)':r.funnel==='MOFU'?'rgba(5,150,105,.12)':'rgba(180,83,9,.12)',color:r.funnel==='TOFU'?'#1A56DB':r.funnel==='MOFU'?'#059669':'#B45309',fontFamily:"'DM Mono',monospace"}}>{r.funnel}</span>
                      </td>
                      <td style={{padding:'7px 14px',textAlign:'right',color:'var(--text2)',fontFamily:"'DM Mono',monospace",fontSize:11}}>{r.sv>0?r.sv.toLocaleString():'-'}</td>
                      <td style={{padding:'7px 20px 7px 10px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:11,color:'var(--text2)',whiteSpace:'nowrap'}}>
                        {r.prev==='-'?101:'#'+r.prev} <span style={{color:'var(--text3)'}}>→</span> <span style={{color:'#0891B2',fontWeight:700}}>#{r.cur}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* footer */}
            <div style={{padding:'10px 20px',borderTop:'1px solid var(--border)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Scroll to view all {RANK_11_100.length} keywords</span>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Click outside to close</span>
            </div>
          </div>
        </div>
      )}

      {/* ── Not Ranking Modal ── */}
      {modalNR && (
        <div onClick={()=>setModalNR(false)} style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.55)',zIndex:9000,display:'flex',alignItems:'center',justifyContent:'center',padding:24}}>
          <div onClick={e=>e.stopPropagation()} style={{background:'var(--surface)',borderRadius:12,width:'100%',maxWidth:780,maxHeight:'82vh',display:'flex',flexDirection:'column',boxShadow:'0 24px 64px rgba(0,0,0,0.35)',border:'1px solid var(--border)'}}>
            {/* header */}
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 20px',borderBottom:'1px solid var(--border)',flexShrink:0}}>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <span style={{fontSize:15,fontWeight:700,color:'var(--text1)',fontFamily:"'Inter',sans-serif"}}>Not Ranking Keywords</span>
                <span style={{background:'#F97316',color:'#fff',fontSize:11,fontWeight:700,borderRadius:20,padding:'2px 10px',fontFamily:"'DM Mono',monospace"}}>{NOT_RANKING.length} Keywords</span>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Source: Semrush</span>
                <button onClick={()=>setModalNR(false)} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text2)',fontSize:18,lineHeight:1,padding:2}}>✕</button>
              </div>
            </div>
            {/* table */}
            <div style={{overflowY:'auto',flex:1}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead style={{position:'sticky',top:0,background:'var(--surface)',zIndex:1}}>
                  <tr style={{borderBottom:'2px solid var(--border)'}}>
                    <th style={{textAlign:'left',padding:'8px 20px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>KEYWORDS</th>
                    <th style={{textAlign:'center',padding:'8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>FUNNEL</th>
                    <th style={{textAlign:'right',padding:'8px 14px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>SV</th>
                    <th style={{textAlign:'right',padding:'8px 20px 8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>POS PREV → CURR</th>
                  </tr>
                </thead>
                <tbody>
                  {NOT_RANKING.map((r,i)=>(
                    <tr key={i} style={{borderBottom:'1px solid var(--border)',background:i%2===0?'transparent':'rgba(0,0,0,0.02)'}}>
                      <td style={{padding:'7px 20px',color:'var(--text1)',fontWeight:500,fontFamily:"'Inter',sans-serif",fontSize:12}}>{r.kw}</td>
                      <td style={{padding:'7px 10px',textAlign:'center'}}>
                        <span style={{fontSize:9,fontWeight:700,borderRadius:4,padding:'2px 6px',background:r.funnel==='TOFU'?'rgba(26,86,219,.12)':r.funnel==='MOFU'?'rgba(5,150,105,.12)':'rgba(180,83,9,.12)',color:r.funnel==='TOFU'?'#1A56DB':r.funnel==='MOFU'?'#059669':'#B45309',fontFamily:"'DM Mono',monospace"}}>{r.funnel}</span>
                      </td>
                      <td style={{padding:'7px 14px',textAlign:'right',color:'var(--text2)',fontFamily:"'DM Mono',monospace",fontSize:11}}>{r.sv>0?r.sv.toLocaleString():'-'}</td>
                      <td style={{padding:'7px 20px 7px 10px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:11,color:'var(--text2)',whiteSpace:'nowrap'}}>
                        {r.prev==='-'?101:'#'+r.prev} <span style={{color:'var(--text3)'}}>→</span> <span style={{color:'#DC2626',fontWeight:700}}>101</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* footer */}
            <div style={{padding:'10px 20px',borderTop:'1px solid var(--border)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Scroll to view all {NOT_RANKING.length} keywords</span>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Click outside to close</span>
            </div>
          </div>
        </div>
      )}

      {/* ── AIO Keywords Modal ── */}
      {modalAIO && (
        <div onClick={()=>setModalAIO(false)} style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.55)',zIndex:9000,display:'flex',alignItems:'center',justifyContent:'center',padding:24}}>
          <div onClick={e=>e.stopPropagation()} style={{background:'var(--surface)',borderRadius:16,width:'100%',maxWidth:780,maxHeight:'82vh',display:'flex',flexDirection:'column',boxShadow:'0 24px 64px rgba(0,0,0,.25)',border:'1px solid var(--border)'}}>
            {/* header */}
            <div style={{padding:'16px 20px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <span style={{fontSize:15,fontWeight:700,color:'var(--text1)',fontFamily:"'Inter',sans-serif"}}>AIO Keywords — Oct 28, 2026</span>
                <span style={{background:'#4338CA',color:'#fff',fontSize:11,fontWeight:700,borderRadius:20,padding:'2px 10px',fontFamily:"'DM Mono',monospace"}}>{AIO_KEYWORDS.length} Keywords</span>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Source: Semrush</span>
                <button onClick={()=>setModalAIO(false)} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text2)',fontSize:18,lineHeight:1,padding:2}}>✕</button>
              </div>
            </div>
            {/* table */}
            <div style={{overflowY:'auto',flex:1}}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead style={{position:'sticky',top:0,background:'var(--surface)',zIndex:1}}>
                  <tr style={{borderBottom:'2px solid var(--border)'}}>
                    <th style={{textAlign:'left',padding:'8px 20px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>KEYWORDS</th>
                    <th style={{textAlign:'center',padding:'8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>FUNNEL</th>
                    <th style={{textAlign:'right',padding:'8px 14px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>SV</th>
                    <th style={{textAlign:'right',padding:'8px 20px 8px 10px',color:'var(--text3)',fontWeight:600,fontFamily:"'DM Mono',monospace",fontSize:10,letterSpacing:'.06em'}}>POS PREV → CURR</th>
                  </tr>
                </thead>
                <tbody>
                  {(()=>{const dupSet=new Set(['what is a firewall','wan','firewall','sd-wan','sdwan','sd wan','firewalls','network security firewall']);const seen=new Set<string>();return AIO_KEYWORDS.filter(r=>{if(!dupSet.has(r.kw))return true;if(seen.has(r.kw))return false;seen.add(r.kw);return true;});})().map((r,i)=>(
                    <tr key={i} style={{borderBottom:'1px solid var(--border)',background:i%2===0?'transparent':'rgba(0,0,0,0.02)'}}>
                      <td style={{padding:'7px 20px',color:'var(--text1)',fontWeight:500,fontFamily:"'Inter',sans-serif",fontSize:12}}>{r.kw}</td>
                      <td style={{padding:'7px 10px',textAlign:'center'}}>
                        <span style={{fontSize:9,fontWeight:700,borderRadius:4,padding:'2px 6px',background:r.funnel==='TOFU'?'rgba(26,86,219,.12)':r.funnel==='MOFU'?'rgba(5,150,105,.12)':'rgba(180,83,9,.12)',color:r.funnel==='TOFU'?'#1A56DB':r.funnel==='MOFU'?'#059669':'#B45309',fontFamily:"'DM Mono',monospace"}}>{r.funnel}</span>
                      </td>
                      <td style={{padding:'7px 14px',textAlign:'right',color:'var(--text2)',fontFamily:"'DM Mono',monospace",fontSize:11}}>{r.sv>0?r.sv.toLocaleString():'-'}</td>
                      <td style={{padding:'7px 20px 7px 10px',textAlign:'right',fontFamily:"'DM Mono',monospace",fontSize:11,color:'var(--text2)',whiteSpace:'nowrap'}}>
                        {r.prev==='NR'||r.prev==='-'?101:'#'+r.prev} <span style={{color:'var(--text3)'}}>→</span> <span style={{color:'#4338CA',fontWeight:700}}>{r.cur==='NR'||r.cur==='-'?101:'#'+r.cur}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* footer */}
            <div style={{padding:'10px 20px',borderTop:'1px solid var(--border)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Scroll to view all {AIO_KEYWORDS.length} AIO keywords · Oct 21 → Oct 28</span>
              <span style={{fontSize:10,color:'var(--text3)',fontFamily:"'DM Mono',monospace"}}>Click outside to close</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
